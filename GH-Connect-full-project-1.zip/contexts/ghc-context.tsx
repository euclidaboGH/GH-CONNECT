"use client"
import {
  fetchServerProfile,
  persistServerProfile,
} from "@/lib/profile/server-profile-sync"

import { useMemo, createContext, useContext, useState, useEffect, ReactNode, useCallback, startTransition } from "react"
import type { Profile, Settings, Post, StoryItem, Tab, Toast, Candidate, MatchEntry, Conversation, Like, FriendRequest, Message } from "@/lib/ghc-types"
import { socialGraphStore } from "@/lib/social-graph-store"
import { resolveBlockedIds, applyGlobalBlockFilters } from "@/lib/block-enforcement"
import {
  applyGraphPatch,
  patchFromFollow,
  patchFromBlock,
  patchFromUnblock,
  patchFromMute,
  patchFromRestrict,
  patchFromFriendRemoved,
  patchFromMatchIds,
  syncSessionEdgesToStore,
} from "@/lib/domains/graph-session-adapter"
import { defaultProfile, DEFAULT_SETTINGS, coerceStoredProfile, sanitizeStories, sanitizeStory, STORAGE_KEYS, generateId } from "@/lib/ghc-data"
import {
  bootstrapPosts,
  bootstrapStories,
  bootstrapCandidates,
  bootstrapLikes,
} from "@/lib/domains/adapters/session-bootstrap"
import { canFollowUser as privacyCanFollow, canMessageUser as privacyCanMessage } from "@/lib/privacy-controls"
import {
  type LocalProfileRecord,
  readLocalProfiles,
  writeLocalProfile,
  profileToLocalCandidate,
  getActiveLocalProfileId,
  setActiveLocalProfileId,
  findLocalProfile,
} from "@/lib/local-profiles"
import { usePiAuth } from "./pi-auth-context"
import { IdentityService } from "@/lib/identity/identity-service"
import {
  findCompletedLocalProfileForUser,
  isCompletedProfileShape,
} from "@/lib/onboarding-local"
import { validation } from "@/lib/validation"
import { messageLimiter, postLimiter, spamDetection } from "@/lib/rate-limiter"
import { analytics } from "@/lib/analytics"
import { notificationSystem } from "@/lib/notifications"
import { emitCommunityNotification } from "@/lib/domains/adapters/community-notification"
import {
  appendModerationLog,
  createCommunityReport,
} from "@/lib/domains/adapters/community-governance"
import { offlineSupport } from "@/lib/offline"
import { offlineQueue, connectionMonitor, withRetry } from "@/lib/network-resilience"
import { sanitizeText, sanitizeDisplayName, sanitizeHtml } from "@/lib/sanitizer"
import { getCsrfToken, getCsrfHeader } from "@/lib/csrf-protection"
import { isRateLimited, recordAuthAttempt, getRemainingAttempts } from "@/lib/auth-rate-limiter"
import { errorLogger, NetworkError, OfflineError } from "@/lib/error-recovery"
import { backupRecoveryManager } from "@/lib/backup-recovery"
import { dataConsistencyChecker } from "@/lib/data-consistency"
import { transactionManager } from "@/lib/transactions"
// Profile enhancements - achievements, analytics, privacy controls, etc.
import {
  calculateProfileCompletionMetrics,
  evaluateAchievements,
  createPinnedPostsManager,
  calculateProfileAnalytics,
  calculateFollowerInsights,
  DEFAULT_PRIVACY_SETTINGS,
  type ProfileCompletionMetrics,
  type EnhancedProfileState,
} from "@/lib/profile-enhancements"
// Master unified messaging engine (all message/chat features consolidated here, no duplicates)
import {
  filterConversationList,
  prepareMessageForSending,
  handleMessageEdit,
  handleMessageDeletion,
  handleMessageReaction,
  handleMessageReply,
  handleMessageForwarding,
  handleMessageRead,
  TypingIndicatorManager,
  searchMessages as searchMessagesInThread,
  toggleConversationPin,
  toggleConversationArchive,
  toggleConversationMute,
  createVoiceNoteMessage,
  ScheduledMessageQueue,
  updateGroupRole,
  removeGroupMember as applyRemoveGroupMember,
  draftStorage,
  analyzeMessageThreadData,
  type ConversationListFilter,
  type MessageOperation,
  type MessageSearchOptions,
  type MediaUploadProgress,
  type DraftMessage,
  type MessageAnalytics,
  type GroupRole,
} from "@/lib/unified-messaging-engine"
import { domainEvents } from "@/lib/realtime/event-bus"
import { subscribeDomainCache } from "@/lib/realtime/use-domain-events"
import { transportBridge } from "@/lib/realtime/transport-bridge"
import { createDomainServices, bindDomainServices, type DomainServices } from "@/lib/domains"
import {
  loadPersistedCommunities,
  persistCommunityConversation,
  markJoined,
  markLeft,
  mergeCommunityConversations,
} from "@/lib/domains/community-persistence"
// Master unified post/comment system (all features consolidated here, no duplicates)
import {
  createNestedComment,
  addReplyToComment,
  buildCommentThreads,
  flattenCommentThread,
  sortComments,
  addReactionToComment,
  removeReactionFromComment,
  getTopCommentReactions,
  validateMediaAttachment,
  addMediaToComment,
  editComment,
  editPost,
  pinComment,
  unpinComment,
  getPinnedComment,
  extractMentions,
  extractHashtags,
  extractUrls,
  isValidUrl,
  validateMentions,
  validateHashtags,
  createQuoteRepost,
  generateShareText,
  getSocialShareUrl,
  copyPostLink,
  savePostToCollection,
  removePostFromCollection,
  hidePost,
  trackNotInterested,
  reportPost,
  createFollowAction,
  muteUser,
  blockUser,
  validateCommentText,
  validatePostContent,
  detectSpamContent,
  sanitizeCommentText,
  sanitizePostText,
  findCommentById,
  flattenComments,
  type EnhancedComment,
  type CommentThread,
  type CommentSortOption,
  type MediaAttachment,
  type CommentReaction,
  type UserRestriction,
  type QuoteRepost,
  type PostShare,
} from "@/lib/post-comment-system-complete"

interface GHCContextType {
  ready: boolean
  profile: Profile
  settings: Settings
  posts: Post[]
  stories: StoryItem[]
  publishStory: (story: StoryItem) => Promise<void>
  /** Opens/creates private chat with story owner via Messaging domain */
  replyToStory: (storyId: string) => Promise<string | null>
  tab: Tab
  toasts: Toast[]
  candidates: Candidate[]
  matches: MatchEntry[]
  /** Transient mutual-match confirmation (UI only) */
  matchCelebration: null | { userId: string; userName: string; userPhoto: string }
  likes: Like[]
  conversations: Conversation[]
  friendRequests: FriendRequest[]
  following: string[]
  /** Mutual connections (explicit friends graph) */
  friends: string[]
  shares: import("@/lib/share-types").ShareRecord[]
  reposts: import("@/lib/share-types").RepostFeedItem[]
  likedPostIds: string[]
  isOnline: boolean
  networkQuality: "excellent" | "good" | "fair" | "poor" | "offline"
  dataIntegrity: "verified" | "suspected_corruption" | "unknown"
  
  // Backup & Recovery
  createBackup: () => void
  restoreFromBackup: () => Promise<boolean>

  // Profile actions
  updateProfile: (updates: Partial<Profile>) => Promise<void>
  completeOnboarding: () => Promise<void>
  localProfiles: Array<LocalProfileRecord>
  switchLocalProfile: (localId: string) => void
  createLocalProfile: (profile: Partial<Profile>) => void

  // Posts
  createPost: (
    content: string,
    images: string[],
    video: string | null,
    pdf: string | null,
    pdfName: string | null,
    audience?: "public" | "followers" | "mutuals" | "private",
    community?: { id: string; name: string } | null,
  ) => Promise<boolean>
  likePost: (postId: string) => Promise<void>
  deletePost: (postId: string) => Promise<void>
  editPost: (postId: string, newContent: string) => Promise<void>
  archivePost: (postId: string) => Promise<void>
  unarchivePost: (postId: string) => Promise<void>
  addComment: (postId: string, text: string, replyToCommentId?: string) => Promise<void>
  editComment: (postId: string, commentId: string, newText: string) => Promise<void>
  deleteComment: (postId: string, commentId: string) => Promise<void>
  addCommentReaction: (postId: string, commentId: string, emoji: string) => Promise<void>
  removeCommentReaction: (postId: string, commentId: string, emoji: string) => Promise<void>
  pinComment: (postId: string, commentId: string) => Promise<void>
  unpinComment: (postId: string, commentId: string) => Promise<void>
  createQuoteRepost: (originalPostId: string, quoteText: string) => Promise<void>
  sharePost: (postId: string, platform: "twitter" | "facebook" | "linkedin" | "copy" | "timeline" | "story" | "private" | "group") => Promise<string>
  applyShareResult: (result: any) => void
  savePost: (postId: string, collection?: string) => Promise<void>
  unsavePost: (postId: string) => Promise<void>
  hidePost: (postId: string) => Promise<void>
  markNotInterested: (postId: string) => Promise<void>
  reportPost: (postId: string, reason: string) => Promise<void>
  reportContent: (targetType: "user" | "post" | "comment" | "message" | "story" | "group", targetId: string, reason: string, details?: string) => Promise<void>
  muteUser: (userId: string) => Promise<void>
  unmuteUser: (userId: string) => Promise<void>
  restrictUser: (userId: string) => Promise<void>
  unrestrictUser: (userId: string) => Promise<void>
  followFromPost: (userId: string) => Promise<void>
  unfollowFromPost: (userId: string) => Promise<void>

  // Settings
  updateSettings: (updates: Partial<Settings>) => Promise<void>
  canViewProfile: (userId: string) => boolean
  canMessageUser: (userId: string) => boolean
  canViewStory: (ownerId: string) => boolean
  canSeeOnlineStatus: (userId: string) => boolean

  // Discovery
  swipe: (candidateId: string, action: "like" | "pass" | "superlike") => Promise<void>
  dismissMatchCelebration: () => void
  followUser: (userId: string) => Promise<void>
  addFriend: (userId: string) => Promise<void>
  reportUser: (userId: string, reason: string) => Promise<void>
  blockUser: (userId: string) => Promise<void>
  unblockUser: (userId: string) => Promise<void>
  /** Merged block list for UI filters (state + settings) */
  blockedUsers: string[]
  /** Merged mute list for UI filters (state + settings) */
  mutedUsers: string[]
  /** Returns conversation id when opened/found, or null if blocked by privacy */
  startConversation: (userId: string, userName: string, userPhoto: string) => Promise<string | null>

  // Match actions
  acceptMatch: (userId: string) => Promise<void>
  rejectMatch: (userId: string) => Promise<void>

  // Messages - unified for both private chats and group chats
  sendMessage: (conversationId: string, text: string) => Promise<void>
  editMessage: (conversationId: string, messageId: string, newText: string) => Promise<void>
  deleteMessage: (conversationId: string, messageId: string, deleteForEveryone?: boolean) => Promise<void>
  replyToMessage: (conversationId: string, replyToMessageId: string, text: string) => Promise<void>
  forwardMessage: (conversationId: string, messageId: string) => Promise<void>
  addMessageReaction: (conversationId: string, messageId: string, emoji: string) => Promise<void>
  removeMessageReaction: (conversationId: string, messageId: string, emoji: string) => Promise<void>
  pinMessage: (conversationId: string, messageId: string) => Promise<void>
  unpinMessage: (conversationId: string, messageId: string) => Promise<void>
  sendVoiceNote: (conversationId: string, audioBlob: Blob, waveform: number[]) => Promise<void>
  sendMediaMessage: (conversationId: string, mediaUrl: string, type: "image" | "file" | "video", fileName?: string) => Promise<void>
  scheduleMessage: (conversationId: string, text: string, scheduledFor: number) => Promise<void>
  sendDisappearingMessage: (conversationId: string, text: string, expiresInSeconds?: number) => Promise<void>
  saveDraft: (conversationId: string, text: string) => void
  loadDraft: (conversationId: string) => string | null
  searchMessages: (conversationId: string, query: string) => Promise<void>
  markConversationRead: (conversationId: string) => Promise<void>
  // Conversation management
  pinConversation: (conversationId: string) => Promise<void>
  unpinConversation: (conversationId: string) => Promise<void>
  archiveConversation: (conversationId: string) => Promise<void>
  unarchiveConversation: (conversationId: string) => Promise<void>
  muteConversation: (conversationId: string, muteHours?: number) => Promise<void>
  unmuteConversation: (conversationId: string) => Promise<void>
  setTypingIndicator: (conversationId: string, isTyping: boolean) => Promise<void>
  // Group / community features
  createGroup: (formData: any) => Promise<string>
  joinCommunity: (communityId: string) => Promise<boolean>
  acceptCommunityInvitation: (communityId: string) => Promise<boolean>
  declineCommunityInvitation: (communityId: string) => Promise<boolean>
  approveCommunityJoinRequest: (communityId: string, userId: string) => Promise<boolean>
  declineCommunityJoinRequest: (communityId: string, userId: string) => Promise<boolean>
  inviteCommunityMember: (communityId: string, userId: string) => Promise<boolean>
  leaveCommunity: (communityId: string) => Promise<boolean>
  requestJoinCommunity: (communityId: string) => Promise<boolean>
  replyToBoardPost: (
    communityId: string,
    postId: string,
    body: string
  ) => Promise<boolean>
  reactToBoardPost: (
    communityId: string,
    postId: string
  ) => Promise<boolean>
  pinBoardPost: (communityId: string, postId: string) => Promise<boolean>
  unpinBoardPost: (communityId: string, postId: string) => Promise<boolean>
  hideBoardPost: (communityId: string, postId: string) => Promise<boolean>
  unhideBoardPost: (communityId: string, postId: string) => Promise<boolean>
  transitionCommunityLifecycle: (
    communityId: string,
    next: "draft" | "discoverable" | "active" | "quiet" | "archived"
  ) => Promise<boolean>
  reportCommunityContent: (
    communityId: string,
    input: {
      targetType: "community" | "post" | "member"
      targetId: string
      reason: "spam" | "harassment" | "hate" | "misinformation" | "impersonation" | "safety" | "other"
      note?: string
    }
  ) => Promise<boolean>
  createCommunityAnnouncement: (
    communityId: string,
    input: { title: string; content: string; type?: "info" | "important" | "celebration" | "maintenance" }
  ) => Promise<boolean>
  createCommunityEvent: (
    communityId: string,
    input: {
      title: string
      description: string
      startTime: number
      endTime: number
      location?: string
      category?: "meeting" | "social" | "workshop" | "discussion" | "celebration"
    }
  ) => Promise<boolean>
  rsvpCommunityEvent: (communityId: string, eventId: string) => Promise<boolean>
  createBoardPost: (
    communityId: string,
    body: string,
    kind?: "text" | "question" | "resource"
  ) => Promise<boolean>
  addGroupMember: (conversationId: string, userId: string) => Promise<void>
  removeGroupMember: (conversationId: string, userId: string) => Promise<void>
  setGroupRole: (conversationId: string, userId: string, role: "admin" | "member") => Promise<void>
  updateGroupName: (conversationId: string, newName: string) => Promise<void>
  updateGroupPhoto: (conversationId: string, photoUrl: string) => Promise<void>

  // UI
  setTab: (tab: Tab) => void
  addToast: (message: string, type: "success" | "error" | "info") => void
  logout: () => Promise<void>
}

const GHCContext = createContext<GHCContextType | null>(null)

/** Domain slices — consumers using these hooks only re-render when their slice changes */
const GHCShellContext = createContext<{
  ready: boolean
  tab: Tab
  setTab: (tab: Tab) => void
  toasts: Toast[]
  addToast: (message: string, type: "success" | "error" | "info") => void
  isOnline: boolean
  networkQuality: "excellent" | "good" | "fair" | "poor" | "offline"
  matchCelebration: GHCContextType["matchCelebration"]
  dismissMatchCelebration: () => void
  startConversation: GHCContextType["startConversation"]
} | null>(null)

const GHCProfileContext = createContext<{
  profile: Profile
  settings: Settings
  friends: string[]
  following: string[]
  posts: Post[]
  updateProfile: GHCContextType["updateProfile"]
  completeOnboarding: GHCContextType["completeOnboarding"]
  updateSettings: GHCContextType["updateSettings"]
  addToast: (message: string, type: "success" | "error" | "info") => void
} | null>(null)

const GHCDiscoveryContext = createContext<{
  candidates: Candidate[]
  matches: MatchEntry[]
  following: string[]
  swipe: GHCContextType["swipe"]
  followUser: GHCContextType["followUser"]
  addFriend: GHCContextType["addFriend"]
  reportUser: GHCContextType["reportUser"]
  blockUser: GHCContextType["blockUser"]
  unblockUser: GHCContextType["unblockUser"]
  startConversation: GHCContextType["startConversation"]
  acceptMatch: GHCContextType["acceptMatch"]
  rejectMatch: GHCContextType["rejectMatch"]
  profile: Profile
} | null>(null)

const GHCMessagingContext = createContext<{
  conversations: Conversation[]
  sendMessage: GHCContextType["sendMessage"]
  markConversationRead: GHCContextType["markConversationRead"]
  pinConversation: GHCContextType["pinConversation"]
  archiveConversation: GHCContextType["archiveConversation"]
  muteConversation: GHCContextType["muteConversation"]
  createGroup: GHCContextType["createGroup"]
  joinCommunity: GHCContextType["joinCommunity"]
  leaveCommunity: GHCContextType["leaveCommunity"]
  createBoardPost: GHCContextType["createBoardPost"]
  startConversation: GHCContextType["startConversation"]
  addToast: (message: string, type: "success" | "error" | "info") => void
  profile: Profile
  setTab: (tab: Tab) => void
} | null>(null)

/** Feed / posts slice — Home re-renders only when posts/stories change */
const GHCFeedContext = createContext<{
  posts: Post[]
  stories: StoryItem[]
  likedPostIds: string[]
  following: string[]
  friends: string[]
  profile: Profile
  settings: Settings
  candidates: Candidate[]
  createPost: GHCContextType["createPost"]
  likePost: GHCContextType["likePost"]
  deletePost: GHCContextType["deletePost"]
  editPost: GHCContextType["editPost"]
  archivePost: GHCContextType["archivePost"]
  unarchivePost: GHCContextType["unarchivePost"]
  addComment: GHCContextType["addComment"]
  editComment: GHCContextType["editComment"]
  deleteComment: GHCContextType["deleteComment"]
  addCommentReaction: GHCContextType["addCommentReaction"]
  removeCommentReaction: GHCContextType["removeCommentReaction"]
  pinComment: GHCContextType["pinComment"]
  unpinComment: GHCContextType["unpinComment"]
  createQuoteRepost: GHCContextType["createQuoteRepost"]
  sharePost: GHCContextType["sharePost"]
  applyShareResult: GHCContextType["applyShareResult"]
  savePost: GHCContextType["savePost"]
  unsavePost: GHCContextType["unsavePost"]
  reportPost: GHCContextType["reportPost"]
  reportContent: GHCContextType["reportContent"]
  publishStory: GHCContextType["publishStory"]
  followUser: GHCContextType["followUser"]
  unfollowFromPost: GHCContextType["unfollowFromPost"]
  muteUser: GHCContextType["muteUser"]
  blockUser: GHCContextType["blockUser"]
  addToast: (message: string, type: "success" | "error" | "info") => void
  setTab: (tab: Tab) => void
  shares: GHCContextType["shares"]
  reposts: GHCContextType["reposts"]
  blockedUsers: string[]
} | null>(null)


// Consolidated state interface (Quick Win: reduce from 16 to 5 useState calls)
interface ConsolidatedState {
  ready: boolean
  profile: Profile
  settings: Settings
  tab: Tab
  toasts: Toast[]
  // Data collections
  posts: Post[]
  stories: StoryItem[]
  candidates: Candidate[]
  matches: MatchEntry[]
  /** Transient mutual-match confirmation (UI only) */
  matchCelebration: null | { userId: string; userName: string; userPhoto: string }
  likes: Like[]
  conversations: Conversation[]
  friendRequests: FriendRequest[]
  // User relationships (session cache; Social Graph domain owns mutations)
  following: string[]
  followers: string[]
  friends: string[]
  blockedUsers: string[]
  mutedUsers: string[]
  restrictedUsers: string[]
  likedPostIds: string[]
  feedToggle: "for-you" | "following"
  shares: import("@/lib/share-types").ShareRecord[]
  reposts: import("@/lib/share-types").RepostFeedItem[]
}

const initialState: ConsolidatedState = {
  ready: false,
  profile: defaultProfile(),
  settings: DEFAULT_SETTINGS,
  tab: "home",
  toasts: [],
  posts: [],
  stories: [],
  // Empty at boot — seed after first paint so cold start is not blocked by large arrays
  candidates: [],
  matches: [],
  matchCelebration: null,
  likes: [],
  conversations: [],
  friendRequests: [],
  following: [],
  followers: [],
  shares: [],
  reposts: [],
  friends: [],
  blockedUsers: [],
  mutedUsers: [],
  restrictedUsers: [],
  likedPostIds: [],
  feedToggle: "for-you",
}

// Extended state for network monitoring
interface ExtendedGHCState extends ConsolidatedState {
  isOnline: boolean
  networkQuality: "excellent" | "good" | "fair" | "poor" | "offline"
}

/** Canonical full session state — always includes network fields required by ExtendedGHCState */
function createDefaultExtendedState(
  overrides?: Partial<ExtendedGHCState>
): ExtendedGHCState {
  return {
    ...initialState,
    isOnline: true,
    networkQuality: "excellent",
    ...overrides,
  }
}

export function GHCProvider({ children }: { children: ReactNode }) {
  const { sdk } = usePiAuth()
  const [identityUserId, setIdentityUserId] = useState(() => IdentityService.getCurrentUserId())
  useEffect(() => {
    return IdentityService.subscribe((id) => setIdentityUserId(id.userId))
  }, [])

  const [state, setState] = useState<ExtendedGHCState>(() => createDefaultExtendedState())

  // Hydrate persisted communities into conversation list (survives reload)
  useEffect(() => {
    try {
      const persisted = loadPersistedCommunities()
      if (!persisted.length) return
      setState((s) => {
        const merged = mergeCommunityConversations(s.conversations as any, persisted)
        const liveIds = new Set(s.conversations.map((c) => c.id))
        const hasNew = persisted.some((c) => !liveIds.has(c.id))
        if (!hasNew) return s
        return { ...s, conversations: merged as typeof s.conversations }
      })
    } catch {
      /* */
    }
  }, [])

  // Apply Pi Network identity + returning-user onboarding gate when Pi.authenticate succeeds
  useEffect(() => {
    const onPi = (ev: Event) => {
      const d = (ev as CustomEvent).detail as {
        uid?: string
        username?: string | null
        accessToken?: string | null
        serverVerified?: boolean
        needsOnboarding?: boolean
        isReturning?: boolean
        onboardingStatus?: "unknown" | "required" | "complete"
      }
      if (!d?.uid) return
      setState((prev) => {
        const profile: Profile = { ...prev.profile }
        if (!profile.id || profile.id === "current-user" || profile.id === "preview-user") {
          profile.id = d.uid
        }
        if (d.username) {
          if (!profile.username) profile.username = d.username
          if (!profile.displayName) profile.displayName = d.username
        }
        // Server-authoritative onboarding (Phase 2A):
        // profile.onboarded is UI/cache only — never security proof.
        // When serverVerified AND durable, server mapping wins.
        // If the user already completed local profile registration this session,
        // do not force them back through onboarding solely because a non-durable
        // (memory) identity store still has needsOnboarding=true after PIN unlock / Pi reinit.
        if (d.serverVerified) {
          if (
            d.onboardingStatus === "complete" ||
            d.isReturning === true ||
            d.needsOnboarding === false
          ) {
            profile.onboarded = true
          } else if (d.onboardingStatus === "required" || d.needsOnboarding === true) {
            let alreadyLocal =
              profile.onboarded === true ||
              (typeof profile.displayName === "string" &&
                profile.displayName.trim().length > 0 &&
                Array.isArray(profile.photos) &&
                profile.photos.length > 0)
            // Also consult local profile store (PIN unlock / cold start race)
            if (!alreadyLocal) {
              try {
                if (isCompletedProfileShape(profile as never)) alreadyLocal = true
                const found = findCompletedLocalProfileForUser({
                  userId: String(d.uid || profile.id || ""),
                  username: d.username || (profile.username as string) || null,
                })
                if (found) {
                  alreadyLocal = true
                  // Merge stable fields so UI is not empty
                  if (!profile.displayName && found.displayName) profile.displayName = found.displayName
                  if ((!profile.photos || profile.photos.length === 0) && found.photos) {
                    profile.photos = found.photos
                  }
                  if (!profile.interests && found.interests) profile.interests = found.interests
                  if (!profile.city && found.city) profile.city = found.city
                  if (!profile.primaryMode && found.primaryMode) profile.primaryMode = found.primaryMode
                }
              } catch {
                /* */
              }
            }
            if (!alreadyLocal) {
              profile.onboarded = false
            } else {
              profile.onboarded = true
            }
          }
        }
        return { ...prev, profile }
      })
    }
    window.addEventListener("ghc:pi-identity-ready", onPi as EventListener)
    return () => window.removeEventListener("ghc:pi-identity-ready", onPi as EventListener)
  }, [])

  // Keep IdentityService aligned with profile (Pi UID always wins)
  useEffect(() => {
    const profile = state.profile as { id?: string; username?: string; displayName?: string } | undefined
    if (!profile) return
    try {
      IdentityService.setFromProfile({
        userId: profile.id || null,
        username: profile.username || null,
        displayName: profile.displayName || null,
      })
    } catch {
      /* */
    }
  }, [state.profile])

  // Setup network monitoring on mount
  useEffect(() => {
    // Monitor connection status
    const unsubscribe = connectionMonitor.subscribe((isOnline) => {
      setState((s) => ({ ...s, isOnline, networkQuality: isOnline ? "excellent" : "offline" }))
    })

    return () => unsubscribe()
  }, [])

  useEffect(() => {
    let mounted = true
    async function load() {
      try {
        // Paint shell immediately — hydrate storage in the background
        if (mounted) {
          setState((s) => ({
            ...s,
            ready: true,
            posts: s.posts?.length ? s.posts : bootstrapPosts(),
            stories: s.stories?.length ? s.stories : bootstrapStories(),
          }))
        }

        const updates: Partial<ExtendedGHCState> = { ready: true }

        if (!sdk) {
          const cands = bootstrapCandidates()
          updates.posts = bootstrapPosts()
          updates.stories = bootstrapStories()
          updates.candidates = cands
          updates.likes = bootstrapLikes(cands)
          if (mounted) setState((s) => ({ ...s, ...updates }))
          return
        }

        // Priority: identity first so onboarding gate is correct ASAP
        const [profileResult, settingsResult] = await Promise.allSettled([
          withRetry(() => sdk.state.get(STORAGE_KEYS.profile)),
          withRetry(() => sdk.state.get(STORAGE_KEYS.settings)),
        ])
        const early: Partial<ExtendedGHCState> = { ready: true }
        if (profileResult.status === "fulfilled" && profileResult.value?.blob) {
          const coerced = coerceStoredProfile(profileResult.value.blob)
          if (coerced) early.profile = coerced
        }
        if (settingsResult.status === "fulfilled" && settingsResult.value?.blob) {
          const blob = settingsResult.value.blob
          if (blob && typeof blob === "object" && !Array.isArray(blob)) {
            const loaded = blob as Partial<Settings>
            if (typeof loaded.language === "string" || typeof loaded.darkMode === "boolean") {
              const blockedUsers = Array.isArray(loaded.blockedUsers)
                ? loaded.blockedUsers.filter((id): id is string => typeof id === "string").slice(0, 200)
                : []
              early.settings = { ...DEFAULT_SETTINGS, ...loaded, blockedUsers }
              if (blockedUsers.length) early.blockedUsers = blockedUsers
            }
          }
        }
        if (mounted) setState((s) => ({ ...s, ...early }))

        // Correct key mapping — one fetch per domain (no duplicate profile/settings reads)
        const [
          postsResult,
          storiesResult,
          matchesResult,
          likesResult,
          conversationsResult,
          friendRequestsResult,
          followingResult,
        ] = await Promise.allSettled([
          withRetry(() => sdk.state.get(STORAGE_KEYS.posts)),
          withRetry(() => sdk.state.get(STORAGE_KEYS.stories)),
          withRetry(() => sdk.state.get(STORAGE_KEYS.matches)),
          withRetry(() => sdk.state.get(STORAGE_KEYS.likes)),
          withRetry(() => sdk.state.get(STORAGE_KEYS.conversations)),
          withRetry(() => sdk.state.get(STORAGE_KEYS.friendRequests)),
          withRetry(() => sdk.state.get(STORAGE_KEYS.following)),
        ])

        // Profile / settings already loaded above — only fill gaps
        if (!updates.profile && profileResult.status === "fulfilled") {
          const loaded = coerceStoredProfile(profileResult.value?.blob)
          if (loaded?.displayName) updates.profile = loaded
        } else if (profileResult.status === "rejected") {
          errorLogger.logWarning("Profile load failed, using defaults", { error: profileResult.reason })
        }

        if (!updates.settings && settingsResult.status === "fulfilled") {
          const blob = settingsResult.value?.blob
          if (blob && typeof blob === "object" && !Array.isArray(blob)) {
            const loaded = blob as Partial<Settings>
            if (loaded.language) {
              const blockedUsers = Array.isArray(loaded.blockedUsers)
                ? loaded.blockedUsers.filter((id): id is string => typeof id === "string").slice(0, 200)
                : []
              const moderationReports = Array.isArray(loaded.moderationReports)
                ? loaded.moderationReports
                    .filter(
                      (report) =>
                        report &&
                        (report.type === "user" ||
                          report.type === "post" ||
                          report.type === "comment" ||
                          report.type === "message" ||
                          report.type === "story" ||
                          report.type === "group") &&
                        typeof report.targetId === "string"
                    )
                    .slice(-200)
                : []
              updates.settings = { ...DEFAULT_SETTINGS, ...loaded, blockedUsers, moderationReports }
              updates.blockedUsers = blockedUsers
            }
          }
        } else if (settingsResult.status === "rejected") {
          errorLogger.logWarning("Settings load failed, using defaults", { error: settingsResult.reason })
        }

        if (postsResult.status === "fulfilled") {
          const loaded = postsResult.value?.blob as Post[] | undefined
          updates.posts = Array.isArray(loaded)
            ? loaded.map((post) => ({
                ...post,
                content: typeof post?.content === "string" ? post.content : "",
                authorName: typeof post?.authorName === "string" ? post.authorName : "Pi Member",
                images: Array.isArray(post?.images)
                  ? post.images.filter((image): image is string => typeof image === "string")
                  : [],
                comments: Array.isArray(post?.comments) ? post.comments : [],
              }))
            : bootstrapPosts()
        } else {
          errorLogger.logWarning("Posts load failed, using empty collection", { error: postsResult.reason })
          updates.posts = bootstrapPosts()
        }

        if (storiesResult.status === "fulfilled" && Array.isArray(storiesResult.value?.blob)) {
          updates.stories = sanitizeStories(storiesResult.value.blob)
        } else {
          updates.stories = bootstrapStories()
        }
        if (matchesResult.status === "fulfilled" && Array.isArray(matchesResult.value?.blob)) {
          updates.matches = matchesResult.value.blob as MatchEntry[]
        } else if (matchesResult.status === "rejected") {
          errorLogger.logWarning("matches load failed, using empty state", { error: matchesResult.reason })
        }
        // Discovery candidates — light seed only if still empty (after first paint path)
        const cands = bootstrapCandidates()
        updates.candidates = cands
        if (likesResult.status === "fulfilled" && Array.isArray(likesResult.value?.blob)) {
          const loadedLikes = likesResult.value.blob as Like[]
          updates.likes =
            loadedLikes.length > 0 ? loadedLikes : bootstrapLikes(cands)
          updates.likedPostIds = (updates.likes as Like[])
            .filter((like) => like?.fromUserId === "current-user" && typeof like.toUserId === "string")
            .map((like) => like.toUserId)
        } else if (likesResult.status === "rejected") {
          errorLogger.logWarning("likes load failed, using empty state", { error: likesResult.reason })
          updates.likes = bootstrapLikes(cands)
        } else {
          updates.likes = bootstrapLikes(cands)
        }
        if (conversationsResult.status === "fulfilled" && Array.isArray(conversationsResult.value?.blob)) {
          updates.conversations = conversationsResult.value.blob as Conversation[]
        } else if (conversationsResult.status === "rejected") {
          errorLogger.logWarning("conversations load failed, using empty state", { error: conversationsResult.reason })
        }
        if (friendRequestsResult.status === "fulfilled" && Array.isArray(friendRequestsResult.value?.blob)) {
          updates.friendRequests = friendRequestsResult.value.blob as FriendRequest[]
        } else if (friendRequestsResult.status === "rejected") {
          errorLogger.logWarning("friend requests load failed, using empty state", { error: friendRequestsResult.reason })
        }
        if (followingResult.status === "fulfilled" && Array.isArray(followingResult.value?.blob)) {
          updates.following = (followingResult.value.blob as string[]).filter(
            (id) => typeof id === "string"
          )
        }

        if (mounted) setState((s) => ({ ...s, ...updates }))
      } catch (err) {
        errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
        if (mounted) setState((s) => ({ ...s, ready: true, posts: bootstrapPosts(), stories: bootstrapStories() })) // prod: empty
      }
    }

    load()
    return () => {
      mounted = false
    }
  }, [sdk])

  useEffect(() => {
    if (!state.ready || typeof window === "undefined") return
    const activeId = getActiveLocalProfileId()
    const localCandidates = readLocalProfiles()
      .filter((profile) => profile.localId !== activeId)
      .map(profileToLocalCandidate)
    setState((current) => ({
      ...current,
      candidates: [
        ...current.candidates.filter((candidate) => !candidate.id.startsWith("local-")),
        ...localCandidates,
      ],
    }))
  }, [state.ready, state.profile])


  // Hydrate social graph slices (following / friends / block / mute) so they survive refresh
  useEffect(() => {
    if (!sdk || !state.ready) return
    let cancelled = false
    ;(async () => {
      try {
        const [followingR, friendsR, blockedR, mutedR] = await Promise.allSettled([
          withRetry(() => sdk.state.get(STORAGE_KEYS.following)),
          withRetry(() => sdk.state.get(STORAGE_KEYS.friends)),
          withRetry(() => sdk.state.get(STORAGE_KEYS.blockedUsers)),
          withRetry(() => sdk.state.get(STORAGE_KEYS.mutedUsers)),
        ])
        if (cancelled) return
        setState((s) => {
          const next = { ...s }
          if (followingR.status === "fulfilled" && Array.isArray(followingR.value?.blob)) {
            next.following = followingR.value.blob.filter((id: unknown) => typeof id === "string")
          }
          if (friendsR.status === "fulfilled" && Array.isArray(friendsR.value?.blob)) {
            next.friends = friendsR.value.blob.filter((id: unknown) => typeof id === "string")
          }
          if (blockedR.status === "fulfilled" && Array.isArray(blockedR.value?.blob)) {
            const blocked = blockedR.value.blob.filter((id: unknown) => typeof id === "string")
            next.blockedUsers = blocked
            next.settings = { ...next.settings, blockedUsers: blocked }
          }
          if (mutedR.status === "fulfilled" && Array.isArray(mutedR.value?.blob)) {
            next.mutedUsers = mutedR.value.blob.filter((id: unknown) => typeof id === "string")
          }
          return next
        })
      } catch {
        /* non-fatal */
      }
    })()
    return () => {
      cancelled = true
    }
  }, [sdk, state.ready])

  // Durable social hydrate (posts / stories / follows) — server authoritative when configured
  useEffect(() => {
    if (!state.ready) return
    let cancelled = false
    ;(async () => {
      try {
        const {
          socialFetchFeed,
          socialFetchStories,
          socialFetchFollows,
        } = await import("@/lib/social/client")
        const [feed, stories, follows] = await Promise.all([
          socialFetchFeed({ limit: 40 }),
          socialFetchStories(),
          socialFetchFollows(),
        ])
        if (cancelled) return
        setState((s) => {
          const next = { ...s }
          if (feed.ok && feed.durable && Array.isArray(feed.posts) && feed.posts.length > 0) {
            const remotePosts = feed.posts.map((p) => ({
              id: String(p.id),
              authorId: String(p.authorId || ""),
              authorName: String(p.authorName || "Member"),
              authorPhoto: String(p.authorPhoto || ""),
              content: String(p.content || ""),
              images: Array.isArray(p.images) ? (p.images as string[]) : [],
              video: (p.video as string | null) ?? null,
              pdf: (p.pdf as string | null) ?? null,
              pdfName: (p.pdfName as string | null) ?? null,
              likes: Number(p.likes) || 0,
              comments: Array.isArray(p.comments) ? p.comments : [],
              createdAt: Number(p.createdAt) || Date.now(),
              visibility: (p.visibility as Post["visibility"]) || "public",
              deletedAt: p.deletedAt ? Number(p.deletedAt) : null,
            })) as Post[]
            // Prefer durable remote; keep local-only posts not yet synced
            const remoteIds = new Set(remotePosts.map((p) => p.id))
            const localOnly = s.posts.filter(
              (p) => !remoteIds.has(p.id) && !p.deletedAt
            )
            next.posts = [...remotePosts, ...localOnly].sort(
              (a, b) => (b.createdAt || 0) - (a.createdAt || 0)
            )
            const liked = feed.posts
              .filter((p) => (p as { likedByMe?: boolean }).likedByMe)
              .map((p) => String(p.id))
            if (liked.length) {
              next.likedPostIds = Array.from(
                new Set([...(s.likedPostIds || []), ...liked])
              )
            }
          }
          if (stories.ok && stories.durable && Array.isArray(stories.stories)) {
            next.stories = stories.stories.map((st) => ({
              id: String(st.id),
              ownerId: st.ownerId ? String(st.ownerId) : undefined,
              name: String(st.name || "Member"),
              photo: st.photo ? String(st.photo) : undefined,
              text: String(st.text || ""),
              media: st.media as StoryItem["media"],
              createdAt: Number(st.createdAt) || Date.now(),
              expiresAt: st.expiresAt ? Number(st.expiresAt) : undefined,
              audience: st.audience as StoryItem["audience"],
              status: (st.status as StoryItem["status"]) || "published",
            }))
          }
          if (follows.ok && follows.durable) {
            if (Array.isArray(follows.following)) next.following = follows.following
            if (Array.isArray(follows.followers)) next.followers = follows.followers
          }
          return next
        })
      } catch {
        /* studio / offline */
      }
    })()
    return () => {
      cancelled = true
    }
  }, [state.ready])

  // Durable messaging hydrate — conversations list when server has membership rows
  useEffect(() => {
    if (!state.ready) return
    let cancelled = false
    ;(async () => {
      try {
        const { apiListConversations } = await import("@/lib/messaging/server-messaging-sync")
        const res = await apiListConversations(50)
        if (cancelled || !res?.ok || !res.durable) return
        const remote = Array.isArray(res.conversations) ? res.conversations : []
        if (!remote.length) return
        setState((s) => {
          const byId = new Map(s.conversations.map((c) => [c.id, c]))
          for (const r of remote) {
            const id = String(r.id || "")
            if (!id) continue
            const existing = byId.get(id)
            const remoteMembers = Array.isArray(r.memberIds)
              ? r.memberIds.map(String)
              : []
            const members =
              remoteMembers.length > 0
                ? remoteMembers
                : existing?.members || existing?.memberIds || []
            const preview =
              typeof r.lastMessagePreview === "string" ? r.lastMessagePreview : ""
            const lastAt =
              typeof r.lastMessageAt === "number" && Number.isFinite(r.lastMessageAt)
                ? r.lastMessageAt
                : existing?.lastMessageTime || Date.now()
            const updatedAt =
              typeof r.updatedAt === "number" && Number.isFinite(r.updatedAt)
                ? r.updatedAt
                : existing?.updatedAt || lastAt
            // Fallback object only when existing is missing (do not reference existing inside it).
            byId.set(id, {
              ...(existing || {
                id,
                participantId: "",
                participantName: r.title || "Chat",
                participantPhoto: "/placeholder.svg?width=40&height=40",
                messages: [],
                lastMessage: "",
                lastMessageTime: lastAt,
                unread: false,
                online: false,
                conversationType: "private" as const,
                members: [],
                memberIds: [],
                name: r.title || "Chat",
                unreadCount: 0,
                updatedAt: lastAt,
              }),
              id,
              members,
              memberIds: members,
              name: r.title || existing?.name || existing?.groupName || existing?.participantName || "Chat",
              groupName: r.title || existing?.groupName || existing?.name,
              updatedAt,
              lastMessage: preview || existing?.lastMessage || "",
              lastMessageTime: lastAt,
            })
          }
          return {
            ...s,
            conversations: Array.from(byId.values()).sort(
              (a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)
            ),
          }
        })
      } catch {
        /* offline */
      }
    })()
    return () => {
      cancelled = true
    }
  }, [state.ready])

  // Save existing user-state slices together after startup restoration.
  useEffect(() => {
    if (!sdk || !state.ready) return
    const {
      profile,
      settings,
      posts,
      matches,
      likes,
      conversations,
      friendRequests,
      following,
      friends,
      blockedUsers,
      mutedUsers,
    } = state
    if (!profile.onboarded) return

    const timer = setTimeout(async () => {
      try {
        const results = await Promise.allSettled([
          withRetry(() => sdk.state.set(STORAGE_KEYS.profile, profile)),
          withRetry(() => sdk.state.set(STORAGE_KEYS.settings, settings)),
          withRetry(() => sdk.state.set(STORAGE_KEYS.posts, posts)),
          withRetry(() => sdk.state.set(STORAGE_KEYS.matches, matches)),
          withRetry(() => sdk.state.set(STORAGE_KEYS.likes, likes)),
          withRetry(() => sdk.state.set(STORAGE_KEYS.conversations, conversations)),
          withRetry(() => sdk.state.set(STORAGE_KEYS.friendRequests, friendRequests)),
          withRetry(() => sdk.state.set(STORAGE_KEYS.following, following || [])),
          withRetry(() => sdk.state.set(STORAGE_KEYS.friends, friends || [])),
          withRetry(() =>
            sdk.state.set(STORAGE_KEYS.blockedUsers, blockedUsers || settings?.blockedUsers || []),
          ),
          withRetry(() => sdk.state.set(STORAGE_KEYS.mutedUsers, mutedUsers || [])),
        ])
        const failed = results.filter((result) => result.status === "rejected")
        if (failed.length > 0) {
          console.warn(`[v0] ${failed.length} state slice(s) could not be saved; memory retained for retry`)
        }
      } catch (e) {
        console.warn("[v0] State save failed; keeping the current in-memory state:", e)
      }
    }, 1500)
    return () => clearTimeout(timer)
  }, [
    state.ready,
    state.profile,
    state.settings,
    state.posts,
    state.matches,
    state.likes,
    state.conversations,
    state.friendRequests,
    state.following,
    state.friends,
    state.blockedUsers,
    state.mutedUsers,
    sdk,
  ])

  // Stories have their own slower write lane so media never competes with the rest of the app.
  useEffect(() => {
    if (!sdk || !state.ready || !state.profile.onboarded) return
    const timer = setTimeout(() => {
      withRetry(() => sdk.state.set(STORAGE_KEYS.stories, sanitizeStories(state.stories))).catch(() => {
        console.warn("[v0] Stories could not be saved; keeping the latest stories in memory")
      })
    }, 5000)
    return () => clearTimeout(timer)
  }, [sdk, state.ready, state.profile.onboarded, state.stories])

  // Define addToast first - it's used by other functions
  const addToast = useCallback((message: string, type: "success" | "error" | "info") => {
    const id = generateId()
    setState((s) => ({ ...s, toasts: [...s.toasts, { id, message, type }] }))
    setTimeout(() => {
      setState((s) => ({ ...s, toasts: s.toasts.filter((t) => t.id !== id) }))
    }, 3000)
  }, [])


  // Cross-device profile hydrate — server is authoritative when durable row exists.
  // Must run after Pi/server session is ready; early calls before auth return empty.
  useEffect(() => {
    let cancelled = false
    const hydrateFromServer = async () => {
      try {
        const uid = IdentityService.getCurrentUserId?.() || state.profile?.id
        if (!uid || uid === "current-user") return
        const result = await fetchServerProfile()
        if (cancelled || !result.ok || !result.profile) return
        setState((s) => {
          const server = result.profile as Partial<Profile>
          // Durable server row is authority: honor explicit empty arrays / false onboarded.
          // Non-durable or offline: keep local cache to avoid flash-wipe.
          const durable = result.durable && result.exists
          const photos =
            durable && Array.isArray(server.photos)
              ? server.photos
              : Array.isArray(server.photos) && server.photos.length > 0
                ? server.photos
                : s.profile.photos
          const coverPhoto =
            durable && (server.coverPhoto === null || server.coverPhoto === "")
              ? ""
              : typeof server.coverPhoto === "string" && server.coverPhoto.length > 0
                ? server.coverPhoto
                : s.profile.coverPhoto
          const onboarded = durable
            ? Boolean(server.onboarded)
            : Boolean(server.onboarded) || Boolean(s.profile.onboarded)
          return {
            ...s,
            profile: {
              ...s.profile,
              ...server,
              id: (server.id as string) || s.profile.id,
              photos,
              coverPhoto,
              onboarded,
            },
          }
        })
      } catch {
        /* offline */
      }
    }
    void hydrateFromServer()
    const onPiReady = () => {
      void hydrateFromServer()
    }
    if (typeof window !== "undefined") {
      window.addEventListener("ghc:pi-identity-ready", onPiReady as EventListener)
    }
    return () => {
      cancelled = true
      if (typeof window !== "undefined") {
        window.removeEventListener("ghc:pi-identity-ready", onPiReady as EventListener)
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- hydrate on profile id + after Pi identity ready
  }, [state.profile?.id])

  const updateProfile = async (updates: Partial<Profile>) => {
    try {
      // UX-layer validation (compatibility); domain re-validates on mutate path
      if (updates.displayName && !validation.isValidName(updates.displayName)) {
        addToast("Invalid name format", "error")
        return
      }
      if (updates.bio && !validation.isValidBio(updates.bio)) {
        addToast("Bio must be between 10 and 500 characters", "error")
        return
      }
      if (updates.age && !validation.isValidAge(updates.age)) {
        addToast("Age must be between 18 and 120", "error")
        return
      }
      if (
        updates.displayName &&
        updates.bio &&
        spamDetection.isSpammyProfile(updates.bio, updates.displayName)
      ) {
        addToast("Your profile update was flagged as spam", "error")
        return
      }

      const sanitized: Partial<Profile> = {
        ...updates,
        displayName: updates.displayName ? sanitizeDisplayName(updates.displayName) : undefined,
        bio: updates.bio ? sanitizeText(updates.bio, 500) : undefined,
      }

      // Canonical Identity domain mutation
      const result = await domains.identity.updateProfile(sanitized)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }

      setState((s) => ({ ...s, profile: { ...s.profile, ...result.data } }))

      // Durable social profile (server). Await so reload can hydrate photos/fields.
      // Failures do not roll back local UX; queue offline sync when needed.
      try {
        const persisted = await persistServerProfile({ ...result.data })
        if (!persisted.ok && state.isOnline) {
          offlineQueue.addAction({
            type: "profile_update",
            payload: result.data,
            maxRetries: 3,
          })
        }
      } catch {
        offlineQueue.addAction({
          type: "profile_update",
          payload: result.data,
          maxRetries: 3,
        })
      }

      if (!state.isOnline) {
        offlineQueue.addAction({
          type: "profile_update",
          payload: result.data,
          maxRetries: 3,
        })
        addToast("Profile queued for sync", "info")
        return
      }

      analytics.trackEvent("profile_update", { fields: Object.keys(updates) }, state.profile.displayName)
      addToast("Profile updated", "success")
    } catch (error) {
      errorLogger.logError(error instanceof Error ? error : new Error(String(error)))
      addToast("Failed to update profile", "error")
    }
  }

  const completeOnboarding = async () => {
    try {
      const result = await domains.identity.completeOnboarding()
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      // Persist on server identity bridge (Pi-verified mapping).
      // Client state advances only after authoritative success (or local-dev fallback).
      let serverOk = false
      try {
        const headers = {
          "Content-Type": "application/json",
          ...IdentityService.getAuthHeaders(),
        }
        const res = await fetch("/api/auth/onboarding-complete", {
          method: "POST",
          headers,
          credentials: "include",
        })
        const body = await res.json().catch(() => ({}))
        serverOk = Boolean(res.ok && body?.ok && body?.identity?.onboardingCompleted === true)
        if (!serverOk) {
          console.warn("[completeOnboarding] server did not confirm", body?.error || res.status)
        }
      } catch (e) {
        console.warn("[completeOnboarding] network error", e)
      }

      const { allowLocalAuthFallback } = await import("@/lib/system-config")
      if (!serverOk && !allowLocalAuthFallback()) {
        addToast(
          "Could not save onboarding on the server. Please check your connection and try again.",
          "error"
        )
        return
      }

      IdentityService.setOnboardingCompleted()
      const profile = { ...state.profile, onboarded: true as const }
      try {
        if (typeof window !== "undefined") {
          window.localStorage.setItem("ghc.profile", JSON.stringify(profile))
        }
      } catch {
        /* */
      }
      setState((s) => ({ ...s, profile: { ...s.profile, onboarded: true as const } }))
      // Await durable social profile so reload/login restores name, photos, fields
      try {
        await persistServerProfile({ ...profile, onboarded: true })
      } catch {
        /* offline — local cache still holds this session */
      }
    } catch (error) {
      errorLogger.logError(error instanceof Error ? error : new Error(String(error)))
      addToast("Onboarding could not be completed. Please try again.", "error")
    }
  }

  const switchLocalProfile = (localId: string) => {
    const profile = findLocalProfile(localId)
    if (!profile) return
    setActiveLocalProfileId(localId)
    const otherLocals = readLocalProfiles()
      .filter((item) => item.localId !== localId)
      .map(profileToLocalCandidate)
    setState((current) => ({
      ...current,
      profile,
      candidates: [
        ...current.candidates.filter(
          (candidate) => !candidate.id.startsWith("local-") && candidate.id !== localId
        ),
        ...otherLocals,
      ],
    }))
  }

  const createLocalProfile = (profile: Partial<Profile>) => {
    // Identity domain builds the record; local-profiles API persists it
    const next = domains.identity.buildLocalProfile(profile)
    setActiveLocalProfileId(next.localId)
    writeLocalProfile(next)
    setState((current) => ({
      ...current,
      profile: next,
      candidates: [
        ...current.candidates.filter((candidate) => !candidate.id.startsWith("local-")),
        ...readLocalProfiles()
          .filter((item) => item.localId !== next.localId)
          .map(profileToLocalCandidate),
      ],
    }))
  }

  const createPost = async (
    content: string,
    images: string[],
    video: string | null,
    pdf: string | null,
    pdfName: string | null,
    audience: "public" | "followers" | "mutuals" | "private" = "public",
    community?: { id: string; name: string } | null,
  ): Promise<boolean> => {
    try {
      // Rate limit check
      if (!postLimiter.isAllowed(`post_${state.profile.displayName}`)) {
        addToast("Too many posts. Please wait before posting again.", "error")
        return false
      }

      const safeContent = typeof content === "string" ? content : ""
      // Spam detection must receive a guaranteed string, even if an older caller sends nullish data.
      if (spamDetection.detectSpamText(safeContent)) {
        addToast("Your post was flagged as spam. Please review it.", "error")
        return false
      }

      const safeImages = Array.isArray(images) ? images.filter((image): image is string => typeof image === "string") : []
      const safeVideo = typeof video === "string" ? video : null
      const safePdf = typeof pdf === "string" ? pdf : null
      const safePdfName = typeof pdfName === "string" ? pdfName : null
      const visibility =
        audience === "followers" || audience === "mutuals" || audience === "private"
          ? audience
          : "public"
      // Validation: text-only posts still require text; media posts may omit it.
      const hasMedia = safeImages.length > 0 || Boolean(safeVideo) || Boolean(safePdf)
      if ((!safeContent.trim() && !hasMedia) || safeContent.length > 5000) {
        addToast("Add text, a photo, or a video before posting", "error")
        return false
      }

      // Sanitize content (XSS prevention); always normalize to a string for feed renderers.
      const sanitizedContent = String(sanitizeText(safeContent, 5000) || "")

      // Canonical domain path (validate → audience → event)
      const domainResult = await domains.posts.createPost({
        content: sanitizedContent,
        images: safeImages,
        video: safeVideo,
        pdf: safePdf,
        pdfName: safePdfName,
        visibility,
        communityId: community?.id,
        communityName: community?.name,
      })
      if (!domainResult.ok) {
        addToast(domainResult.error || "Failed to create post", "error")
        return false
      }
      const newPost = domainResult.data

      setState((s) => ({ ...s, posts: [newPost, ...s.posts] }))

      // Durable write — server is authoritative when Supabase social core is applied
      try {
        const { socialCreatePost } = await import("@/lib/social/client")
        const remote = await socialCreatePost({
          id: newPost.id,
          content: newPost.content,
          images: newPost.images,
          video: newPost.video,
          pdf: newPost.pdf,
          pdfName: newPost.pdfName,
          visibility: newPost.visibility || visibility,
          authorName: newPost.authorName,
          authorPhoto: newPost.authorPhoto,
          communityId: newPost.communityId,
          communityName: newPost.communityName,
          contentType: newPost.contentType,
          listingId: newPost.listingId,
          listingKind: newPost.listingKind,
        })
        if (remote.ok && remote.durable && remote.post?.id && remote.post.id !== newPost.id) {
          setState((s) => ({
            ...s,
            posts: s.posts.map((p) =>
              p.id === newPost.id ? { ...p, id: String(remote.post!.id) } : p
            ),
          }))
        }
      } catch {
        /* offline / studio — local session remains until durable path available */
      }

      // Queue for sync if offline
      if (!state.isOnline) {
        offlineQueue.addAction({
          type: "create_post",
          payload: newPost,
          maxRetries: 3,
        })
        addToast("Post queued - will upload when online", "info")
        return true
      }

      // Track analytics
      analytics.trackEvent(
        "post_created",
        { postId: newPost.id, visibility },
        state.profile.displayName,
      )

      // Notification
      notificationSystem.addNotification("share", "Posted", "Your post is live on Feed", "✓", { open: "feed", section: "post" })
      addToast("Posted to your feed", "success")
      return true
    } catch (error) {
      errorLogger.logError(error instanceof Error ? error : new Error(String(error)))
      addToast("Failed to create post", "error")
      return false
    }
  }

  const likePost = async (postId: string) => {
    // Optimistic local toggle
    setState((s) => {
      const isLiked = s.likedPostIds.includes(postId)
      const nextLikedPostIds = isLiked
        ? s.likedPostIds.filter((id) => id !== postId)
        : [...s.likedPostIds, postId]
      const nextLikes = isLiked
        ? s.likes.filter(
            (like) =>
              !(like.fromUserId === "current-user" && like.toUserId === postId)
          )
        : [
            ...s.likes,
            {
              id: generateId(),
              fromUserId: "current-user",
              toUserId: postId,
              createdAt: Date.now(),
            },
          ]
      return {
        ...s,
        posts: s.posts.map((post) =>
          post.id === postId
            ? { ...post, likes: Math.max(0, post.likes + (isLiked ? -1 : 1)) }
            : post
        ),
        likes: nextLikes,
        likedPostIds: nextLikedPostIds,
      }
    })
    // Durable reconcile
    try {
      const { socialToggleLike } = await import("@/lib/social/client")
      const remote = await socialToggleLike(postId)
      if (remote.ok && remote.durable && typeof remote.likeCount === "number") {
        setState((s) => ({
          ...s,
          posts: s.posts.map((post) =>
            post.id === postId ? { ...post, likes: remote.likeCount as number } : post
          ),
          likedPostIds:
            remote.liked === false
              ? s.likedPostIds.filter((id) => id !== postId)
              : s.likedPostIds.includes(postId)
                ? s.likedPostIds
                : [...s.likedPostIds, postId],
        }))
      }
    } catch {
      /* local-only */
    }
  }


  const getDomainState = useCallback(() => ({
    profile: state.profile,
    posts: state.posts,
    stories: state.stories || [],
    following: state.following || [],
    followers: state.followers || [],
    blockedUsers: Array.from(
      new Set([...(state.settings?.blockedUsers || []), ...(state.blockedUsers || [])])
    ),
    mutedUsers: state.mutedUsers || state.settings?.mutedUsers || [],
    restrictedUsers: state.restrictedUsers || state.settings?.restrictedUsers || [],
    matches: state.matches || [],
    likes: state.likes || [],
    friends: state.friends || [],
    outgoingFriendRequestIds: (state.friendRequests || [])
      .filter((r: any) => {
        const me = IdentityService.getCurrentUserId()
        return r.fromUserId === me || r.fromUserId === "current-user" || r.toUserId
      })
      .map((r: any) => r.toUserId || r.fromUserId)
      .filter(Boolean),
    incomingFriendRequestIds: (state.friendRequests || [])
      .map((r) => r.fromUserId)
      .filter((id) => {
        const me = IdentityService.getCurrentUserId()
        return id && id !== me && id !== "current-user"
      }),
    candidates: state.candidates || [],
    conversations: state.conversations || [],
  }), [state])

  const domains: DomainServices = useMemo(
    () =>
      createDomainServices(getDomainState, {
        currentUserId: IdentityService.getCurrentUserId(),
        onReportPersist: (report) => {
          try {
            recordModerationReport?.(report.targetType, report.targetId, report.reason)
          } catch { /* */ }
        },
        getConversations: () => getDomainState().conversations,
        setConversations: (updater) => {
          setState((s) => ({ ...s, conversations: updater(s.conversations || []) }))
        },
      }),
    [getDomainState, identityUserId]
  )

  // Migration foundation: non-React adapters can resolve active domain services
  useEffect(() => {
    bindDomainServices(domains)
    return () => bindDomainServices(null)
  }, [domains])

  // Canonical notifications: domain events → preference-aware delivery
  useEffect(() => {
    const stop = domains.notifications.startEventBridge()
    return () => {
      stop()
      domains.notifications.stopEventBridge()
    }
  }, [domains])

  // Economy reward engine: domain events → eligibility / ledger
  useEffect(() => {
    const stop = domains.economy.startRewardEventBridge()
    return () => {
      stop()
      domains.economy.stopRewardEventBridge()
    }
  }, [domains])

  // Reputation + Achievements bridges (separate from GHC)
  useEffect(() => {
    const stopRep = domains.reputation.startEventBridge()
    const stopAch = domains.achievements.startEventBridge()
    return () => {
      stopRep()
      stopAch()
      domains.reputation.stopEventBridge()
      domains.achievements.stopEventBridge()
    }
  }, [domains])

  // Keep social-graph-store edges aligned with session relationship cache
  useEffect(() => {
    if (!state.ready) return
    syncSessionEdgesToStore("current-user", {
      following: state.following || [],
      friends: state.friends || [],
      blockedUsers: Array.from(
        new Set([...(state.blockedUsers || []), ...(state.settings?.blockedUsers || [])])
      ),
      mutedUsers: state.mutedUsers || state.settings?.mutedUsers || [],
      restrictedUsers: state.restrictedUsers || state.settings?.restrictedUsers || [],
      matches: state.matches || [],
    })
  }, [
    state.ready,
    state.following,
    state.friends,
    state.blockedUsers,
    state.mutedUsers,
    state.restrictedUsers,
    state.matches,
    state.settings?.blockedUsers,
    state.settings?.mutedUsers,
    state.settings?.restrictedUsers,
  ])

  // Realtime: domain events → local cache reconcile + transport bridge
  useEffect(() => {
    const unsub = subscribeDomainCache((event) => {
      if (process.env.NODE_ENV !== "production") {
        console.debug("[domain-event]", event.type, event.payload)
      }
      // Apply remote/local domain events into React state (live UI)
      const p = (event.payload || {}) as Record<string, any>
      switch (event.type) {
        case "POST_CREATED":
          // Own creates already write state; remote posts arrive via transport
          if (p.post && event.actorId !== "current-user") {
            setState((s) => {
              if (s.posts.some((x) => x.id === p.post.id)) return s
              return { ...s, posts: [p.post as Post, ...s.posts] }
            })
          }
          break
        case "POST_DELETED":
          if (p.postId) {
            setState((s) => ({
              ...s,
              posts: s.posts.filter((x) => x.id !== p.postId),
            }))
          }
          break
        case "LIKE_ADDED":
        case "LIKE_REMOVED":
          if (p.postId) {
            setState((s) => ({
              ...s,
              posts: s.posts.map((post) =>
                post.id === p.postId
                  ? {
                      ...post,
                      likes: Math.max(
                        0,
                        (post.likes || 0) + (event.type === "LIKE_ADDED" ? 1 : -1),
                      ),
                    }
                  : post,
              ),
            }))
          }
          break
        case "COMMENT_CREATED":
          if (p.postId && p.comment) {
            setState((s) => ({
              ...s,
              posts: s.posts.map((post) =>
                post.id === p.postId
                  ? { ...post, comments: [...(post.comments || []), p.comment] }
                  : post,
              ),
            }))
          }
          break
        case "MESSAGE_CREATED":
          if (p.conversationId && p.message) {
            setState((s) => ({
              ...s,
              conversations: (s.conversations || []).map((c) => {
                if (c.id !== p.conversationId) return c
                const exists = (c.messages || []).some((m: any) => m.id === p.message.id)
                if (exists) return c
                return {
                  ...c,
                  messages: [...(c.messages || []), p.message],
                  lastMessage: p.message.text,
                  lastMessageTime: p.message.createdAt || Date.now(),
                  unread: event.actorId !== "current-user",
                }
              }),
            }))
          }
          break
        case "FOLLOW_CREATED":
          if (p.userId && event.actorId === "current-user") {
            setState((s) =>
              s.following.includes(p.userId)
                ? s
                : { ...s, following: [...s.following, p.userId] },
            )
          }
          break
        case "FOLLOW_REMOVED":
          if (p.userId) {
            setState((s) => ({
              ...s,
              following: s.following.filter((id) => id !== p.userId),
            }))
          }
          break
        case "BLOCK_CREATED":
          if (p.userId) {
            setState((s) => ({
              ...s,
              blockedUsers: s.blockedUsers.includes(p.userId)
                ? s.blockedUsers
                : [...s.blockedUsers, p.userId],
            }))
          }
          break
        default:
          break
      }
    })
    transportBridge.startLocal()
    try {
            const { presenceStore } = require("@/lib/realtime/presence")
      presenceStore.setSelf("current-user")
      presenceStore.startHeartbeat(30_000)
    } catch {
      /* optional */
    }
    try {
            const { resolveApiBaseUrl } = require("@/lib/domains/http-repositories")
            const { enableWebSocketTransport } = require("@/lib/realtime/transport-bridge")
      const base = resolveApiBaseUrl()
      if (base) {
        const wsUrl = base.replace(/^http/, "ws") + "/realtime"
        void enableWebSocketTransport(wsUrl)
      }
    } catch {
      /* stay on LocalTransport */
    }
    return () => {
      unsub()
      try {
                const { presenceStore } = require("@/lib/realtime/presence")
        presenceStore.stopHeartbeat()
      } catch {
        /* */
      }
    }
  }, [])

  const deletePost = async (postId: string) => {
    try {
      const result = await domains.posts.deletePost(postId)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      const deleted = result.data.post
      setState((s) => ({
        ...s,
        posts: s.posts.map((p) => (p.id === postId ? { ...p, ...deleted } : p)),
      }))
      try {
        const { socialDeletePost } = await import("@/lib/social/client")
        await socialDeletePost(postId)
      } catch {
        /* local soft-delete still applied */
      }
      addToast("Post deleted", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Could not delete post", "error")
    }
  }

  const addComment = async (postId: string, text: string, replyToCommentId?: string) => {
    const normalizedText = sanitizeText(text, 500).trim()
    if (!normalizedText) {
      addToast("Comment cannot be empty", "error")
      return
    }
    try {
      // Validate reply target exists (orphans still allowed by domain, but UX clearer)
      if (replyToCommentId) {
        const post = state.posts.find((p) => p.id === postId)
        const parentExists = post?.comments?.some((c) => c.id === replyToCommentId)
        if (!parentExists) {
          addToast("Original comment was removed", "error")
          return
        }
      }
      const result = await domains.posts.addComment(postId, normalizedText, replyToCommentId)
      if (!result.ok) {
        addToast(result.error || "Could not post comment", "error")
        return
      }
      const newComment = result.data
      if (!newComment?.id) {
        addToast("Could not post comment", "error")
        return
      }
      setState((s) => ({
        ...s,
        posts: s.posts.map((post) => {
          if (post.id !== postId) return post
          const existing = Array.isArray(post.comments) ? post.comments : []
          // Dedupe by id (preferred) or near-duplicate text from same user
          if (existing.some((c) => c.id === newComment.id)) return post
          const duplicate = existing.some(
            (comment) =>
              comment.authorId === "current-user" &&
              (comment.text ?? "").trim().toLowerCase() === normalizedText.toLowerCase() &&
              Date.now() - (comment.createdAt || 0) < 5000
          )
          if (duplicate) return post
          // Flat list only — buildCommentTree nests via replyTo (no dual-write)
          return {
            ...post,
            comments: [
              ...existing,
              {
                ...newComment,
                replyTo: replyToCommentId || newComment.replyTo,
                replies: [],
              },
            ],
          }
        }),
      }))
      try {
        const { socialAddComment } = await import("@/lib/social/client")
        await socialAddComment(postId, {
          id: newComment.id,
          text: normalizedText,
          authorName: newComment.authorName,
          authorPhoto: newComment.authorPhoto,
          parentId: replyToCommentId,
        })
      } catch {
        /* local comment remains until durable path available */
      }
      addToast(replyToCommentId ? "Reply posted" : "Comment posted", "success")
    } catch (err) {
      try {
        errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      } catch {
        /* logger must never block UX */
      }
      addToast("Could not post comment", "error")
    }
  }

  const editPost = async (postId: string, newContent: string) => {
    try {
      const result = await domains.posts.editPost(postId, newContent)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => ({
        ...s,
        posts: s.posts.map((post) =>
          post.id === postId
            ? {
                ...post,
                content: result.data.content,
                isDraft: false,
                isEdited: true,
                editedAt: Date.now(),
              }
            : post
        ),
      }))
      try {
        const { socialEditPost } = await import("@/lib/social/client")
        await socialEditPost(postId, result.data.content)
      } catch {
        /* local edit remains until durable path available */
      }
      addToast("Post updated", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Could not update post", "error")
    }
  }

  const archivePost = async (postId: string) => {
    setState((s) => ({
      ...s,
      posts: s.posts.map((post) =>
        post.id === postId
          ? { ...post, isArchived: true, archivedAt: Date.now() }
          : post
      ),
    }))
    addToast("Post archived", "success")
  }

  const unarchivePost = async (postId: string) => {
    setState((s) => ({
      ...s,
      posts: s.posts.map((post) =>
        post.id === postId
          ? { ...post, isArchived: false, archivedAt: undefined }
          : post
      ),
    }))
    addToast("Post restored from archive", "success")
  }

  const editComment = async (postId: string, commentId: string, newText: string) => {
    const normalized = (newText || "").trim()
    if (!normalized) {
      addToast("Comment cannot be empty", "error")
      return
    }
    try {
      const result = await domains.posts.editComment(postId, commentId, normalized)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => ({
        ...s,
        posts: s.posts.map((p) =>
          p.id === postId
            ? {
                ...p,
                comments: p.comments.map((c) =>
                  c.id === commentId
                    ? { ...c, text: result.data.text, isEdited: true, editedAt: Date.now() }
                    : c
                ),
              }
            : p
        ),
      }))
      addToast("Comment updated", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Could not edit comment", "error")
    }
  }

  const deleteComment = async (postId: string, commentId: string) => {
    try {
      const result = await domains.posts.deleteComment(postId, commentId)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => ({
        ...s,
        posts: s.posts.map((p) =>
          p.id === postId
            ? {
                ...p,
                comments: p.comments.filter(
                  (c) => c.id !== commentId && c.replyTo !== commentId
                ),
              }
            : p
        ),
      }))
      addToast("Comment deleted", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Could not delete comment", "error")
    }
  }

  const addCommentReaction = async (postId: string, commentId: string, emoji: string) => {
    try {
      const result = await domains.posts.reactToComment(postId, commentId, emoji)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => ({
        ...s,
        posts: s.posts.map((post) =>
          post.id === postId
            ? {
                ...post,
                comments: post.comments.map((c) =>
                  c.id === commentId ? { ...c, reactions: result.data.reactions } : c
                ),
              }
            : post
        ),
      }))
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Could not react to comment", "error")
    }
  }

  const removeCommentReaction = async (postId: string, commentId: string, emoji: string) => {
    setState((s) => ({
      ...s,
      posts: s.posts.map((post) =>
        post.id === postId
          ? {
              ...post,
              comments: post.comments.map((c) => {
                if (c.id === commentId) {
                  const reactions = { ...c.reactions }
                  if (reactions[emoji]) {
                    reactions[emoji] = reactions[emoji].filter((id) => id !== s.profile.displayName)
                    if (reactions[emoji].length === 0) delete reactions[emoji]
                  }
                  return { ...c, reactions }
                }
                return c
              }),
            }
          : post
      ),
    }))
  }

  const pinComment = async (postId: string, commentId: string) => {
    setState((s) => ({
      ...s,
      posts: s.posts.map((post) =>
        post.id === postId
          ? {
              ...post,
              comments: post.comments.map((c) => (c.id === commentId ? { ...c, isPinned: true } : c)),
            }
          : post
      ),
    }))
    addToast("Comment pinned", "success")
  }

  const unpinComment = async (postId: string, commentId: string) => {
    setState((s) => ({
      ...s,
      posts: s.posts.map((post) =>
        post.id === postId
          ? {
              ...post,
              comments: post.comments.map((c) => (c.id === commentId ? { ...c, isPinned: false } : c)),
            }
          : post
      ),
    }))
    addToast("Comment unpinned", "success")
  }

  const createQuoteRepost = async (originalPostId: string, quoteText: string) => {
    const originalPost = state.posts.find((p) => p.id === originalPostId)
    if (!originalPost) {
      addToast("Original post not found", "error")
      return
    }
    const newPost: Post = {
      id: generateId(),
      authorId: "current-user",
      authorName: state.profile.displayName || "You",
      authorPhoto: state.profile.photos[0] || "/placeholder.svg?width=32&height=32",
      content: quoteText,
      images: [],
      video: null,
      pdf: null,
      pdfName: null,
      likes: 0,
      comments: [],
      createdAt: Date.now(),
      quoteOf: originalPostId,
    }
    setState((s) => ({ ...s, posts: [newPost, ...s.posts] }))
    addToast("Quote repost created", "success")
  }

  const sharePost = async (
    postId: string,
    platform: "twitter" | "facebook" | "linkedin" | "copy" | "timeline" | "story" | "private" | "group" = "copy"
  ) => {
    // Legacy external platforms still supported; internal shares use ShareService via ShareSheet
    const { ShareService } = await import("@/lib/share-service")
    const ctx = {
      currentUserId: IdentityService.getCurrentUserId(),
      blockedUsers: state.settings?.blockedUsers || state.blockedUsers || [],
      posts: state.posts,
      conversations: state.conversations,
    }
    if (platform === "copy" || platform === "twitter" || platform === "facebook" || platform === "linkedin") {
      const result = ShareService.copyPostLink(ctx, postId)
      if (!result.ok) {
        addToast(result.error, "error")
        return ""
      }
      setState((s) => ({ ...s, shares: [result.share, ...(s.shares || [])].slice(0, 200) }))
      addToast("Link copied", "success")
      return result.link || ""
    }
    return ""
  }

  const applyShareResult = (result: import("@/lib/share-service").ShareResult) => {
    if (!result.ok) return
    setState((s) => {
      let conversations = s.conversations
      if (result.messages?.length) {
        conversations = s.conversations.map((c) => {
          const batch = result.messages!.filter((m) => m.conversationId === c.id)
          if (!batch.length) return c
          const newMsgs = batch.map((m) => ({
            id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
            senderId: "current-user",
            text: m.text,
            createdAt: Date.now(),
            sharedPostId: m.sharedPostId,
            status: "sent" as const,
          }))
          return {
            ...c,
            messages: [...(c.messages || []), ...newMsgs],
            lastMessage: newMsgs[newMsgs.length - 1]?.text || c.lastMessage,
            lastMessageTime: Date.now(),
          }
        })
      }
      let stories = s.stories
      if (result.story) {
        stories = [result.story as any, ...(s.stories || [])]
      }
      return {
        ...s,
        shares: [result.share, ...(s.shares || [])].slice(0, 200),
        reposts: result.repost ? [result.repost, ...(s.reposts || [])].slice(0, 100) : s.reposts,
        conversations,
        stories,
      }
    })
  }

  const savePost = async (postId: string, collection?: string) => {
    setState((s) => ({
      ...s,
      posts: s.posts.map((post) =>
        post.id === postId
          ? { ...post, bookmarkedBy: [...(post.bookmarkedBy || []), s.profile.displayName] }
          : post
      ),
    }))
    addToast("Post saved", "success")
  }

  const unsavePost = async (postId: string) => {
    setState((s) => ({
      ...s,
      posts: s.posts.map((post) =>
        post.id === postId
          ? {
              ...post,
              bookmarkedBy: (post.bookmarkedBy || []).filter((name) => name !== s.profile.displayName),
            }
          : post
      ),
    }))
    addToast("Post removed from saved", "success")
  }

  const hidePost = async (postId: string) => {
    setState((s) => ({
      ...s,
      posts: s.posts.map((post) =>
        post.id === postId ? { ...post, hideCount: (post.hideCount || 0) + 1 } : post
      ),
    }))
    addToast("Post hidden", "success")
  }

  const markNotInterested = async (postId: string) => {
    setState((s) => ({
      ...s,
      posts: s.posts.filter((p) => p.id !== postId),
    }))
    addToast("Marked as not interested", "success")
  }

  const recordModerationReport = useCallback((type: "user" | "post" | "comment" | "message" | "story" | "group", targetId: string, reason: string) => {
    const normalizedReason = reason.trim().slice(0, 160) || "Other"
    setState((s) => {
      const existing = s.settings.moderationReports || []
      const alreadyReported = existing.some((report) => report.type === type && report.targetId === targetId)
      if (alreadyReported) return s
      return {
        ...s,
        settings: {
          ...s.settings,
          moderationReports: [...existing, { type, targetId, reason: normalizedReason, createdAt: Date.now() }].slice(-200),
        },
      }
    })
  }, [])

  const reportPost = async (postId: string, reason: string) => {
    try {
      const result = await domains.reports.report("post", postId, reason)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      recordModerationReport("post", postId, reason)
      addToast("Post reported for review", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Could not submit report", "error")
    }
  }

  const reportContent = useCallback(async (
    targetType: "user" | "post" | "comment" | "message" | "story" | "group",
    targetId: string,
    reason: string,
    details?: string
  ) => {
    try {
      const result = await domains.reports.report(targetType, targetId, reason, details)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      recordModerationReport(targetType, targetId, reason)
      const labels: Record<string, string> = {
        user: "user",
        post: "post",
        comment: "comment",
        message: "message",
        story: "story",
        group: "community",
      }
      addToast(`Thank you. We'll review this ${labels[targetType] || "content"}.`, "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Could not submit report", "error")
    }
  }, [addToast, recordModerationReport, domains])


  const muteUser = async (userId: string) => {
    try {
      const result = await domains.graph.muteUser(userId)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => applyGraphPatch(s, patchFromMute(result.data)))
      addToast("User muted", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error muting user", "error")
    }
  }

  const unmuteUser = async (userId: string) => {
    try {
      const result = await domains.graph.unmuteUser(userId)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => applyGraphPatch(s, patchFromMute(result.data)))
      addToast("User unmuted", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error unmuting user", "error")
    }
  }

  const restrictUser = async (userId: string) => {
    try {
      const result = await domains.graph.restrictUser(userId)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => applyGraphPatch(s, patchFromRestrict(result.data)))
      addToast("User restricted", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error restricting user", "error")
    }
  }

  const unrestrictUser = async (userId: string) => {
    try {
      const result = await domains.graph.unrestrictUser(userId)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => applyGraphPatch(s, patchFromRestrict(result.data)))
      addToast("Restriction removed", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error updating restriction", "error")
    }
  }

  const followFromPost = async (userId: string) => {
    // Canonical: same path as followUser (graph domain)
    await followUser(userId)
  }

  const unfollowFromPost = async (userId: string) => {
    // Canonical: toggleFollow via graph — never dual-write following alone
    await followUser(userId)
  }

  const updateSettings = async (updates: Partial<Settings>) => {
    setState((s) => ({ ...s, settings: { ...s.settings, ...updates } }))
  }

  const isMatchOrFriend = (userId: string) => state.matches.some((match) => match.userId === userId) || state.friends.includes(userId)
  const canViewProfile = (userId: string) => userId === "current-user" || state.settings.profileVisibility === "everyone" || (state.settings.profileVisibility === "matches-only" && isMatchOrFriend(userId))
  const canMessageUser = (userId: string) => {
    if (userId === "current-user") return false
    const blocked = new Set([...(state.settings?.blockedUsers || []), ...(state.blockedUsers || [])])
    if (blocked.has(userId)) return false
    if (state.settings.whoCanMessage === "no-one") return false
    if (state.settings.whoCanMessage === "matches-only" && !isMatchOrFriend(userId)) return false
    return true
  }
  const canViewStory = (ownerId: string) => ownerId === "current-user" || state.settings.storyVisibility === "everyone" || (state.settings.storyVisibility === "matches-only" && isMatchOrFriend(ownerId))
  const canSeeOnlineStatus = (userId: string) => userId === "current-user" || state.settings.onlineStatus === "everyone" || (state.settings.onlineStatus === "matches-only" && isMatchOrFriend(userId))

  const swipe = useCallback(async (candidateId: string, action: "like" | "pass" | "superlike") => {
    try {
      const candidate = state.candidates.find((c) => c.id === candidateId)
      if (!candidate) return

      if (action === "like" || action === "superlike") {
        const interest = await domains.matching.expressInterest(candidateId, {
          superlike: action === "superlike",
        })
        if (!interest.ok) {
          addToast(interest.error, "error")
          return
        }

        const quality = domains.matching.evaluateQuality(candidate)
        const now = Date.now()
        let createdMatch: (typeof state.matches)[number] | null = null
        let alreadyMatched = interest.data.alreadyMatched

        setState((s) => {
          const alreadyLiked = s.likes.some(
            (like) => like.fromUserId === "current-user" && like.toUserId === candidateId
          )
          const hasMutualLike = s.likes.some(
            (like) => like.fromUserId === candidateId && like.toUserId === "current-user"
          )
          const existingMatch = s.matches.find((match) => match.userId === candidateId)
          if (existingMatch) {
            alreadyMatched = true
            return alreadyLiked
              ? s
              : {
                  ...s,
                  likes: [
                    ...s.likes,
                    {
                      id: generateId(),
                      fromUserId: "current-user",
                      toUserId: candidateId,
                      createdAt: now,
                    },
                  ],
                }
          }
          const nextLikes = alreadyLiked
            ? s.likes
            : [
                ...s.likes,
                {
                  id: generateId(),
                  fromUserId: "current-user",
                  toUserId: candidateId,
                  createdAt: now,
                },
              ]
          // Mutual consent only — does not add to friends[]
          if (!hasMutualLike) return { ...s, likes: nextLikes }

          createdMatch = {
            id: generateId(),
            userId: candidateId,
            userName: candidate.name,
            userPhoto: candidate.photo || "/placeholder.svg?height=80&width=80",
            matchedAt: now,
            online: candidate.online,
            intentions: quality.sharedIntentions.length
              ? quality.sharedIntentions
              : domains.matching.openIntentions(),
            reasons: quality.reasons.slice(0, 3),
            qualityScore: quality.score,
          }
          const existingConversation = s.conversations.find(
            (conversation) =>
              conversation.conversationType === "private" &&
              conversation.participantId === candidateId
          )
          const matchConversation: Conversation = existingConversation || {
            id: `match-${candidateId}`,
            participantId: candidateId,
            participantName: candidate.name,
            participantPhoto: candidate.photo || "/placeholder.svg?height=80&width=80",
            messages: [],
            lastMessage: "You matched — say hello!",
            lastMessageTime: now,
            unread: false,
            online: Boolean(candidate.online),
            conversationType: "private",
          }
          // Dedupe: never add a second match for the same userId
          const priorMatches = (s.matches || []).filter((m) => m.userId !== candidateId)
          return {
            ...s,
            likes: nextLikes,
            matches: [...priorMatches, createdMatch],
            matchCelebration: {
              userId: candidateId,
              userName: candidate.name,
              userPhoto: candidate.photo || "/placeholder.svg?height=80&width=80",
            },
            // Explicit: friends/connections unchanged
            conversations: existingConversation
              ? s.conversations
              : [matchConversation, ...s.conversations],
          }
        })

        analytics.trackEvent("swipe_action", { action, candidateId }, state.profile.displayName)

        if (createdMatch && !alreadyMatched) {
          await domains.graph.addMatch(candidateId).catch(() => null)
          notificationSystem.addNotification(
            "match",
            "It's a Match",
            `You and ${candidate.name} both expressed interest`,
            "💚",
            { candidateId, candidateName: candidate.name }
          )
          // Confirmation UI is driven by matchCelebration — avoid reward/earnings language
          addToast("It's a Match — mutual interest", "success")
        } else if (alreadyMatched) {
          addToast("You're already matched", "info")
        } else {
          addToast(
            action === "superlike" ? "Interest sent" : "Interest sent — not a Match until they like you too",
            "success",
          )
        }
      } else {
        addToast("Passed", "info")
      }
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error processing action", "error")
    }
  }, [state.candidates, state.profile.displayName, state.likes, state.matches, domains, addToast])

  

const dismissMatchCelebration = useCallback(() => {
    setState((s) => (s.matchCelebration ? { ...s, matchCelebration: null } : s))
  }, [])

  const followUser = useCallback(async (userId: string) => {
    try {
      const already = (state.following || []).includes(userId)
      if (!already) {
        const matchIds = (state.matches || []).map((m) => m.userId)
        const friendIds = state.friends || []
        if (!privacyCanFollow(state.settings, "current-user", userId, matchIds, friendIds)) {
          addToast("Follow is limited by privacy settings", "info")
          return
        }
      }
      const result = await domains.graph.toggleFollow(userId)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => applyGraphPatch(s, patchFromFollow(result.data)))
      addToast(
        result.data.action === "follow" ? "Following" : "Unfollowed",
        result.data.action === "follow" ? "success" : "info"
      )
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error following user", "error")
    }
  }, [domains, addToast, state.following, state.matches, state.friends, state.settings])

  const addFriend = useCallback(async (userId: string) => {
    try {
      if (state.friends.includes(userId)) {
        const result = await domains.graph.removeFriend(userId)
        if (!result.ok) {
          addToast(result.error, "error")
          return
        }
        setState((s) => applyGraphPatch(s, patchFromFriendRemoved(result.data)))
        addToast("Removed from friends", "info")
        return
      }
      const result = await domains.graph.sendFriendRequest(userId)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      const cand = bootstrapCandidates().find((c) => c.id === userId)
      const newRequest = {
        id: generateId(),
        fromUserId: "current-user",
        fromUserName: state.profile.displayName || "You",
        fromUserPhoto: state.profile.photos?.[0] || "/placeholder.svg?width=40&height=40",
        toUserId: userId,
        toUserName: cand?.name || "User",
        createdAt: Date.now(),
      }
      setState((s) => ({
        ...s,
        friendRequests: [
          ...(s.friendRequests || []).filter(
            (r) => !(r.fromUserId === "current-user" && r.toUserId === userId)
          ),
          newRequest as any,
        ],
      }))
      addToast("Friend request sent!", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error adding friend", "error")
    }
  }, [state.friends, state.friendRequests, state.profile, domains, addToast])

  const reportUser = useCallback(async (userId: string, reason: string) => {
    try {
      recordModerationReport("user", userId, reason)
      addToast("Thank you for reporting. We'll review this user.", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error submitting report", "error")
    }
  }, [addToast, recordModerationReport])

  const blockUser = useCallback(async (userId: string) => {
    try {
      if (!userId || userId === "current-user") return
      const result = await domains.graph.applyBlock(userId)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) =>
        applyGraphPatch(
          s,
          patchFromBlock({
            ...(result.data as any),
            friends: (result.data as any).friends ?? (s.friends || []).filter((id) => id !== userId),
          })
        )
      )
      addToast("User blocked — hidden from feed, discovery, matches, and messaging", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error blocking user", "error")
    }
  }, [domains, addToast])

  const unblockUser = useCallback(async (userId: string) => {
    try {
      const result = await domains.graph.removeBlock(userId)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => applyGraphPatch(s, patchFromUnblock(result.data)))
      addToast("User unblocked", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error unblocking user", "error")
    }
  }, [domains, addToast])


  const startConversation = useCallback(async (userId: string, userName: string, userPhoto: string): Promise<string | null> => {
    try {
      if (!canMessageUser(userId)) {
        addToast(state.settings.whoCanMessage === "no-one" ? "Messaging is turned off in your privacy settings." : "This person cannot be messaged with your current privacy settings.", "info")
        return null
      }
      const existingConv = state.conversations.find(c => c.participantId === userId && c.conversationType === "private")
      if (existingConv) {
        setState((s) => ({ ...s, tab: "messages" as Tab }))
        return existingConv.id
      }

      const result = await domains.messaging.createConversation({
        kind: "private",
        participantId: userId,
        participantName: userName,
        participantPhoto: userPhoto,
      })
      if (!result.ok) {
        addToast(result.error, "error")
        return null
      }
      const newConversation = {
        ...result.data.conversation,
        online: true,
      } as Conversation

      setState((s) => ({
        ...s,
        conversations: [newConversation, ...s.conversations],
        tab: "messages" as Tab,
      }))
      return newConversation.id
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error starting conversation", "error")
      return null
    }
  }, [state.conversations, state.settings.whoCanMessage, domains, addToast])

  const acceptMatch = useCallback(async (userId: string) => {
    try {
      const result = await domains.graph.addMatch(userId)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => {
        const cand = s.candidates.find((c) => c.id === userId)
        return applyGraphPatch(
          s,
          patchFromMatchIds(result.data.matchIds, s.matches || [], (id) => ({
            id: `match-${id}`,
            userId: id,
            userName: cand?.name || "Match",
            userPhoto: cand?.photo || "/placeholder.svg?width=40&height=40",
            matchedAt: Date.now(),
            online: Boolean(cand?.online),
          }))
        )
      })
      addToast("Match accepted!", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error accepting match", "error")
    }
  }, [domains, addToast])

  const rejectMatch = useCallback(async (userId: string) => {
    try {
      const result = await domains.graph.removeMatch(userId)
      if (!result.ok) {
        // Still remove from session list for UX even if edge missing
        setState((s) => ({
          ...s,
          matches: (s.matches || []).filter((m) => m.userId !== userId),
        }))
        addToast("Request declined", "info")
        return
      }
      setState((s) =>
        applyGraphPatch(s, patchFromMatchIds(result.data.matchIds, s.matches || []))
      )
      addToast("Request declined", "info")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Error declining match", "error")
    }
  }, [domains, addToast])

  const sendMessage = useCallback(async (conversationId: string, text: string) => {
    try {
      if (!messageLimiter.isAllowed(`msg_${conversationId}`)) {
        addToast("You're messaging too fast. Please slow down.", "error")
        return
      }

      const safeText = typeof text === "string" ? text : ""
      if (spamDetection.detectSpamText(safeText)) {
        addToast("Your message was flagged as spam.", "error")
        return
      }

      const sanitizedText = String(sanitizeText(safeText, 5000) || "").trim()
      if (!sanitizedText) {
        addToast("Message cannot be empty", "error")
        return
      }

      const csrfToken = getCsrfToken()

      const result = await domains.messaging.sendMessage({
        conversationId,
        text: sanitizedText,
        offline: !state.isOnline,
      })
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }

      const uiMessage = (result.data as any).uiMessage || {
        id: result.data.id,
        senderId: result.data.senderId || "current-user",
        text: sanitizedText,
        createdAt: result.data.createdAt || Date.now(),
        status: state.isOnline ? "sent" : "sending",
      }

      setState((s) => ({
        ...s,
        conversations: (s.conversations || []).map((c) => {
          if (c.id !== conversationId) return c
          const existing = Array.isArray(c.messages) ? c.messages : []
          if (existing.some((m) => m.id === uiMessage.id)) {
            return {
              ...c,
              lastMessage: uiMessage.text,
              lastMessageTime: uiMessage.createdAt || Date.now(),
            }
          }
          return {
            ...c,
            messages: [...existing, uiMessage],
            lastMessage: uiMessage.text,
            lastMessageTime: uiMessage.createdAt || Date.now(),
            unread: false,
            unreadCount: 0,
          }
        }),
      }))

      analytics.trackEvent("message_sent", { conversationId }, state.profile.displayName)

      if (!state.isOnline) {
        offlineQueue.addAction({
          type: "send_message",
          payload: {
            conversationId,
            text: sanitizedText,
            csrfToken,
            messageId: result.data.id,
          },
          maxRetries: 3,
        })
        addToast("Message queued — will send when online", "info")
        return
      }

      await domains.messaging
        .setMessageStatus(conversationId, result.data.id, "delivered")
        .catch(() => null)
      setState((s) => ({
        ...s,
        conversations: (s.conversations || []).map((c) => {
          if (c.id !== conversationId) return c
          return {
            ...c,
            messages: (c.messages || []).map((m) =>
              m.id === uiMessage.id ? { ...m, status: "delivered" as const } : m,
            ),
          }
        }),
      }))
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Failed to send message", "error")
    }
  }, [domains, state.isOnline, state.profile.displayName, addToast])

  const markConversationRead = useCallback(
    async (conversationId: string) => {
      // Skip work when already read — avoids full list remap freezes
      let alreadyRead = false
      const me = (() => {
        try {
          return IdentityService.getCurrentUserId() || "current-user"
        } catch {
          return "current-user"
        }
      })()
      setState((s) => {
        const current = (s.conversations || []).find((c) => c.id === conversationId)
        if (current && !current.unread && !(current.unreadCount && current.unreadCount > 0)) {
          alreadyRead = true
          return s
        }
        const now = Date.now()
        return {
          ...s,
          conversations: (s.conversations || []).map((c) => {
            if (c.id !== conversationId) return c
            return {
              ...c,
              unread: false,
              unreadCount: 0,
              // Advance peer-sent messages to read so the sender sees ✓✓ when sharing state
              messages: (c.messages || []).map((m) => {
                const fromPeer =
                  m.senderId && m.senderId !== me && m.senderId !== "current-user"
                if (!fromPeer) return m
                if (m.status === "sent" || m.status === "delivered" || !m.status) {
                  return {
                    ...m,
                    status: "read" as const,
                    readAt: now,
                    readBy: Array.from(
                      new Set([...((m as { readBy?: string[] }).readBy || []), me]),
                    ),
                  }
                }
                return m
              }),
            }
          }),
        }
      })
      if (alreadyRead) return
      try {
        await domains.messaging.markRead(conversationId)
      } catch {
        /* local state already cleared */
      }
    },
    [domains]
  )

  // Unified message operations - reused by both Messages (private) and Chat (group)
  const editMessage = useCallback(async (conversationId: string, messageId: string, newText: string) => {
    try {
      const result = await domains.messaging.editMessage({
        conversationId,
        messageId,
        newText,
      })
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => ({
        ...s,
        conversations: s.conversations.map((c) =>
          c.id === conversationId
            ? {
                ...c,
                messages: c.messages.map((m) =>
                  m.id === messageId ? result.data.message : m
                ),
              }
            : c
        ),
      }))
      analytics.trackEvent("message_edited", { conversationId, messageId }, state.profile.displayName)
      addToast("Message updated", "success")
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("Cannot edit this message", "error")
    }
  }, [domains, state.profile.displayName, addToast])

  const deleteMessage = useCallback(
    async (conversationId: string, messageId: string, deleteForEveryone: boolean = false) => {
      const conv = state.conversations.find((c) => c.id === conversationId)
      if (!conv) return

      const message = conv.messages.find((m) => m.id === messageId)
      if (!message) return

      try {
        const result = await domains.messaging.deleteMessage(
          {
            id: message.id,
            senderId: message.senderId,
            createdAt: message.createdAt,
            conversationId,
          },
          deleteForEveryone ? "for_everyone" : "for_me"
        )
        if (!result.ok) {
          addToast(result.error, "error")
          return
        }
        if (result.data.message) {
          setState((s) => ({
            ...s,
            conversations: s.conversations.map((c) =>
              c.id === conversationId
                ? {
                    ...c,
                    messages: c.messages.map((m) =>
                      m.id === messageId ? (result.data.message as typeof m) : m
                    ),
                  }
                : c
            ),
          }))
        }
        analytics.trackEvent(
          "message_deleted",
          { conversationId, messageId, deleteForEveryone },
          state.profile.displayName
        )
        addToast(deleteForEveryone ? "Message deleted for everyone" : "Message deleted", "success")
      } catch (err) {
        errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
        addToast("Failed to delete message", "error")
      }
    },
    [state.conversations, state.profile.displayName, domains, addToast]
  )

  const replyToMessage = useCallback(
    async (conversationId: string, replyToMessageId: string, text: string) => {
      const conv = state.conversations.find((c) => c.id === conversationId)
      if (!conv) return

      const replyMessage = handleMessageReply(
        conv.messages.find((m) => m.id === replyToMessageId)!,
        text,
        "current-user"
      )
      if (!replyMessage) {
        addToast("Invalid reply message", "error")
        return
      }

      setState((s) => ({
        ...s,
        conversations: s.conversations.map((c) =>
          c.id === conversationId
            ? {
                ...c,
                messages: [...c.messages, replyMessage],
                lastMessage: text,
                lastMessageTime: Date.now(),
              }
            : c
        ),
      }))

      analytics.trackEvent("message_replied", { conversationId, replyToMessageId }, state.profile.displayName)
      addToast("Reply sent", "success")
    },
    [state.conversations, state.profile.displayName, addToast]
  )

  const forwardMessage = useCallback(
    async (conversationId: string, messageId: string) => {
      const conv = state.conversations.find((c) => c.id === conversationId)
      if (!conv) return

      const message = conv.messages.find((m) => m.id === messageId)
      if (!message) return

      const forwarded = handleMessageForwarding(message, "current-user")
      if (!forwarded) {
        addToast("Cannot forward this message", "error")
        return
      }

      setState((s) => ({
        ...s,
        conversations: s.conversations.map((c) =>
          c.id === conversationId
            ? {
                ...c,
                messages: [...c.messages, forwarded],
                lastMessage: message.text,
                lastMessageTime: Date.now(),
              }
            : c
        ),
      }))

      analytics.trackEvent("message_forwarded", { conversationId, messageId }, state.profile.displayName)
      addToast("Message forwarded", "success")
    },
    [state.conversations, state.profile.displayName, addToast]
  )

  const addMessageReaction = useCallback(
    async (conversationId: string, messageId: string, emoji: string) => {
      setState((s) => ({
        ...s,
        conversations: s.conversations.map((c) =>
          c.id === conversationId
            ? {
                ...c,
                messages: c.messages.map((m) =>
                  m.id === messageId ? handleMessageReaction(m, emoji, "current-user", true) : m
                ),
              }
            : c
        ),
      }))

      analytics.trackEvent("reaction_added", { conversationId, messageId, emoji }, state.profile.displayName)
    },
    [state.profile.displayName]
  )

  const removeMessageReaction = useCallback(
    async (conversationId: string, messageId: string, emoji: string) => {
      setState((s) => ({
        ...s,
        conversations: s.conversations.map((c) =>
          c.id === conversationId
            ? {
                ...c,
                messages: c.messages.map((m) =>
                  m.id === messageId ? handleMessageReaction(m, emoji, "current-user", false) : m
                ),
              }
            : c
        ),
      }))

      analytics.trackEvent("reaction_removed", { conversationId, messageId, emoji }, state.profile.displayName)
    },
    [state.profile.displayName]
  )

  const pinMessage = useCallback(async (conversationId: string, messageId: string) => {
    setState((s) => ({
      ...s,
      conversations: s.conversations.map((c) =>
        c.id === conversationId
          ? { ...c, messages: c.messages.map((m) => (m.id === messageId ? { ...m, isPinned: true } : m)) }
          : c
      ),
    }))
    addToast("Message pinned", "success")
  }, [addToast])

  const unpinMessage = useCallback(async (conversationId: string, messageId: string) => {
    setState((s) => ({
      ...s,
      conversations: s.conversations.map((c) =>
        c.id === conversationId
          ? { ...c, messages: c.messages.map((m) => (m.id === messageId ? { ...m, isPinned: false } : m)) }
          : c
      ),
    }))
    addToast("Message unpinned", "success")
  }, [addToast])

  const sendVoiceNote = useCallback(
    async (conversationId: string, audioBlob: Blob, waveform: number[]) => {
      try {
        const message = await createVoiceNoteMessage(audioBlob, waveform, "current-user")
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) =>
            c.id === conversationId
              ? { ...c, messages: [...c.messages, message], lastMessage: "🎤 Voice message", lastMessageTime: Date.now() }
              : c
          ),
        }))
        analytics.trackEvent("voice_note_sent", { conversationId }, state.profile.displayName)
        addToast("Voice note sent", "success")
      } catch (error) {
        errorLogger.logError(error instanceof Error ? error : new Error(String(error)))
        addToast("Failed to send voice note", "error")
      }
    },
    [state.profile.displayName, state.conversations, addToast]
  )

  const sendMediaMessage = useCallback(
    async (conversationId: string, mediaUrl: string, type: "image" | "file" | "video", fileName?: string) => {
      const message: Message = {
        id: generateId(),
        senderId: "current-user",
        text: type === "image" ? "📷 Sent a photo" : type === "video" ? "🎥 Sent a video" : `📎 ${fileName || "File"}`,
        createdAt: Date.now(),
        status: "sending",
        mediaAttachments: [{ id: generateId(), type, url: mediaUrl, fileName }],
      }

      setState((s) => ({
        ...s,
        conversations: s.conversations.map((c) =>
          c.id === conversationId
            ? { ...c, messages: [...c.messages, message], lastMessage: message.text, lastMessageTime: Date.now() }
            : c
        ),
      }))

      analytics.trackEvent("media_sent", { conversationId, type }, state.profile.displayName)
      addToast(`${type === "image" ? "Photo" : type === "video" ? "Video" : "File"} sent`, "success")
    },
    [state.profile.displayName, state.conversations, addToast]
  )

  const scheduleMessage = useCallback(
    async (conversationId: string, text: string, scheduledFor: number) => {
      const message: Message = {
        id: generateId(),
        senderId: "current-user",
        text,
        createdAt: Date.now(),
        status: "sending",
        scheduledFor,
      }

      setState((s) => ({
        ...s,
        conversations: s.conversations.map((c) =>
          c.id === conversationId ? { ...c, messages: [...c.messages, message] } : c
        ),
      }))

      analytics.trackEvent("message_scheduled", { conversationId }, state.profile.displayName)
      addToast("Message scheduled", "success")
    },
    [state.profile.displayName, state.conversations, addToast]
  )

  const sendDisappearingMessage = useCallback(
    async (conversationId: string, text: string, expiresInSeconds: number = 300) => {
      const message: Message = {
        id: generateId(),
        senderId: "current-user",
        text,
        createdAt: Date.now(),
        status: "sending",
        expiresIn: expiresInSeconds,
        expiresAt: Date.now() + expiresInSeconds * 1000,
      }

      setState((s) => ({
        ...s,
        conversations: s.conversations.map((c) =>
          c.id === conversationId
            ? { ...c, messages: [...c.messages, message], lastMessage: text, lastMessageTime: Date.now() }
            : c
        ),
      }))

      analytics.trackEvent("disappearing_message_sent", { conversationId }, state.profile.displayName)
      addToast("Disappearing message sent", "success")
    },
    [state.profile.displayName, state.conversations, addToast]
  )

  const saveDraft = useCallback((conversationId: string, text: string) => {
    draftStorage.save(conversationId, text)
  }, [])

  const loadDraft = useCallback((conversationId: string): string | null => {
    const draft = draftStorage.load(conversationId)
    return draft?.text || null
  }, [])

  /** Context API: run in-conversation message search via unified engine (no side effects). */
  const searchMessages = useCallback(
    async (conversationId: string, query: string) => {
      const conv = state.conversations.find((c) => c.id === conversationId)
      if (!conv) return
      searchMessagesInThread(conv.messages || [], { query })
    },
    [state.conversations]
  )

  const pinConversation = useCallback(async (conversationId: string) => {
    setState((s) => ({
      ...s,
      conversations: s.conversations.map((c) => (c.id === conversationId ? toggleConversationPin(c) : c)),
    }))
    addToast("Conversation pinned", "success")
  }, [addToast])

  const unpinConversation = useCallback(async (conversationId: string) => {
    setState((s) => ({
      ...s,
      conversations: s.conversations.map((c) => (c.id === conversationId ? toggleConversationPin(c) : c)),
    }))
    addToast("Conversation unpinned", "success")
  }, [addToast])

  const archiveConversation = useCallback(async (conversationId: string) => {
    setState((s) => ({
      ...s,
      conversations: s.conversations.map((c) => (c.id === conversationId ? toggleConversationArchive(c) : c)),
    }))
    addToast("Conversation archived", "success")
  }, [addToast])

  const unarchiveConversation = useCallback(async (conversationId: string) => {
    setState((s) => ({
      ...s,
      conversations: s.conversations.map((c) => (c.id === conversationId ? toggleConversationArchive(c) : c)),
    }))
    addToast("Conversation unarchived", "success")
  }, [addToast])

  const muteConversation = useCallback(async (conversationId: string, muteHours: number = 1) => {
    setState((s) => ({
      ...s,
      conversations: s.conversations.map((c) => (c.id === conversationId ? toggleConversationMute(c, muteHours) : c)),
    }))
    addToast(`Notifications muted for ${muteHours} hour${muteHours > 1 ? "s" : ""}`, "success")
  }, [addToast])

  const unmuteConversation = useCallback(async (conversationId: string) => {
    setState((s) => ({
      ...s,
      conversations: s.conversations.map((c) => (c.id === conversationId ? toggleConversationMute(c, 0) : c)),
    }))
    addToast("Notifications unmuted", "success")
  }, [addToast])

  const setTypingIndicator = useCallback(async (conversationId: string, isTyping: boolean) => {
    setState((s) => ({
      ...s,
      conversations: s.conversations.map((c) =>
        c.id === conversationId
          ? { ...c, isTyping, typingUser: isTyping ? "current-user" : undefined }
          : c
      ),
    }))
  }, [])

  const createGroup = useCallback(
    async (formData: any): Promise<string> => {
      try {
        // Community org + chat share one group conversation with kind=community
        const result = await domains.community.createCommunity({
          name: formData.name,
          description: formData.description,
          privacy: formData.privacy,
          category: formData.category,
          coverImage: formData.coverImage,
          welcomeMessage: formData.welcomeMessage,
          rules: formData.rules,
          invitedMembers: formData.invitedMembers || [],
        })
        if (!result.ok) {
          addToast(result.error, "error")
          return ""
        }
        let newGroup = result.data.community
        try {
          const { socialCreateCommunity } = await import("@/lib/social/client")
          const durable = await socialCreateCommunity({
            id: newGroup.id,
            name: newGroup.name || formData.name,
            purpose: formData.description || "",
            description: formData.description || "",
            privacy: formData.privacy,
            category: formData.category,
          })
          // Prefer server-canonical id when durable create returns one
          const serverId =
            durable && typeof durable === "object"
              ? String(
                  (durable as { id?: string; community?: { id?: string } }).id ||
                    (durable as { community?: { id?: string } }).community?.id ||
                    ""
                ).trim()
              : ""
          if (serverId && serverId !== newGroup.id) {
            newGroup = { ...newGroup, id: serverId }
          }
        } catch {
          /* local community remains until durable path available */
        }
        setState((s) => ({
          ...s,
          conversations: [newGroup, ...s.conversations],
        }))
        try {
          persistCommunityConversation(newGroup)
          markJoined(newGroup.id)
        } catch {
          /* */
        }
        analytics.trackEvent(
          "group_created",
          { groupId: newGroup.id, category: formData.category, privacy: formData.privacy },
          state.profile.displayName
        )
        addToast(`"${formData.name}" is live — Board is ready`, "success")
        return newGroup.id
      } catch (err) {
        errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
        addToast("Could not create community", "error")
        return ""
      }
    },
    [state.profile.displayName, addToast, domains]
  )

  const joinCommunity = useCallback(
    async (communityId: string): Promise<boolean> => {
      try {
        const conv = state.conversations.find((c) => c.id === communityId)
        const privacy = (conv?.privacy || "public") as string
        if (privacy === "invite-only") {
          const req = await domains.community.requestJoin(communityId)
          if (!req.ok) {
            addToast(req.error, "error")
            return false
          }
          setState((s) => ({
            ...s,
            conversations: s.conversations.map((c) =>
              c.id === communityId
                ? {
                    ...c,
                    pendingJoinRequests: req.data.pendingRequests,
                  }
                : c
            ),
          }))
          addToast("Join request sent — waiting for approval", "info")
          return true
        }
        const result = await domains.community.joinCommunity(communityId)
        if (result.ok) {
          try {
            const { socialJoinCommunity } = await import("@/lib/social/client")
            await socialJoinCommunity(communityId)
          } catch {
            /* local join remains */
          }
        }
        if (!result.ok) {
          // Seed/demo communities may not be in conversations yet — admit locally
          if (!conv) {
            setState((s) => {
              const existing = s.conversations.find((c) => c.id === communityId)
              if (existing) {
                return {
                  ...s,
                  conversations: s.conversations.map((c) =>
                    c.id === communityId
                      ? {
                          ...c,
                          members: Array.from(
                            new Set([
                              ...(c.members || []),
                              IdentityService.getCurrentUserId() || "current-user",
                            ])
                          ),
                        }
                      : c
                  ),
                }
              }
              return s
            })
            markJoined(communityId)
            addToast("Joined community", "success")
            return true
          }
          addToast(result.error, "error")
          return false
        }
        setState((s) => {
          const memberId = IdentityService.getCurrentUserId() || "current-user"
          const next: Conversation[] = s.conversations.map((c) => {
            if (c.id !== communityId) return c
            const groupRoles: NonNullable<Conversation["groupRoles"]> = {
              ...(c.groupRoles || {}),
              [memberId]: "member",
            }
            return {
              ...c,
              members: result.data.members,
              groupRoles,
            }
          })
          const row = next.find((c) => c.id === communityId)
          if (row) {
            try {
              persistCommunityConversation(row)
            } catch {
              /* */
            }
          }
          return { ...s, conversations: next }
        })
        markJoined(communityId)
        addToast("Joined community", "success")
        analytics.trackEvent("community_joined", { communityId }, state.profile.displayName)
        return true
      } catch (err) {
        errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
        addToast("Could not join community", "error")
        return false
      }
    },
    [state.conversations, state.profile.displayName, addToast, domains]
  )

  const leaveCommunity = useCallback(
    async (communityId: string): Promise<boolean> => {
      try {
        const result = await domains.community.leaveCommunity(communityId)
        if (!result.ok) {
          addToast(result.error, "error")
          return false
        }
        setState((s) => {
          const next: Conversation[] = s.conversations.map((c) =>
            c.id === communityId
              ? {
                  ...c,
                  members: result.data.members,
                }
              : c
          )
          const row = next.find((c) => c.id === communityId)
          if (row) {
            try {
              persistCommunityConversation(row)
            } catch {
              /* */
            }
          }
          return { ...s, conversations: next }
        })
        markLeft(communityId)
        addToast("Left community", "info")
        return true
      } catch (err) {
        errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
        addToast("Could not leave community", "error")
        return false
      }
    },
    [addToast, domains]
  )

  const acceptCommunityInvitation = useCallback(
    async (communityId: string): Promise<boolean> => {
      try {
        const result = await domains.community.acceptInvitation(communityId)
        if (!result.ok) {
          addToast(result.error || "Invitation unavailable", "error")
          return false
        }
        setState((s) => {
          const memberId = IdentityService.getCurrentUserId() || "current-user"
          return {
            ...s,
            conversations: s.conversations.map((c) => {
              if (c.id !== communityId) return c
              const groupRoles: NonNullable<Conversation["groupRoles"]> = {
                ...(c.groupRoles || {}),
                [memberId]: "member",
              }
              return {
                ...c,
                members: result.data.members,
                invitedMembers: (c.invitedMembers || []).filter((id: string) => id !== memberId),
                groupRoles,
              }
            }),
          }
        })
        try {
          const communityName =
            (state.conversations.find((c) => c.id === communityId))?.groupName || "community"
          emitCommunityNotification({
            subtype: "invitation_accepted",
            communityId,
            communityName,
            userId: IdentityService.getCurrentUserId() || undefined,
            actorName: state.profile.displayName || "Member",
            referenceId: `invitation_accepted:${communityId}:${IdentityService.getCurrentUserId()}`,
          })
        } catch { /* */ }
        addToast("Joined community", "success")
        return true
      } catch (err) {
        addToast("Could not accept invitation", "error")
        return false
      }
    },
    [addToast, domains, state.conversations, state.profile.displayName]
  )

  const declineCommunityInvitation = useCallback(
    async (communityId: string): Promise<boolean> => {
      try {
        const result = await domains.community.declineInvitation(communityId)
        if (!result.ok) {
          addToast(result.error || "Invitation unavailable", "error")
          return false
        }
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) =>
            c.id === communityId
              ? {
                  ...c,
                  invitedMembers: (c.invitedMembers || []).filter(
                    (id: string) => id !== (IdentityService.getCurrentUserId() || "current-user")
                  ),
                }
              : c
          ),
        }))
        addToast("Invitation declined", "info")
        return true
      } catch {
        addToast("Could not decline invitation", "error")
        return false
      }
    },
    [addToast, domains]
  )


  const approveCommunityJoinRequest = useCallback(
    async (communityId: string, userId: string): Promise<boolean> => {
      try {
        const result = await domains.community.approveJoinRequest(communityId, userId)
        if (!result.ok) {
          addToast(result.error || "Could not approve", "error")
          return false
        }
        try {
          const { socialDecideJoinRequest } = await import("@/lib/social/client")
          await socialDecideJoinRequest(communityId, userId, true)
        } catch {
          /* local approval remains */
        }
        const communityName =
          (state.conversations.find((c) => c.id === communityId))?.groupName ||
          (state.conversations.find((c) => c.id === communityId))?.participantName ||
          "community"
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) =>
            c.id === communityId
              ? {
                  ...c,
                  members: result.data.members,
                  pendingJoinRequests: result.data.pendingJoinRequests,
                }
              : c
          ),
        }))
        try {
          emitCommunityNotification({
            subtype: "join_accepted",
            communityId,
            communityName,
            userId,
            actorName: state.profile.displayName || "Admin",
            referenceId: `join_accepted:${communityId}:${userId}`,
          })
        } catch { /* */ }
        addToast("Join request approved", "success")
        return true
      } catch {
        addToast("Could not approve request", "error")
        return false
      }
    },
    [addToast, domains, state.conversations, state.profile.displayName]
  )

  const declineCommunityJoinRequest = useCallback(
    async (communityId: string, userId: string): Promise<boolean> => {
      try {
        const result = await domains.community.declineJoinRequest(communityId, userId)
        if (!result.ok) {
          addToast(result.error || "Could not decline", "error")
          return false
        }
        try {
          const { socialDecideJoinRequest } = await import("@/lib/social/client")
          await socialDecideJoinRequest(communityId, userId, false)
        } catch {
          /* local decline remains */
        }
        const communityName =
          (state.conversations.find((c) => c.id === communityId))?.groupName || "community"
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) =>
            c.id === communityId
              ? { ...c, pendingJoinRequests: result.data.pendingJoinRequests }
              : c
          ),
        }))
        try {
          emitCommunityNotification({
            subtype: "join_declined",
            communityId,
            communityName,
            userId,
            referenceId: `join_declined:${communityId}:${userId}`,
          })
        } catch { /* */ }
        addToast("Join request declined", "info")
        return true
      } catch {
        addToast("Could not decline request", "error")
        return false
      }
    },
    [addToast, domains, state.conversations]
  )

  const inviteCommunityMember = useCallback(
    async (communityId: string, userId: string): Promise<boolean> => {
      try {
        if (!userId || userId === IdentityService.getCurrentUserId()) {
          addToast("Invalid invite target", "error")
          return false
        }
        const result = await domains.community.inviteMember(communityId, userId)
        if (!result.ok) {
          addToast(result.error || "Could not invite", "error")
          return false
        }
        const communityName =
          (state.conversations.find((c) => c.id === communityId))?.groupName || "community"
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) =>
            c.id === communityId
              ? {
                  ...c,
                  invitedMembers: result.data.invitedMembers || [
                    ...new Set([...(c.invitedMembers || []), userId]),
                  ],
                }
              : c
          ),
        }))
        try {
          emitCommunityNotification({
            subtype: "invitation",
            communityId,
            communityName,
            userId,
            actorName: state.profile.displayName || "Member",
            referenceId: `invitation:${communityId}:${userId}`,
          })
        } catch { /* */ }
        addToast("Invitation sent", "success")
        return true
      } catch {
        addToast("Could not send invitation", "error")
        return false
      }
    },
    [addToast, domains, state.conversations, state.profile.displayName]
  )

  const requestJoinCommunity = useCallback(
    async (communityId: string): Promise<boolean> => {
      try {
        const result = await domains.community.requestJoin(communityId)
        if (!result.ok) {
          addToast(result.error, "error")
          return false
        }
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) =>
            c.id === communityId
              ? { ...c, pendingJoinRequests: result.data.pendingRequests }
              : c
          ),
        }))
        try {
          const communityName =
            (state.conversations.find((c) => c.id === communityId))?.groupName || "community"
          emitCommunityNotification({
            subtype: "join_request",
            communityId,
            communityName,
            userId: IdentityService.getCurrentUserId() || undefined,
            actorName: state.profile.displayName || "Member",
            referenceId: `join_request:${communityId}:${IdentityService.getCurrentUserId()}`,
          })
        } catch { /* */ }
        addToast("Request sent", "info")
        return true
      } catch (err) {
        addToast("Could not send request", "error")
        return false
      }
    },
    [addToast, domains, state.conversations, state.profile.displayName]
  )

  const createBoardPost = useCallback(
    async (
      communityId: string,
      body: string,
      kind: "text" | "question" | "resource" = "text"
    ): Promise<boolean> => {
      try {
        const result = await domains.community.createBoardPost(communityId, { body, kind })
        if (!result.ok) {
          addToast(result.error, "error")
          return false
        }
        const post = {
          ...result.data.post,
          authorName: state.profile.displayName || "You",
        }
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) => {
            if (c.id !== communityId) return c
            const existing = (c.boardPosts || []) as typeof post[]
            return {
              ...c,
              boardPosts: [post, ...existing],
              lastMessage: body.slice(0, 80),
              lastMessageTime: post.createdAt,
            }
          }),
        }))
        addToast("Posted to board", "success")
        return true
      } catch (err) {
        addToast("Could not post", "error")
        return false
      }
    },
    [state.profile.displayName, addToast, domains]
  )

  const replyToBoardPost = useCallback(
    async (communityId: string, postId: string, body: string): Promise<boolean> => {
      try {
        const result = await domains.community.replyToBoardPost(communityId, postId, body)
        if (!result.ok) {
          addToast(result.error || "Could not reply", "error")
          return false
        }
        const reply = {
          ...result.data.reply,
          authorName: state.profile.displayName || "You",
        }
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) => {
            if (c.id !== communityId) return c
            const posts = (c.boardPosts || []) as any[]
            return {
              ...c,
              boardPosts: posts.map((p) =>
                p.id === postId
                  ? {
                      ...p,
                      replies: [...(p.replies || []), reply],
                      comments: result.data.comments,
                    }
                  : p
              ),
            }
          }),
        }))
        addToast("Reply posted", "success")
        return true
      } catch {
        addToast("Could not reply", "error")
        return false
      }
    },
    [addToast, domains, state.profile.displayName]
  )

  const reactToBoardPost = useCallback(
    async (communityId: string, postId: string): Promise<boolean> => {
      try {
        const result = await domains.community.reactToBoardPost(communityId, postId, "like")
        if (!result.ok) {
          addToast(result.error || "Could not react", "error")
          return false
        }
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) => {
            if (c.id !== communityId) return c
            const posts = (c.boardPosts || []) as any[]
            return {
              ...c,
              boardPosts: posts.map((p) =>
                p.id === postId
                  ? {
                      ...p,
                      likes: result.data.likes,
                      likedBy: result.data.likedBy,
                    }
                  : p
              ),
            }
          }),
        }))
        return true
      } catch {
        addToast("Could not react", "error")
        return false
      }
    },
    [addToast, domains]
  )


  const pinBoardPost = useCallback(
    async (communityId: string, postId: string): Promise<boolean> => {
      try {
        const result = await domains.community.pinBoardPost(communityId, postId)
        if (!result.ok) {
          addToast(result.error || "Could not pin", "error")
          return false
        }
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) => {
            if (c.id !== communityId) return c
            const posts = (c.boardPosts || []) as any[]
            return {
              ...c,
              boardPosts: posts.map((p) =>
                p.id === postId ? { ...p, pinned: true } : p
              ),
            }
          }),
        }))
        try {
          appendModerationLog({
            communityId,
            action: "pin",
            actorId: IdentityService.getCurrentUserId() || "unknown",
            targetType: "post",
            targetId: postId,
          })
        } catch { /* */ }
        addToast("Discussion pinned", "success")
        return true
      } catch {
        addToast("Could not pin", "error")
        return false
      }
    },
    [addToast, domains]
  )

  const unpinBoardPost = useCallback(
    async (communityId: string, postId: string): Promise<boolean> => {
      try {
        const result = await domains.community.unpinBoardPost(communityId, postId)
        if (!result.ok) {
          addToast(result.error || "Could not unpin", "error")
          return false
        }
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) => {
            if (c.id !== communityId) return c
            const posts = (c.boardPosts || []) as any[]
            return {
              ...c,
              boardPosts: posts.map((p) =>
                p.id === postId ? { ...p, pinned: false } : p
              ),
            }
          }),
        }))
        try {
          appendModerationLog({
            communityId,
            action: "unpin",
            actorId: IdentityService.getCurrentUserId() || "unknown",
            targetType: "post",
            targetId: postId,
          })
        } catch { /* */ }
        addToast("Discussion unpinned", "info")
        return true
      } catch {
        addToast("Could not unpin", "error")
        return false
      }
    },
    [addToast, domains]
  )

  const hideBoardPost = useCallback(
    async (communityId: string, postId: string): Promise<boolean> => {
      try {
        const result = await domains.community.hideBoardPost(communityId, postId)
        if (!result.ok) {
          addToast(result.error || "Could not hide", "error")
          return false
        }
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) => {
            if (c.id !== communityId) return c
            const posts = (c.boardPosts || []) as any[]
            return {
              ...c,
              boardPosts: posts.map((p) =>
                p.id === postId ? { ...p, hidden: true, pinned: false } : p
              ),
            }
          }),
        }))
        try {
          appendModerationLog({
            communityId,
            action: "hide",
            actorId: IdentityService.getCurrentUserId() || "unknown",
            targetType: "post",
            targetId: postId,
          })
        } catch { /* */ }
        addToast("Discussion hidden", "info")
        return true
      } catch {
        addToast("Could not hide", "error")
        return false
      }
    },
    [addToast, domains]
  )

  const unhideBoardPost = useCallback(
    async (communityId: string, postId: string): Promise<boolean> => {
      try {
        const result = await domains.community.unhideBoardPost(communityId, postId)
        if (!result.ok) {
          addToast(result.error || "Could not unhide", "error")
          return false
        }
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) => {
            if (c.id !== communityId) return c
            const posts = (c.boardPosts || []) as any[]
            return {
              ...c,
              boardPosts: posts.map((p) =>
                p.id === postId ? { ...p, hidden: false } : p
              ),
            }
          }),
        }))
        try {
          appendModerationLog({
            communityId,
            action: "unhide",
            actorId: IdentityService.getCurrentUserId() || "unknown",
            targetType: "post",
            targetId: postId,
          })
        } catch { /* */ }
        addToast("Discussion restored", "success")
        return true
      } catch {
        addToast("Could not unhide", "error")
        return false
      }
    },
    [addToast, domains]
  )

  const transitionCommunityLifecycle = useCallback(
    async (
      communityId: string,
      next: "draft" | "discoverable" | "active" | "quiet" | "archived"
    ): Promise<boolean> => {
      try {
        const result = await domains.community.transitionLifecycle(communityId, next)
        if (!result.ok) {
          addToast(result.error || "Could not update status", "error")
          return false
        }
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) =>
            c.id === communityId ? { ...c, lifecycle: next } : c
          ),
        }))
        try {
          appendModerationLog({
            communityId,
            action: "lifecycle",
            actorId: IdentityService.getCurrentUserId() || "unknown",
            targetType: "community",
            targetId: communityId,
            metadata: { lifecycle: next },
          })
        } catch { /* */ }
        addToast(`Community marked ${next}`, "success")
        return true
      } catch {
        addToast("Could not update community status", "error")
        return false
      }
    },
    [addToast, domains]
  )

  const reportCommunityContent = useCallback(
    async (
      communityId: string,
      input: {
        targetType: "community" | "post" | "member"
        targetId: string
        reason: "spam" | "harassment" | "hate" | "misinformation" | "impersonation" | "safety" | "other"
        note?: string
      }
    ): Promise<boolean> => {
      try {
        const result = await domains.community.reportCommunityContent(communityId, input)
        if (!result.ok) {
          addToast(result.error || "Could not submit report", "error")
          return false
        }
        try {
          createCommunityReport({
            communityId,
            targetType: input.targetType,
            targetId: input.targetId,
            reporterId: IdentityService.getCurrentUserId() || "unknown",
            reason: input.reason,
            note: input.note,
          })
        } catch { /* */ }
        addToast("Report submitted — thank you", "success")
        return true
      } catch {
        addToast("Could not submit report", "error")
        return false
      }
    },
    [addToast, domains]
  )

  const createCommunityAnnouncement = useCallback(
    async (
      communityId: string,
      input: { title: string; content: string; type?: "info" | "important" | "celebration" | "maintenance" }
    ): Promise<boolean> => {
      try {
        const result = await domains.community.createAnnouncement(communityId, input)
        if (!result.ok) {
          addToast(result.error || "Could not announce", "error")
          return false
        }
        const announcement = result.data.announcement
        const communityName =
          (state.conversations.find((c) => c.id === communityId))?.groupName || "community"
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) => {
            if (c.id !== communityId) return c
            const existing = ((c as any).announcements || []) as any[]
            return {
              ...c,
              announcements: [announcement, ...existing],
            }
          }),
        }))
        try {
          emitCommunityNotification({
            subtype: "announcement",
            communityId,
            communityName,
            actorName: state.profile.displayName || "Moderator",
            referenceId: `announcement:${communityId}:${announcement.id}`,
            messageOverride: input.title,
          })
        } catch { /* */ }
        addToast("Announcement published", "success")
        return true
      } catch {
        addToast("Could not publish announcement", "error")
        return false
      }
    },
    [addToast, domains, state.conversations, state.profile.displayName]
  )

  const createCommunityEvent = useCallback(
    async (
      communityId: string,
      input: {
        title: string
        description: string
        startTime: number
        endTime: number
        location?: string
        category?: "meeting" | "social" | "workshop" | "discussion" | "celebration"
      }
    ): Promise<boolean> => {
      try {
        const result = await domains.community.createEvent(communityId, input)
        if (!result.ok) {
          addToast(result.error || "Could not create event", "error")
          return false
        }
        const event = result.data.event
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) => {
            if (c.id !== communityId) return c
            const existing = (c.events || []) as any[]
            return { ...c, events: [event, ...existing] }
          }),
        }))
        addToast("Event scheduled", "success")
        return true
      } catch {
        addToast("Could not create event", "error")
        return false
      }
    },
    [addToast, domains]
  )

  const rsvpCommunityEvent = useCallback(
    async (communityId: string, eventId: string): Promise<boolean> => {
      try {
        // Best-effort local RSVP until server calendar exists
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) => {
            if (c.id !== communityId) return c
            const events = ((c.events || []) as any[]).map((e) => {
              if (e.id !== eventId) return e
              const attendees = Array.from(
                new Set([...(e.attendees || []), IdentityService.getCurrentUserId() || "current-user"]),
              )
              return { ...e, attendees, rsvpCount: attendees.length }
            })
            return { ...c, events }
          }),
        }))
        addToast("You're attending", "success")
        return true
      } catch {
        return false
      }
    },
    [addToast]
  )

    const addGroupMember = useCallback(
    async (conversationId: string, userId: string) => {
      setState((s) => ({
        ...s,
        conversations: s.conversations.map((c) =>
          c.id === conversationId && !c.members?.includes(userId)
            ? { ...c, members: [...(c.members || []), userId] }
            : c
        ),
      }))
      analytics.trackEvent("group_member_added", { conversationId, userId }, state.profile.displayName)
      addToast("Member added", "success")
    },
    [state.profile.displayName, addToast]
  )

  const removeGroupMember = useCallback(
    async (conversationId: string, userId: string) => {
      setState((s) => ({
        ...s,
        conversations: s.conversations.map((c) =>
          c.id === conversationId ? applyRemoveGroupMember(c, userId) : c
        ),
      }))
      analytics.trackEvent("group_member_removed", { conversationId, userId }, state.profile.displayName)
      addToast("Member removed", "success")
    },
    [state.profile.displayName, addToast]
  )

  const setGroupRole = useCallback(
    async (conversationId: string, userId: string, role: "admin" | "member" | "owner" | "moderator") => {
      try {
        const normalized =
          role === "admin" || role === "owner" || role === "moderator" || role === "member"
            ? role
            : "member"
        const result = await domains.community.setRole(conversationId, userId, normalized as any)
        if (!result.ok) {
          addToast(result.error, "error")
          return
        }
        // Durable role when community membership is server-backed
        try {
          const roleApi =
            normalized === "owner" ? "admin" : normalized === "admin" || normalized === "moderator" || normalized === "member" ? normalized : "member"
          await fetch(`/api/communities/${encodeURIComponent(conversationId)}/roles`, {
            method: "POST",
            credentials: "include",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ targetUserId: userId, role: roleApi }),
          })
        } catch {
          /* offline / studio */
        }
        setState((s) => ({
          ...s,
          conversations: s.conversations.map((c) => {
            if (c.id !== conversationId) return c
            const role = result.data.role
            const safeRole: NonNullable<Conversation["groupRoles"]>[string] =
              role === "owner" || role === "admin" || role === "moderator" || role === "member"
                ? role
                : "member"
            const groupRoles: NonNullable<Conversation["groupRoles"]> = {
              ...(c.groupRoles || {}),
              [userId]: safeRole,
            }
            return { ...c, groupRoles }
          }),
        }))
        analytics.trackEvent(
          "group_role_updated",
          { conversationId, userId, role: result.data.role },
          state.profile.displayName
        )
        addToast("Role updated", "success")
      } catch (err) {
        errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
        addToast("Could not update role", "error")
      }
    },
    [state.profile.displayName, addToast, domains]
  )

  const updateGroupName = useCallback(
    async (conversationId: string, newName: string) => {
      setState((s) => ({
        ...s,
        conversations: s.conversations.map((c) =>
          c.id === conversationId ? { ...c, groupName: newName, participantName: newName } : c
        ),
      }))
      analytics.trackEvent("group_name_updated", { conversationId }, state.profile.displayName)
      addToast("Group name updated", "success")
    },
    [state.profile.displayName, addToast]
  )

  const updateGroupPhoto = useCallback(
    async (conversationId: string, photoUrl: string) => {
      setState((s) => ({
        ...s,
        conversations: s.conversations.map((c) =>
          c.id === conversationId ? { ...c, groupPhoto: photoUrl, participantPhoto: photoUrl } : c
        ),
      }))
      analytics.trackEvent("group_photo_updated", { conversationId }, state.profile.displayName)
      addToast("Group photo updated", "success")
    },
    [state.profile.displayName, addToast]
  )

  const logout = useCallback(async () => {
    try {
      backupRecoveryManager.createBackup(state.profile, state.settings, state.posts, state.conversations, "manual")
      // Server-side GH session revoke + clear HttpOnly cookie (Phase 2B)
      try {
        await fetch("/api/auth/logout", {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
        })
      } catch {
        /* network — still clear local state */
      }
      // Clear local App Lock session flags (keeps PIN hash for next login)
      try {
        const { clearLockSessionState } = await import("@/lib/session-security")
        clearLockSessionState()
      } catch {
        /* */
      }
      // Identity domain session signal (does not replace Pi auth transport)
      await domains.identity.clearSession()
      try {
        IdentityService.clear()
      } catch {
        /* */
      }
      setState(() => createDefaultExtendedState({ ready: true }))
      addToast("Logged out successfully", "success")
    } catch (error) {
      errorLogger.logError(error instanceof Error ? error : new Error(String(error)))
      addToast("Error logging out", "error")
    }
  }, [addToast, state.profile, state.settings, state.posts, state.conversations, domains])

  const createBackup = useCallback(() => {
    try {
      backupRecoveryManager.createBackup(
        state.profile,
        state.settings,
        state.posts,
        state.conversations,
        "manual"
      )
      addToast("Backup created successfully", "success")
    } catch (error) {
      errorLogger.logError(error instanceof Error ? error : new Error(String(error)))
      addToast("Failed to create backup", "error")
    }
  }, [state.profile, state.settings, state.posts, state.conversations, addToast])

  const restoreFromBackup = useCallback(async (): Promise<boolean> => {
    try {
      const latestBackup = backupRecoveryManager.getLatestBackup()

      if (!latestBackup) {
        addToast("No backup available", "error")
        return false
      }

      // Verify backup integrity
      if (!backupRecoveryManager.verifySnapshot(latestBackup)) {
        addToast("Backup verification failed - possible corruption", "error")
        return false
      }

      // Restore within transaction for atomicity
      const result = await transactionManager.executeTransaction(async () => {
        if (latestBackup.data.profile) {
          setState((s) => ({ ...s, profile: latestBackup.data.profile! }))
        }

        if (latestBackup.data.settings) {
          setState((s) => ({ ...s, settings: latestBackup.data.settings! }))
        }

        setState((s) => ({ 
          ...s, 
          posts: latestBackup.data.posts, 
          conversations: latestBackup.data.conversations 
        }))

        return true
      })

      if (result.success) {
        addToast("Data restored from backup successfully", "success")
        return true
      }

      return false
    } catch (error) {
      errorLogger.logError(error instanceof Error ? error : new Error(String(error)))
      addToast("Failed to restore from backup", "error")
      return false
    }
  }, [addToast])

  const publishStory = useCallback(async (story: StoryItem) => {
    try {
      const prepared: StoryItem = {
        ...story,
        id: typeof story.id === "string" && story.id ? story.id : generateId(),
        name: sanitizeDisplayName(story.name || state.profile.displayName || "User"),
        text: sanitizeText(story.text || "", 500),
        createdAt: Number.isFinite(story.createdAt) ? story.createdAt : Date.now(),
        ownerId: story.ownerId || "current-user",
        photo: story.photo || state.profile.photos?.[0],
      }
      const result = await domains.stories.publish(prepared)
      if (!result.ok) {
        addToast(result.error, "error")
        return
      }
      setState((s) => ({
        ...s,
        stories: sanitizeStories([result.data, ...s.stories.filter((x) => x.id !== result.data.id)]),
      }))
      try {
        const { socialCreateStory } = await import("@/lib/social/client")
        await socialCreateStory({
          id: result.data.id,
          ownerId: result.data.ownerId,
          name: result.data.name,
          photo: result.data.photo,
          text: result.data.text,
          media: result.data.media,
          audience: result.data.audience,
          expiresAt: result.data.expiresAt || Date.now() + 24 * 60 * 60 * 1000,
          createdAt: result.data.createdAt,
        })
      } catch {
        /* local story remains until durable path available */
      }
    } catch (err) {
      errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
      addToast("This story could not be saved safely", "error")
    }
  }, [addToast, domains, state.profile.displayName, state.profile.photos])

  /**
   * Story reply → Messaging domain: open or create private conversation with story owner.
   * Does not invent a parallel story-messaging channel.
   */
  const replyToStory = useCallback(
    async (storyId: string): Promise<string | null> => {
      try {
        const target = domains.stories.resolveReplyTarget(storyId)
        if (!target.ok) {
          addToast(target.error, "error")
          return null
        }
        const { ownerId, ownerName, ownerPhoto } = target.data
        if (!canMessageUser(ownerId)) {
          addToast("You cannot message this person with your current privacy settings.", "info")
          return null
        }
        return await startConversation(
          ownerId,
          ownerName,
          ownerPhoto || "/placeholder.svg?width=40&height=40"
        )
      } catch (err) {
        errorLogger.logError(err instanceof Error ? err : new Error(String(err)))
        addToast("Could not open conversation", "error")
        return null
      }
    },
    [domains, addToast, canMessageUser, startConversation]
  )

  const setTab = useCallback((tab: Tab) => {
    startTransition(() => {
      setState((s) => (s.tab === tab ? s : { ...s, tab: tab as Tab }))
    })
  }, [])

  // Platform-wide block + mute enforcement (single policy, not per-screen rules)
  const blockedIdsForUi = useMemo(
    () =>
      resolveBlockedIds({
        blockedUsers: state.blockedUsers,
        settingsBlocked: state.settings?.blockedUsers,
      }),
    [state.blockedUsers, state.settings?.blockedUsers]
  )

  const mutedIdsForUi = useMemo(() => {
    const fromState = ((state as { mutedUsers?: string[] }).mutedUsers) || []
    const fromSettings = state.settings?.mutedUsers || []
    return Array.from(new Set([...fromState, ...fromSettings]))
  }, [state, state.settings?.mutedUsers])

  const visibleSession = useMemo(
    () =>
      applyGlobalBlockFilters({
        blockedIds: blockedIdsForUi,
        mutedIds: mutedIdsForUi,
        posts: state.posts,
        candidates: state.candidates,
        matches: state.matches,
        conversations: state.conversations,
        stories: state.stories,
      }),
    [
      blockedIdsForUi,
      mutedIdsForUi,
      state.posts,
      state.candidates,
      state.matches,
      state.conversations,
      state.stories,
    ]
  )

  // Stable context value — prevents every consumer re-rendering when only parent re-renders
  const contextValue = useMemo(
    () => ({
      ready: state.ready,
      profile: state.profile,
      settings: state.settings,
      posts: visibleSession.posts,
      stories: visibleSession.stories,
      publishStory,
      replyToStory,
      tab: state.tab,
      toasts: state.toasts,
      candidates: visibleSession.candidates,
      matches: visibleSession.matches,
      likes: state.likes,
      conversations: visibleSession.conversations,
      friendRequests: state.friendRequests,
      following: state.following,
      friends: state.friends || [],
      shares: state.shares || [],
      reposts: state.reposts || [],
      likedPostIds: state.likedPostIds,
      isOnline: state.isOnline,
      networkQuality: state.networkQuality,
      dataIntegrity: "verified" as const,
      createBackup,
      restoreFromBackup,
      updateProfile,
      completeOnboarding,
      localProfiles: typeof window === "undefined" ? [] : readLocalProfiles(),
      switchLocalProfile,
      createLocalProfile,
      createPost,
      likePost,
      deletePost,
      editPost,
      archivePost,
      unarchivePost,
      addComment,
      editComment,
      deleteComment,
      addCommentReaction,
      removeCommentReaction,
      pinComment,
      unpinComment,
      createQuoteRepost,
      sharePost,
      applyShareResult,
      savePost,
      unsavePost,
      hidePost,
      markNotInterested,
      reportPost,
      reportContent,
      muteUser,
      unmuteUser,
      restrictUser,
      unrestrictUser,
      followFromPost,
      unfollowFromPost,
      updateSettings,
      canViewProfile,
      canMessageUser,
      canViewStory,
      canSeeOnlineStatus,
      swipe,
      matchCelebration: state.matchCelebration,
      dismissMatchCelebration,
      followUser,
      addFriend,
      reportUser,
      blockUser,
      unblockUser,
      blockedUsers: blockedIdsForUi,
      mutedUsers: mutedIdsForUi,
      startConversation,
      acceptMatch,
      rejectMatch,
      sendMessage,
      editMessage,
      deleteMessage,
      replyToMessage,
      forwardMessage,
      addMessageReaction,
      removeMessageReaction,
      pinMessage,
      unpinMessage,
      sendVoiceNote,
      sendMediaMessage,
      scheduleMessage,
      sendDisappearingMessage,
      saveDraft,
      loadDraft,
      searchMessages,
      markConversationRead,
      pinConversation,
      unpinConversation,
      archiveConversation,
      unarchiveConversation,
      muteConversation,
      unmuteConversation,
      setTypingIndicator,
      createGroup,
      joinCommunity,
      acceptCommunityInvitation,
      declineCommunityInvitation,
      leaveCommunity,
      requestJoinCommunity,
      approveCommunityJoinRequest,
      declineCommunityJoinRequest,
      inviteCommunityMember,
      createBoardPost,
      replyToBoardPost,
      reactToBoardPost,
      pinBoardPost,
      unpinBoardPost,
      hideBoardPost,
      unhideBoardPost,
      createCommunityAnnouncement,
      createCommunityEvent,
      rsvpCommunityEvent,
      transitionCommunityLifecycle,
      reportCommunityContent,
      addGroupMember,
      removeGroupMember,
      setGroupRole,
      updateGroupName,
      updateGroupPhoto,
      setTab,
      addToast,
      logout,
    }),
    // Intentionally depend on session slices + state fields that surface in UI.
    // Callbacks are useCallback-stable in this provider.
    [
      state.ready,
      state.profile,
      state.settings,
      state.tab,
      state.toasts,
      state.likes,
      state.friendRequests,
      state.following,
      state.friends,
      state.shares,
      state.reposts,
      state.likedPostIds,
      state.isOnline,
      state.networkQuality,
      state.matchCelebration,
      visibleSession,
      blockedIdsForUi,
      mutedIdsForUi,
    ],
  )

  const shellValue = useMemo(
    () => ({
      ready: state.ready,
      tab: state.tab,
      setTab,
      toasts: state.toasts,
      addToast,
      isOnline: state.isOnline,
      networkQuality: state.networkQuality,
      matchCelebration: state.matchCelebration,
      dismissMatchCelebration,
      startConversation,
    }),
    [
      state.ready,
      state.tab,
      state.toasts,
      state.isOnline,
      state.networkQuality,
      state.matchCelebration,
      setTab,
      addToast,
      dismissMatchCelebration,
      startConversation,
    ],
  )

  const profileValue = useMemo(
    () => ({
      profile: state.profile,
      settings: state.settings,
      friends: state.friends || [],
      following: state.following || [],
      posts: visibleSession.posts,
      updateProfile,
      completeOnboarding,
      updateSettings,
      addToast,
    }),
    [
      state.profile,
      state.settings,
      state.friends,
      state.following,
      visibleSession.posts,
      updateProfile,
      completeOnboarding,
      updateSettings,
      addToast,
    ],
  )

  const discoveryValue = useMemo(
    () => ({
      candidates: visibleSession.candidates,
      matches: visibleSession.matches,
      following: state.following || [],
      swipe,
      followUser,
      addFriend,
      reportUser,
      blockUser,
      unblockUser,
      startConversation,
      acceptMatch,
      rejectMatch,
      profile: state.profile,
    }),
    [
      visibleSession.candidates,
      visibleSession.matches,
      state.following,
      state.profile,
      swipe,
      followUser,
      addFriend,
      reportUser,
      blockUser,
      unblockUser,
      startConversation,
      acceptMatch,
      rejectMatch,
    ],
  )

  const messagingValue = useMemo(
    () => ({
      conversations: visibleSession.conversations,
      sendMessage,
      markConversationRead,
      pinConversation,
      archiveConversation,
      muteConversation,
      createGroup,
      joinCommunity,
      acceptCommunityInvitation,
      declineCommunityInvitation,
      leaveCommunity,
      replyToBoardPost,
      reactToBoardPost,
      pinBoardPost,
      unpinBoardPost,
      hideBoardPost,
      unhideBoardPost,
      transitionCommunityLifecycle,
      reportCommunityContent,
      createCommunityAnnouncement,
      createCommunityEvent,
      rsvpCommunityEvent,
      createBoardPost,
      startConversation,
      addToast,
      profile: state.profile,
      setTab,
    }),
    [
      visibleSession.conversations,
      state.profile,
      sendMessage,
      markConversationRead,
      pinConversation,
      archiveConversation,
      muteConversation,
      createGroup,
      joinCommunity,
      acceptCommunityInvitation,
      declineCommunityInvitation,
      leaveCommunity,
      replyToBoardPost,
      reactToBoardPost,
      pinBoardPost,
      unpinBoardPost,
      hideBoardPost,
      unhideBoardPost,
      transitionCommunityLifecycle,
      reportCommunityContent,
      createCommunityAnnouncement,
      createCommunityEvent,
      rsvpCommunityEvent,
      createBoardPost,
      startConversation,
      addToast,
      setTab,
    ],
  )

  const feedValue = useMemo(
    () => ({
      posts: visibleSession.posts,
      stories: state.stories,
      likedPostIds: state.likedPostIds || [],
      following: state.following || [],
      friends: state.friends || [],
      profile: state.profile,
      settings: state.settings,
      candidates: visibleSession.candidates,
      createPost,
      likePost,
      deletePost,
      editPost,
      archivePost,
      unarchivePost,
      addComment,
      editComment,
      deleteComment,
      addCommentReaction,
      removeCommentReaction,
      pinComment,
      unpinComment,
      createQuoteRepost,
      sharePost,
      applyShareResult,
      savePost,
      unsavePost,
      reportPost,
      reportContent,
      publishStory,
      followUser,
      unfollowFromPost,
      muteUser,
      blockUser,
      addToast,
      setTab,
      shares: state.shares,
      reposts: state.reposts,
      blockedUsers: blockedIdsForUi,
    mutedUsers: mutedIdsForUi,
    }),
    [
      visibleSession.posts,
      visibleSession.candidates,
      state.stories,
      state.likedPostIds,
      state.following,
      state.friends,
      state.profile,
      state.settings,
      state.shares,
      state.reposts,
      blockedIdsForUi,
      mutedIdsForUi,
      createPost,
      likePost,
      deletePost,
      editPost,
      archivePost,
      unarchivePost,
      addComment,
      editComment,
      deleteComment,
      addCommentReaction,
      removeCommentReaction,
      pinComment,
      unpinComment,
      createQuoteRepost,
      sharePost,
      applyShareResult,
      savePost,
      unsavePost,
      reportPost,
      reportContent,
      publishStory,
      followUser,
      unfollowFromPost,
      muteUser,
      blockUser,
      addToast,
      setTab,
    ],
  )


  return (
    <GHCContext.Provider value={contextValue}>
      <GHCShellContext.Provider value={shellValue}>
        <GHCProfileContext.Provider value={profileValue}>
          <GHCDiscoveryContext.Provider value={discoveryValue}>
            <GHCMessagingContext.Provider value={messagingValue}>
              <GHCFeedContext.Provider value={feedValue}>
                {children}
              </GHCFeedContext.Provider>
            </GHCMessagingContext.Provider>
          </GHCDiscoveryContext.Provider>
        </GHCProfileContext.Provider>
      </GHCShellContext.Provider>
    </GHCContext.Provider>
  )
}

export function useGHC() {
  const context = useContext(GHCContext)
  if (!context) throw new Error("useGHC must be used within GHCProvider")
  return context
}

/** Shell: tab, toasts, online — does not re-render on feed/messages data */
export function useGHCShell() {
  const ctx = useContext(GHCShellContext)
  if (!ctx) throw new Error("useGHCShell must be used within GHCProvider")
  return ctx
}

/** Profile + settings slice */
export function useGHCProfile() {
  const ctx = useContext(GHCProfileContext)
  if (!ctx) throw new Error("useGHCProfile must be used within GHCProvider")
  return ctx
}

/** Discovery / Find slice — isolated from messaging list churn */
export function useGHCDiscovery() {
  const ctx = useContext(GHCDiscoveryContext)
  if (!ctx) throw new Error("useGHCDiscovery must be used within GHCProvider")
  return ctx
}

/** Messages + communities slice */
export function useGHCMessaging() {
  const ctx = useContext(GHCMessagingContext)
  if (!ctx) throw new Error("useGHCMessaging must be used within GHCProvider")
  return ctx
}

/** Feed / Home slice — prefer over useGHC() on the feed screen */
export function useGHCFeed() {
  const ctx = useContext(GHCFeedContext)
  if (!ctx) throw new Error("useGHCFeed must be used within GHCProvider")
  return ctx
}

/** @deprecated Prefer useGHCMessaging — kept for existing imports */
export function useGHCCommunity() {
  return useGHCMessaging()
}

