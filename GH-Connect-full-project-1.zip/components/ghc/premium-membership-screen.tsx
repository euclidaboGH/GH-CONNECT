"use client"

import { useMemo, useState, useEffect } from "react"
import {
  ArrowLeft,
  Check,
  Crown,
  Info,
  Loader2,
  Sparkles,
  X,
  ChevronRight,
  Filter,
  Users,
  MessageCircle,
  Store,
  BarChart3,
  ImageIcon,
  Headphones,
  BadgeCheck,
} from "lucide-react"
import { GhcCoinIcon } from "./ghc-coin-icon"
import { getBoundDomainServices } from "@/lib/domains/compat"
import {
  MEMBERSHIP_PLANS,
  type MembershipTierId,
  type EntitlementKey,
  type MembershipStatus,
} from "@/lib/domains/membership-domain"
import { useGHC } from "@/contexts/ghc-context"
import { isPiPaymentsAvailable } from "@/lib/gh-pay"
import { runGhPayMembership } from "@/components/ghc/gh-pay-panel"

/** Human labels + optional product deep-link (tab or settings section) */
const ENTITLEMENT_META: Partial<
  Record<
    EntitlementKey,
    {
      label: string
      /** Where to open in the app */
      link?: { kind: "tab"; id: string } | { kind: "settings"; section: string }
      icon?: "filter" | "users" | "message" | "store" | "chart" | "image" | "support" | "badge"
    }
  >
> = {
  badge_vip: { label: "VIP badge on profile", link: { kind: "tab", id: "profile" }, icon: "badge" },
  badge_vvip: { label: "VVIP badge on profile", link: { kind: "tab", id: "profile" }, icon: "badge" },
  discovery_advanced_filters: {
    label: "Advanced discovery filters",
    link: { kind: "tab", id: "discover" },
    icon: "filter",
  },
  discovery_priority: {
    label: "Priority in discovery",
    link: { kind: "tab", id: "discover" },
    icon: "filter",
  },
  matching_enhanced_controls: {
    label: "Enhanced matching controls",
    link: { kind: "tab", id: "matches" },
    icon: "users",
  },
  matching_advanced: {
    label: "Advanced matching tools",
    link: { kind: "tab", id: "matches" },
    icon: "users",
  },
  profile_customization: {
    label: "Profile customization",
    link: { kind: "tab", id: "profile" },
    icon: "image",
  },
  profile_premium_presentation: {
    label: "Premium profile presentation",
    link: { kind: "tab", id: "profile" },
    icon: "image",
  },
  boost_post: { label: "Post boosts", link: { kind: "tab", id: "feed" }, icon: "chart" },
  boost_profile: { label: "Profile boosts", link: { kind: "tab", id: "profile" }, icon: "badge" },
  story_analytics: { label: "Story analytics", link: { kind: "tab", id: "feed" }, icon: "chart" },
  marketplace_enhanced_visibility: {
    label: "Marketplace visibility boost",
    link: { kind: "tab", id: "discover" },
    icon: "store",
  },
  marketplace_advanced_tools: {
    label: "Advanced marketplace tools",
    link: { kind: "tab", id: "discover" },
    icon: "store",
  },
  community_premium_tools: {
    label: "Premium community tools",
    link: { kind: "tab", id: "communities" },
    icon: "users",
  },
  community_advanced: {
    label: "Advanced community capabilities",
    link: { kind: "tab", id: "communities" },
    icon: "users",
  },
  media_limits_elevated: {
    label: "Higher media limits",
    link: { kind: "tab", id: "profile" },
    icon: "image",
  },
  media_limits_max: {
    label: "Maximum media / storage limits",
    link: { kind: "tab", id: "profile" },
    icon: "image",
  },
  ghc_earning_boost: {
    label: "×1.5 activity earn multiplier (capped)",
    link: { kind: "settings", section: "rewards" },
    icon: "chart",
  },
  ghc_earning_boost_high: {
    label: "×2 activity earn multiplier (capped)",
    link: { kind: "settings", section: "rewards" },
    icon: "chart",
  },
  platform_fee_discount: {
    label: "Platform fee discount (up to 20% VVIP)",
    link: { kind: "settings", section: "wallet" },
    icon: "store",
  },
  analytics_advanced: {
    label: "Advanced analytics",
    link: { kind: "tab", id: "profile" },
    icon: "chart",
  },
  creator_business_tools: {
    label: "Creator / business tools",
    link: { kind: "tab", id: "profile" },
    icon: "store",
  },
  priority_support: {
    label: "Priority support",
    link: { kind: "settings", section: "help" },
    icon: "support",
  },
  exclusive_experiences: {
    label: "Exclusive experiences",
    link: { kind: "tab", id: "communities" },
    icon: "users",
  },
  storage_elevated: {
    label: "Elevated storage",
    link: { kind: "tab", id: "profile" },
    icon: "image",
  },
}

/** Top upgrades to highlight for Free users (not a long marketing list) */
const NEXT_UPGRADES_FOR_FREE: EntitlementKey[] = [
  "discovery_advanced_filters",
  "matching_enhanced_controls",
  "boost_post",
]

const TIER_ORDER: MembershipTierId[] = ["free", "vip", "vvip"]

const COMPARE_ROWS: { key: string; label: string; free: string; vip: string; vvip: string }[] = [
  { key: "price_m", label: "Monthly (GHC)", free: "0", vip: "200", vvip: "500" },
  { key: "price_y", label: "Yearly (GHC)", free: "0", vip: "1,800", vvip: "4,500" },
  { key: "badge", label: "Profile badge", free: "—", vip: "VIP", vvip: "VVIP Elite" },
  { key: "filters", label: "Discovery filters", free: "Standard", vip: "Advanced", vvip: "Priority + spotlight" },
  { key: "match", label: "Matching tools", free: "Standard", vip: "Enhanced", vvip: "Advanced + exclusive" },
  { key: "boosts", label: "Daily profile/post boosts", free: "0", vip: "3", vvip: "10" },
  { key: "media", label: "Photo limit", free: "6", vip: "12", vvip: "24" },
  { key: "ghc", label: "Activity earn multiplier", free: "×1", vip: "×1.5", vvip: "×2" },
  { key: "fee", label: "Platform fee discount", free: "—", vip: "10%", vvip: "20%" },
  { key: "support", label: "Support", free: "Standard", vip: "Priority chat", vvip: "Priority + agent" },
  { key: "events", label: "Exclusive spaces", free: "—", vip: "VIP rooms", vvip: "VVIP experiences" },
  { key: "missions", label: "Reward track", free: "Standard", vip: "VIP missions", vvip: "Elite missions" },
]

function openEntitlementLink(
  link?: { kind: "tab"; id: string } | { kind: "settings"; section: string }
) {
  if (!link) return
  try {
    if (link.kind === "tab") {
      window.dispatchEvent(new CustomEvent("ghc:navigate-tab", { detail: link.id }))
    } else {
      window.dispatchEvent(
        new CustomEvent("ghc:open-settings-section", { detail: { section: link.section } })
      )
    }
  } catch {
    /* */
  }
}

function formatUntil(ts?: number) {
  if (!ts) return "Active · renew anytime"
  try {
    return `Active until ${new Date(ts).toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
      year: "numeric",
    })}`
  } catch {
    return "Active"
  }
}

function EntitlementIcon({ name }: { name?: string }) {
  const cls = "mt-0.5 shrink-0 text-emerald-600"
  switch (name) {
    case "filter":
      return <Filter size={14} className={cls} />
    case "users":
      return <Users size={14} className={cls} />
    case "message":
      return <MessageCircle size={14} className={cls} />
    case "store":
      return <Store size={14} className={cls} />
    case "chart":
      return <BarChart3 size={14} className={cls} />
    case "image":
      return <ImageIcon size={14} className={cls} />
    case "support":
      return <Headphones size={14} className={cls} />
    case "badge":
      return <BadgeCheck size={14} className={cls} />
    default:
      return <Check size={14} className={cls} />
  }
}

export function PremiumMembershipScreen({ onBack }: { onBack: () => void }) {
  const { addToast } = useGHC()
  const [period, setPeriod] = useState<"monthly" | "yearly">("monthly")
  /** Method-scoped busy — never spin both Pi and GHC from one flag */
  const [busy, setBusy] = useState<{
    tier: MembershipTierId
    method: "pi" | "ghc"
  } | null>(null)

  const [confirmTier, setConfirmTier] = useState<MembershipTierId | null>(null)
  const [successStatus, setSuccessStatus] = useState<MembershipStatus | null>(null)
  const [expandedPlanBenefits, setExpandedPlanBenefits] = useState<Record<string, boolean>>({})
  const [tick, setTick] = useState<number>(0)
  const [refreshing, setRefreshing] = useState(false)
  /** Authoritative status from /api/membership/status */
  const [serverStatus, setServerStatus] = useState<MembershipStatus | null>(null)

  // Prefer server entitlement over local-only cache
  useEffect(() => {
    let cancelled = false
    ;(async () => {
      const next = await refreshMembershipFromServer()
      if (cancelled || !next) return
    })()
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- mount-only authoritative hydrate
  }, [])

  const [faqOpen, setFaqOpen] = useState<string | null>(null)
  const [view, setView] = useState<"cards" | "compare">("cards")

  const status = useMemo(() => {
    void tick
    try {
      return getBoundDomainServices()?.membership?.getStatus?.() || null
    } catch {
      return null
    }
  }, [tick])

  // Server authority wins when present; never invent paid tier from local alone
  const currentTier = (
    serverStatus?.tier ||
    status?.tier ||
    "free"
  ) as MembershipTierId
  const mapEntitlementToStatus = (
    e: Record<string, unknown>
  ): MembershipStatus => {
    const rawTier = String(e.tier || "free").toLowerCase()
    const tier: MembershipTierId =
      rawTier === "vip" || rawTier === "vvip" ? rawTier : "free"
    return {
      userId: String(e.userId || e.user_id || "current-user"),
      tier,
      active: e.active !== false,
      expiresAt:
        e.expiresAt != null && Number.isFinite(Number(e.expiresAt))
          ? Number(e.expiresAt)
          : undefined,
      billingPeriod:
        e.billingPeriod === "yearly" || e.billingPeriod === "monthly"
          ? e.billingPeriod
          : undefined,
      source:
        e.source === "ghc" || e.source === "pi" || e.source === "admin"
          ? e.source === "pi"
            ? "external"
            : (e.source as MembershipStatus["source"])
          : e.source === "external"
            ? "external"
            : "default",
      lastPurchaseTxId: e.purchaseRef ? String(e.purchaseRef) : undefined,
    } satisfies MembershipStatus
  }

  const refreshMembershipFromServer = async (
    _fallbackTier?: MembershipTierId
  ): Promise<MembershipStatus | null> => {
    try {
      const headers: Record<string, string> = {}
      try {
        const { IdentityService } = await import("@/lib/identity/identity-service")
        Object.assign(headers, IdentityService.getAuthHeaders?.() || {})
      } catch {
        /* */
      }
      const res = await fetch("/api/membership/status", {
        headers,
        cache: "no-store",
        credentials: "include",
      })
      if (!res.ok) return null
      const data = await res.json().catch(() => ({}))
      if (!data?.ok || !data?.entitlement) return null
      const e = data.entitlement as Record<string, unknown>
      const mapped = mapEntitlementToStatus(e)
      const mem = getBoundDomainServices()?.membership as {
        activate?: (i: unknown) => Promise<unknown>
        getStatus?: () => MembershipStatus | null
      } | null
      // Sync local domain cache from server authority (paid only — never invent VIP)
      if (mapped.tier === "vip" || mapped.tier === "vvip") {
        await mem?.activate?.({
          tier: mapped.tier,
          billingPeriod: mapped.billingPeriod || "monthly",
          source: e.source === "pi" ? "external" : e.source || "external",
          purchaseTxId: e.purchaseRef,
          durationMs:
            e.expiresAt && e.startedAt
              ? Math.max(0, Number(e.expiresAt) - Number(e.startedAt))
              : undefined,
        })
      }
      setServerStatus(mapped)
      setTick((x) => x + 1)
      return mapped
    } catch {
      return null
    }
  }

  const handleRefreshMembership = async () => {
    if (refreshing) return
    setRefreshing(true)
    try {
      const next = await refreshMembershipFromServer()
      if (next) {
        addToast(
          next.tier === "free"
            ? "Membership is Free"
            : `${MEMBERSHIP_PLANS[next.tier].label} is active`,
          "success"
        )
      } else {
        addToast("Could not refresh membership status", "error")
      }
    } finally {
      setRefreshing(false)
    }
  }

  const purchaseWithPiCoin = async (tier: MembershipTierId) => {
    if (tier === "free" || tier === currentTier) return
    setBusy({ tier, method: "pi" })
    try {
      const ok = await runGhPayMembership(tier as "vip" | "vvip", period, (msg, type) => {
        const t =
          type === "error" || type === "success" || type === "info" ? type : "info"
        addToast(msg, t)
      })
      if (ok) {
        setConfirmTier(null)
        // Server grants on complete/fulfill; poll status until paid tier appears or retries exhaust
        let next = await refreshMembershipFromServer(tier)
        for (let i = 0; i < 3 && (!next || next.tier === "free"); i++) {
          await new Promise((r) => setTimeout(r, 800 + i * 400))
          next = await refreshMembershipFromServer(tier)
        }
        if (next && (next.tier === "vip" || next.tier === "vvip")) {
          setSuccessStatus(next)
          addToast(`${MEMBERSHIP_PLANS[next.tier].label} is active`, "success")
        } else {
          setTick((x) => x + 1)
          addToast(
            "Payment received. Membership activation is finishing — tap Refresh if Premium is not shown yet. You will not be charged again.",
            "info"
          )
        }
      }
    } finally {
      setBusy(null)
    }
  }

  const purchaseWithGhcCoin = async (tier: MembershipTierId) => {
    if (tier === "free" || tier === currentTier) return
    setBusy({ tier, method: "ghc" })
    try {
      const mem = getBoundDomainServices()?.membership
      if (!mem?.purchaseWithGhc) {
        addToast("Membership purchase unavailable offline", "error")
        return
      }
      const result = await mem.purchaseWithGhc(tier, period)
      if (result.ok) {
        setConfirmTier(null)
        let next = await refreshMembershipFromServer(tier)
        if (!next) {
          try {
            next = getBoundDomainServices()?.membership?.getStatus?.() || null
          } catch {
            next = null
          }
        }
        if (next) setSuccessStatus(next)
        setTick((x) => x + 1)
        addToast(`${MEMBERSHIP_PLANS[tier].label} activated`, "success")
      } else {
        addToast(result.error || "Purchase failed", "error")
      }
    } catch (e) {
      addToast(e instanceof Error ? e.message : "Purchase failed", "error")
    } finally {
      setBusy(null)
    }
  }

  const purchase = async (tier: MembershipTierId, method: "pi" | "ghc" = "ghc") => {
    if (tier === "free" || tier === currentTier) return
    if (method === "pi") {
      await purchaseWithPiCoin(tier)
      return
    }
    await purchaseWithGhcCoin(tier)
  }

  // Close success sheet on back navigation cleanup
  useEffect(() => {
    return () => setSuccessStatus(null)
  }, [])

  return (
    <div className="relative flex h-full min-h-0 flex-col bg-background text-foreground">
      <header className="flex shrink-0 items-center gap-2 border-b border-border bg-card px-3 py-3">
        <button
          type="button"
          onClick={onBack}
          className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-muted"
          aria-label="Back"
        >
          <ArrowLeft size={18} />
        </button>
        <div className="min-w-0 flex-1">
          <h1 className="text-sm font-bold text-foreground">Membership</h1>
          <p className="text-[11px] text-muted-foreground">
            Current:{" "}
            <span className="font-semibold text-emerald-700">
              {MEMBERSHIP_PLANS[currentTier].label}
            </span>
            {status?.source === "trial" || (status as { lifecycle?: string } | null)?.lifecycle === "trial" ? (
              <span className="text-muted-foreground">
                {" "}
                · welcome trial
                {status?.expiresAt ? ` · ends ${formatUntil(status.expiresAt)}` : ""}
              </span>
            ) : status?.expiresAt ? (
              <span className="text-muted-foreground"> · {formatUntil(status.expiresAt)}</span>
            ) : null}
          </p>
        </div>
        <button
          type="button"
          onClick={() => void handleRefreshMembership()}
          disabled={refreshing}
          className="inline-flex min-h-8 items-center gap-1 rounded-full bg-muted px-2.5 py-1 text-[11px] font-semibold text-muted-foreground disabled:opacity-60"
          aria-label="Refresh membership status from server"
        >
          {refreshing ? (
            <>
              <Loader2 className="h-3 w-3 animate-spin" aria-hidden />
              Refreshing…
            </>
          ) : (
            "Refresh"
          )}
        </button>
      </header>

      <div
        className="min-h-0 flex-1 overflow-y-auto overscroll-y-contain px-3 py-3 scrollbar-hide [-webkit-overflow-scrolling:touch] touch-pan-y"
        style={{ paddingBottom: "var(--gh-screen-bottom-inset)" }}
      >
        <div className="mb-3 flex items-start gap-2 rounded-2xl border border-border bg-card px-3 py-2.5">
          <Info size={14} className="mt-0.5 shrink-0 text-muted-foreground" />
          <p className="text-[11px] leading-relaxed text-muted-foreground">
            Membership is separate from <strong className="text-foreground">verification</strong>, reputation
            and GHC balance. <strong className="text-foreground">Verification ≠ VIP</strong>. Benefits come
            from entitlements — no urgency timers or “only 2 left” claims. Review what you get before confirming.
          </p>
        </div>

        {/* What you have now / next upgrades (Free-focused) */}
        {currentTier === "free" && (
          <div className="mb-3 rounded-2xl border border-emerald-100 bg-emerald-50/80 px-3 py-3 dark:border-emerald-900 dark:bg-emerald-950/30">
            <p className="text-sm font-bold text-foreground">What matters next</p>
            <p className="mt-0.5 text-[11px] text-muted-foreground">
              On Free you already have full social access. These are the upgrades people use most —
              not a long sales list.
            </p>
            <ul className="mt-2 space-y-1.5">
              {NEXT_UPGRADES_FOR_FREE.map((key) => {
                const meta = ENTITLEMENT_META[key]
                return (
                  <li key={key}>
                    <button
                      type="button"
                      onClick={() => openEntitlementLink(meta?.link)}
                      className="flex w-full items-center gap-2 rounded-xl bg-white/80 px-2.5 py-2 text-left text-[12px] font-medium text-foreground dark:bg-card/80"
                    >
                      <EntitlementIcon name={meta?.icon} />
                      <span className="min-w-0 flex-1">{meta?.label || key}</span>
                      <span className="text-[10px] font-bold text-emerald-700">VIP+</span>
                      <ChevronRight size={14} className="text-muted-foreground" />
                    </button>
                  </li>
                )
              })}
            </ul>
          </div>
        )}

        {/* Current plan — product-tier presentation */}
        {status?.active && (
          <div
            className={`mb-3 overflow-hidden rounded-2xl border shadow-sm ${
              currentTier === "vvip"
                ? "border-amber-300/80 bg-gradient-to-br from-amber-50 via-card to-violet-50 dark:border-amber-800 dark:from-amber-950/40"
                : currentTier === "vip"
                  ? "border-violet-300/80 bg-gradient-to-br from-violet-50 via-card to-emerald-50 dark:border-violet-800 dark:from-violet-950/40"
                  : "border-border bg-card"
            }`}
          >
            <div className="flex items-start justify-between gap-2 px-4 pt-4">
              <div>
                <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-muted-foreground">
                  Your membership
                </p>
                <p className="mt-0.5 flex items-center gap-1.5 text-xl font-black text-foreground">
                  <Crown
                    size={20}
                    className={
                      currentTier === "vvip"
                        ? "text-amber-600"
                        : currentTier === "vip"
                          ? "text-violet-600"
                          : "text-muted-foreground"
                    }
                  />
                  {MEMBERSHIP_PLANS[currentTier].label}
                </p>
                {status?.expiresAt ? (
                  <p className="mt-1 text-[12px] font-semibold text-muted-foreground">
                    {status.source === "trial" || (status as { lifecycle?: string }).lifecycle === "trial"
                      ? `Welcome trial · ends ${formatUntil(status.expiresAt)}`
                      : `Membership expires ${formatUntil(status.expiresAt)}`}
                  </p>
                ) : (
                  <p className="mt-1 text-[12px] text-muted-foreground">Standard access · upgrade anytime</p>
                )}
              </div>
              {currentTier !== "free" ? (
                <button
                  type="button"
                  onClick={() => {
                    const el = document.getElementById(`membership-plan-${currentTier}`)
                    el?.scrollIntoView({ behavior: "smooth", block: "center" })
                  }}
                  className="shrink-0 rounded-full bg-foreground px-3.5 py-2 text-[12px] font-bold text-background"
                >
                  Renew
                </button>
              ) : null}
            </div>
            <div className="px-4 pb-4 pt-3">
              <p className="mb-2 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                Your benefits
              </p>
              <ul className="space-y-1.5">
                {(currentTier === "free"
                  ? [
                      "Full social access · feed, messages, communities",
                      "Earn GHC through activity (standard daily cap)",
                      "GreenHaven ID · QR · profile",
                      "Upgrade anytime for discovery priority & boosts",
                    ]
                  : currentTier === "vip"
                    ? [
                        "Higher daily GHC earning limit (1.5×)",
                        "Enhanced profile visibility in discovery",
                        "VIP badge on your profile",
                        "More discovery exposure & advanced filters",
                        "Post & profile boosts",
                        "Priority support",
                      ]
                    : [
                        "Highest daily GHC earning limit (2×)",
                        "Maximum discovery priority",
                        "VVIP badge & premium profile presentation",
                        "Advanced matching & analytics",
                        "Creator / business tools",
                        "Exclusive experiences & elevated storage",
                      ]
                ).map((line) => (
                  <li key={line} className="flex items-start gap-2 text-[12px] font-medium text-foreground">
                    <Check size={14} className="mt-0.5 shrink-0 text-emerald-600" strokeWidth={2.5} />
                    <span>{line}</span>
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-center text-[10px] font-semibold text-muted-foreground">
                Free → VIP → VVIP · compare plans below
              </p>
            </div>
          </div>
        )}

                <p className="mb-2 px-0.5 text-[12px] font-bold text-foreground">
          Compare Free → VIP → VVIP
        </p>

        {/* Period — calm, no pressure */}
        <div className="mb-2 flex gap-1 rounded-2xl border border-border bg-card p-1">
          <button
            type="button"
            onClick={() => setPeriod("monthly")}
            className={`flex-1 rounded-xl py-2 text-xs font-bold ${
              period === "monthly" ? "bg-emerald-700 text-white" : "text-muted-foreground"
            }`}
          >
            Monthly
          </button>
          <button
            type="button"
            onClick={() => setPeriod("yearly")}
            className={`flex-1 rounded-xl py-2 text-xs font-bold ${
              period === "yearly" ? "bg-emerald-700 text-white" : "text-muted-foreground"
            }`}
          >
            Yearly
          </button>
        </div>
        <p className="mb-3 px-1 text-[10px] text-muted-foreground">
          Prices in GHC (in-app utility). No external auto-charge is implied.
        </p>

        {/* View toggle */}
        <div className="mb-3 flex gap-1 rounded-2xl border border-border bg-card p-1">
          <button
            type="button"
            onClick={() => setView("cards")}
            className={`flex-1 rounded-xl py-1.5 text-[11px] font-bold ${
              view === "cards" ? "bg-muted text-foreground" : "text-muted-foreground"
            }`}
          >
            Plans
          </button>
          <button
            type="button"
            onClick={() => setView("compare")}
            className={`flex-1 rounded-xl py-1.5 text-[11px] font-bold ${
              view === "compare" ? "bg-muted text-foreground" : "text-muted-foreground"
            }`}
          >
            Compare side-by-side
          </button>
        </div>

        {view === "compare" ? (
          <div className="mb-8 overflow-x-auto rounded-2xl border border-border bg-card">
            <table className="w-full min-w-[320px] border-collapse text-left text-[11px]">
              <thead className="sticky top-0 z-10 bg-card">
                <tr className="border-b border-border">
                  <th className="sticky left-0 bg-card px-2 py-2.5 font-bold text-muted-foreground">
                    Feature
                  </th>
                  {TIER_ORDER.map((t) => (
                    <th
                      key={t}
                      className={`px-2 py-2.5 text-center font-bold ${
                        currentTier === t ? "text-emerald-700" : "text-foreground"
                      }`}
                    >
                      {MEMBERSHIP_PLANS[t].label}
                      {currentTier === t ? (
                        <span className="mt-0.5 block text-[9px] font-semibold uppercase">You</span>
                      ) : null}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {COMPARE_ROWS.map((row) => (
                  <tr key={row.key} className="border-b border-border/60">
                    <td className="sticky left-0 bg-card px-2 py-2 font-medium text-muted-foreground">
                      {row.label}
                    </td>
                    <td className="px-2 py-2 text-center text-foreground">{row.free}</td>
                    <td className="px-2 py-2 text-center text-foreground">{row.vip}</td>
                    <td className="px-2 py-2 text-center text-foreground">{row.vvip}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="border-t border-border px-3 py-2 text-[10px] text-muted-foreground">
              Scroll horizontally on small screens. Entitlements below open the real product area.
            </p>
          </div>
        ) : (
          /* Full-width vertical stack — every plan scrolls with the page (no clipped horizontal cards) */
          <div className="flex flex-col gap-4">
            <p className="px-1 text-[11px] text-muted-foreground">
              Scroll down to review Free, VIP and VVIP. All benefits are fully visible.
            </p>
            {TIER_ORDER.map((tier) => {
              const plan = MEMBERSHIP_PLANS[tier]
              const isCurrent = currentTier === tier
              const price =
                tier === "free"
                  ? 0
                  : period === "monthly"
                    ? plan.priceGhcMonthly
                    : plan.priceGhcYearly
              const accent =
                tier === "vvip"
                  ? "border-amber-200/80 from-amber-50/80 to-card dark:from-amber-950/20"
                  : tier === "vip"
                    ? "border-emerald-200 from-emerald-50/80 to-card dark:from-emerald-950/20"
                    : "border-border from-card to-card"
              const ring = isCurrent ? "ring-2 ring-emerald-500" : ""

              return (
                <article
                  key={tier}
                  id={`membership-plan-${tier}`}
                  aria-current={isCurrent ? "true" : undefined}
                  className={`w-full rounded-3xl border bg-gradient-to-b p-4 shadow-sm ${accent} ${ring}`}
                >
                  <div className="mb-1">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {tier === "vvip" ? (
                          <Crown size={18} className="text-amber-700" />
                        ) : tier === "vip" ? (
                          <Sparkles size={18} className="text-emerald-600" />
                        ) : (
                          <span className="flex h-[18px] w-[18px] items-center justify-center rounded-full bg-muted text-[10px] font-bold text-muted-foreground">
                            F
                          </span>
                        )}
                        <div>
                          <h2 className="text-[20px] font-bold leading-tight text-foreground">{plan.label}</h2>
                          {isCurrent && (
                            <span className="mt-0.5 inline-block rounded-full bg-emerald-600 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
                              Current
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="inline-flex items-center gap-1 text-lg font-bold text-foreground">
                          {price === 0 ? (
                            "Free"
                          ) : (
                            <>
                              <GhcCoinIcon size={20} />
                              {price} GHC
                            </>
                          )}
                        </p>
                        {price > 0 ? (
                          <p className="text-[10px] text-muted-foreground">
                            / {period === "monthly" ? "month" : "year"} · in-app GHC only
                          </p>
                        ) : (
                          <p className="text-[10px] text-muted-foreground">Always included</p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Badge preview */}
                  <div className="mt-2 flex items-center gap-2 rounded-xl border border-border/60 bg-background/80 px-2.5 py-2">
                    <div className="flex h-9 w-9 items-center justify-center rounded-full bg-muted text-[11px] font-bold">
                      You
                    </div>
                    <div className="min-w-0">
                      <p className="truncate text-[12px] font-semibold text-foreground">Profile badge</p>
                      <p className="text-[11px] text-muted-foreground">
                        {tier === "free" ? "No plan badge" : tier === "vip" ? "VIP badge" : "VVIP badge"}
                      </p>
                    </div>
                  </div>

                  <ul className="mt-3 space-y-1.5">
                    <li className="flex items-start gap-2 text-[14px] text-muted-foreground">
                      <Check size={14} className="mt-0.5 shrink-0 text-emerald-600" />
                      Media: up to {plan.mediaMaxPhotos} photos · stories ~{plan.mediaMaxStoryMb}MB
                    </li>
                    <li className="flex items-start gap-2 text-[14px] text-muted-foreground">
                      <Check size={14} className="mt-0.5 shrink-0 text-emerald-600" />
                      Daily boosts: {plan.dailyBoosts}
                    </li>
                    {plan.ghcDailyEarnMultiplier > 1 && (
                      <li className="flex items-start gap-2 text-[14px] text-muted-foreground">
                        <Check size={14} className="mt-0.5 shrink-0 text-emerald-600" />
                        GHC earn multiplier ×{plan.ghcDailyEarnMultiplier}
                      </li>
                    )}
                    {plan.platformFeeDiscountPct > 0 && (
                      <li className="flex items-start gap-2 text-[14px] text-muted-foreground">
                        <Check size={14} className="mt-0.5 shrink-0 text-emerald-600" />
                        Platform fee discount {plan.platformFeeDiscountPct}%
                      </li>
                    )}
                    {(expandedPlanBenefits[tier] ? plan.entitlements : plan.entitlements.slice(0, 5)).map((key) => {
                      const meta = ENTITLEMENT_META[key]
                      const label = meta?.label || key
                      const clickable = !!meta?.link
                      return (
                        <li key={key}>
                          {clickable ? (
                            <button
                              type="button"
                              onClick={() => openEntitlementLink(meta?.link)}
                              className="flex w-full items-start gap-2 rounded-lg py-0.5 text-left text-[13px] text-foreground transition hover:bg-muted/60"
                            >
                              <EntitlementIcon name={meta?.icon} />
                              <span className="min-w-0 flex-1 underline-offset-2 hover:underline">
                                {label}
                              </span>
                              <ChevronRight size={14} className="mt-0.5 shrink-0 text-muted-foreground" />
                            </button>
                          ) : (
                            <span className="flex items-start gap-2 text-[14px] text-muted-foreground">
                              <Check size={14} className="mt-0.5 shrink-0 text-emerald-600" />
                              {label}
                            </span>
                          )}
                        </li>
                      )
                    })}
                    {tier === "free" && !expandedPlanBenefits[tier] && (
                      <li className="flex items-start gap-2 text-[14px] text-muted-foreground">
                        <X size={14} className="mt-0.5 shrink-0 text-muted-foreground/40" />
                        No paid boosts or priority placement
                      </li>
                    )}
                    {plan.entitlements.length > 5 ? (
                      <li>
                        <button
                          type="button"
                          onClick={() =>
                            setExpandedPlanBenefits((m) => ({
                              ...m,
                              [tier]: !m[tier],
                            }))
                          }
                          className="mt-1 text-[12px] font-semibold text-emerald-700 dark:text-emerald-300"
                        >
                          {expandedPlanBenefits[tier]
                            ? "Show less"
                            : `View all benefits (${plan.entitlements.length})`}
                        </button>
                      </li>
                    ) : null}
                  </ul>

                  {tier !== "free" && !isCurrent && (
                    <button
                      type="button"
                      onClick={() => setConfirmTier(tier)}
                      className="mt-4 w-full rounded-2xl bg-emerald-600 py-2.5 text-sm font-bold text-white transition hover:bg-emerald-700 active:scale-[0.99]"
                    >
                      Review {plan.label}
                    </button>
                  )}
                  {isCurrent && (
                    <p className="mt-3 text-center text-[11px] font-semibold text-emerald-700">
                      {formatUntil(status?.expiresAt)}
                    </p>
                  )}
                </article>
              )
            })}
          </div>
        )}

        {/* FAQ */}
        <div className="mt-4 rounded-2xl border border-border bg-card p-3 shadow-sm">
          <p className="text-[12px] font-bold text-foreground">Membership FAQ</p>
          {(
            [
              {
                id: "trial",
                q: "What is the welcome trial?",
                a: "New accounts may receive time-based VVIP then VIP access calculated from account creation time. Refreshing the app does not reset the trial.",
              },
              {
                id: "verify",
                q: "Is VIP the same as verification?",
                a: "No. Verification means authenticity. VIP/VVIP is a membership entitlement and never replaces verification.",
              },
              {
                id: "pay",
                q: "How do I pay?",
                a: "In the Pi Browser, upgrades prefer Pay with π (User-to-App). Offline Studio can use available GHC from your wallet. Card billing is not used.",
              },
              {
                id: "cancel",
                q: "Can I stay on Free?",
                a: "Yes. Free keeps core social access. You can review VIP/VVIP anytime without pressure.",
              },
            ] as const
          ).map((item) => (
            <div key={item.id} className="mt-2 border-t border-border pt-2">
              <button
                type="button"
                onClick={() => setFaqOpen((v) => (v === item.id ? null : item.id))}
                className="flex min-h-11 w-full items-center justify-between gap-2 text-left text-[14px] font-semibold text-foreground"
                aria-expanded={faqOpen === item.id}
              >
                {item.q}
                <span className="text-muted-foreground">{faqOpen === item.id ? "−" : "+"}</span>
              </button>
              {faqOpen === item.id && (
                <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">{item.a}</p>
              )}
            </div>
          ))}
        </div>

        {/* Explicit end spacer so last FAQ / plan actions clear device chrome & home indicator */}
        <div className="h-8 shrink-0" aria-hidden="true" />
      </div>

      {/* Honest confirm — no countdown / fake scarcity */}
      {confirmTier && (
        <div className="absolute inset-0 z-40 flex items-end bg-black/40 sm:items-center sm:justify-center">
          <div className="w-full max-w-md rounded-t-3xl bg-card p-5 shadow-xl sm:rounded-3xl">
            <h3 className="text-base font-bold text-foreground">
              Confirm {MEMBERSHIP_PLANS[confirmTier].label}
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              You will spend{" "}
              <strong className="text-foreground">
                {period === "monthly"
                  ? MEMBERSHIP_PLANS[confirmTier].priceGhcMonthly
                  : MEMBERSHIP_PLANS[confirmTier].priceGhcYearly}{" "}
                GHC
              </strong>{" "}
              from your wallet for a {period} period. Benefits activate via the entitlement system.
              This does not change verification or reputation.
            </p>
            <ul className="mt-3 max-h-32 space-y-1 overflow-y-auto rounded-xl bg-muted/50 px-3 py-2">
              {MEMBERSHIP_PLANS[confirmTier].entitlements.slice(0, 6).map((key) => (
                <li key={key} className="flex items-center gap-2 text-[11px] text-foreground">
                  <Check size={12} className="text-emerald-600" />
                  {ENTITLEMENT_META[key]?.label || key}
                </li>
              ))}
            </ul>
            <p className="mt-2 text-[11px] text-muted-foreground">
              You can stay on Free anytime. No auto-charge of external currency is implied.
            </p>
            <p className="mt-3 text-[11px] font-semibold text-muted-foreground">Payment methods</p>
            <div className="mt-2 flex flex-col gap-2">
              {isPiPaymentsAvailable() ? (
                <button
                  type="button"
                  disabled={busy?.tier === confirmTier && busy?.method === "pi"}
                  onClick={() => void purchase(confirmTier, "pi")}
                  className="flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl bg-emerald-600 py-2.5 text-sm font-bold text-white disabled:opacity-60"
                >
                  {busy?.tier === confirmTier && busy?.method === "pi" ? (
                    <Loader2 size={16} className="animate-spin" aria-hidden />
                  ) : null}
                  Pay with π
                </button>
              ) : (
                <p className="rounded-xl bg-muted/50 px-3 py-2 text-[11px] text-muted-foreground">
                  Pay with π is available in the Pi Browser after GH Pay is configured.
                </p>
              )}
              <button
                type="button"
                disabled={busy?.tier === confirmTier && busy?.method === "ghc"}
                onClick={() => void purchase(confirmTier, "ghc")}
                className="flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl border border-emerald-600/40 bg-card py-2.5 text-sm font-bold text-emerald-800 dark:text-emerald-300 disabled:opacity-60"
              >
                {busy?.tier === confirmTier && busy?.method === "ghc" ? (
                  <Loader2 size={16} className="animate-spin" aria-hidden />
                ) : null}
                Pay with GHC
              </button>
              <button
                type="button"
                onClick={() => setConfirmTier(null)}
                className="w-full rounded-2xl border border-border py-2.5 text-sm font-bold text-foreground"
              >
                Cancel
              </button>
            </div>
            <p className="mt-2 text-[10px] text-muted-foreground">
              Entitlement is granted by the server after payment is verified — the app never self-assigns VIP/VVIP.
            </p>
          </div>
        </div>
      )}

      {/* Post-purchase confirmation — only after server-confirmed VIP/VVIP */}
      {successStatus &&
        (successStatus.tier === "vip" || successStatus.tier === "vvip") && (
        <div
          className="absolute inset-0 z-50 flex items-end bg-black/45 sm:items-center sm:justify-center"
          role="dialog"
          aria-modal="true"
          aria-labelledby="membership-success-title"
        >
          <div className="relative w-full max-w-md overflow-hidden rounded-t-3xl border border-emerald-200/80 bg-card p-5 shadow-xl dark:border-emerald-800 sm:mb-8 sm:rounded-3xl">
            {/* Brief celebratory accent — respects reduced motion */}
            <div
              className="pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-emerald-400/25 via-teal-300/10 to-transparent motion-safe:animate-pulse"
              aria-hidden
            />
            <div className="relative flex items-center gap-3">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-600 text-white shadow-lg shadow-emerald-600/30 motion-safe:scale-100">
                <Sparkles size={22} aria-hidden />
              </span>
              <div>
                <h3
                  id="membership-success-title"
                  className="text-base font-bold text-foreground"
                >
                  {MEMBERSHIP_PLANS[successStatus.tier].label} is active
                </h3>
                <p className="text-[12px] font-medium text-emerald-700 dark:text-emerald-300">
                  Payment verified · {formatUntil(successStatus.expiresAt)}
                </p>
              </div>
            </div>
            <p className="relative mt-3 text-[12px] text-muted-foreground">
              Your plan is live. Entitlements below are available now.
            </p>
            <ul className="relative mt-3 max-h-48 space-y-1 overflow-y-auto">
              {MEMBERSHIP_PLANS[successStatus.tier].entitlements.map((key) => {
                const meta = ENTITLEMENT_META[key]
                return (
                  <li key={key}>
                    <button
                      type="button"
                      onClick={() => {
                        openEntitlementLink(meta?.link)
                        setSuccessStatus(null)
                      }}
                      className="flex w-full items-center gap-2 rounded-xl px-2 py-1.5 text-left text-[12px] font-medium text-foreground hover:bg-muted"
                    >
                      <EntitlementIcon name={meta?.icon} />
                      <span className="min-w-0 flex-1">{meta?.label || key}</span>
                      <ChevronRight size={14} className="text-muted-foreground" />
                    </button>
                  </li>
                )
              })}
            </ul>
            <button
              type="button"
              onClick={() => setSuccessStatus(null)}
              className="relative mt-4 w-full rounded-2xl bg-emerald-600 py-2.5 text-sm font-bold text-white transition active:scale-[0.99]"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
