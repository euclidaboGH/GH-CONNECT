"use client"

import { useState, useMemo, useRef, useCallback, useEffect, memo, type KeyboardEvent } from "react"
import { Send, Smile, Paperclip, X, Search, MessageCircle, Pin, Archive, VolumeX, AudioLines, FileText, Play, Phone, Video, Images, Info , Mic } from "lucide-react"
import type { Conversation } from "@/lib/ghc-types"
import { timeAgo } from "@/lib/ghc-data"
import { LazyImage } from "./lazy-image"
import { downloadMedia } from "@/lib/media/download-media"
// Import for re-export: enhanced group message component available
// Group chats use MessageScreen threads (conversationType/group). EnhancedGroupMessage is deprecated.
// This file preserves private message components and maintains separation of concerns

// Empty state when no conversations exist
export function EmptyMessagesState({
  onNavigateToMatches,
  onNavigateToFind,
  hasMatches = false,
  hasConnections = false,
}: {
  onNavigateToMatches: () => void
  onNavigateToFind?: () => void
  /** Only show icebreakers when user already has a match or connection */
  hasMatches?: boolean
  hasConnections?: boolean
}) {
  const canIcebreak = hasMatches || hasConnections
  return (
    <div className="flex flex-1 flex-col items-center justify-center bg-background px-4 py-12 text-center">
      <div className="relative mb-4">
        <div className="gh-icon-tile flex h-20 w-20 items-center justify-center rounded-[1.25rem] bg-emerald-50 ring-1 ring-emerald-100 dark:bg-emerald-950/40 dark:ring-emerald-900/40" aria-hidden="true">
          <MessageCircle size={40} className="text-emerald-600" />
        </div>
      </div>
      <h3 className="mb-2 text-lg font-bold tracking-tight text-foreground">No messages yet</h3>
      <p className="mb-4 max-w-xs text-sm text-muted-foreground">
        {canIcebreak
          ? "Say hello to someone you’ve matched or connected with."
          : "Message people you’ve matched or connected with. Strangers stay under Requests until you accept."}
      </p>

      {canIcebreak ? (
        <div className="mb-5 w-full max-w-xs space-y-1.5 text-left">
          <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
            Icebreaker ideas
          </p>
          {[
            "You matched — what’s one goal you’re focused on this month?",
            "Loved your profile note about mentoring. Mind if I ask one question?",
            "We share a community — any tips for someone just joining?",
          ].map((line) => (
            <p
              key={line}
              className="rounded-xl border border-border bg-card px-3 py-2 text-[12px] leading-snug text-foreground"
            >
              “{line}”
            </p>
          ))}
        </div>
      ) : null}

      <div className="flex w-full max-w-xs flex-col gap-2">
        <button
          type="button"
          onClick={onNavigateToMatches}
          className="w-full rounded-2xl bg-emerald-600 px-6 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-emerald-700 active:scale-[0.98]"
        >
          {hasMatches ? "Message a match" : "Open Matches"}
        </button>
        <button
          type="button"
          onClick={() => {
            if (onNavigateToFind) onNavigateToFind()
            else window.dispatchEvent(new CustomEvent("ghc:navigate-tab", { detail: "discover" }))
          }}
          className="w-full rounded-2xl border border-border bg-card px-6 py-3 text-sm font-bold text-foreground transition hover:bg-muted active:scale-[0.98]"
        >
          Find people
        </button>
        <button
          type="button"
          onClick={() => {
            try {
              window.dispatchEvent(new CustomEvent("ghc:navigate-tab", { detail: "communities" }))
            } catch {
              /* */
            }
          }}
          className="w-full rounded-2xl border border-transparent px-6 py-2.5 text-[13px] font-semibold text-emerald-700 hover:bg-emerald-50 dark:text-emerald-300 dark:hover:bg-emerald-950/30"
        >
          Browse communities
        </button>
      </div>
      <p className="mt-4 max-w-xs text-[11px] leading-relaxed text-muted-foreground">
        <span className="font-semibold text-foreground">Matches</span> = people ready to chat.{" "}
        <span className="font-semibold text-foreground">Find people</span> = discover new connections.{" "}
        Requests hold messages from people you have not accepted yet.
      </p>
    </div>
  )
}


export function ConversationSearchBar({ searchQuery, onSearchChange }: { searchQuery: string; onSearchChange: (query: string) => void }) {
  return (
    <div className="relative">
      <div className="relative flex items-center">
        <Search size={16} className="pointer-events-none absolute left-3 text-muted-foreground" />
        <input
          type="search"
          placeholder="Search name or message…"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="min-h-10 w-full rounded-xl border border-border bg-background py-2 pl-9 pr-9 text-sm text-foreground placeholder:text-muted-foreground transition focus:border-primary/40 focus:outline-none focus:ring-2 focus:ring-primary/20"
        />
        {searchQuery && (
          <button type="button" onClick={() => onSearchChange("")} className="absolute right-3 text-muted-foreground hover:text-foreground active:scale-90 transition" aria-label="Clear search">
            <X size={16} aria-hidden />
          </button>
        )}
      </div>
    </div>
  )
}

// Individual conversation list item with actions - optimized rendering
function ConversationItemBase({
  conversation,
  isSelected,
  onClick,
  onPin,
  onArchive,
  onMute,
  onOpenProfile,
}: {
  conversation: Conversation
  isSelected: boolean
  onClick: () => void
  onPin?: (conversationId: string, pinned: boolean) => void
  onArchive?: (conversationId: string, archived: boolean) => void
  onMute?: (conversationId: string, muted: boolean) => void
  onOpenProfile?: () => void
}) {
  const hasUnread = conversation.unread || Boolean(conversation.unreadCount)
  const unreadCount = conversation.unreadCount || (conversation.unread ? 1 : 0)
  const isCommunity =
    conversation.conversationType === "group" ||
    Boolean((conversation as { isCommunity?: boolean }).isCommunity) ||
    (conversation as { kind?: string }).kind === "community"
  const displayName = (
    isCommunity
      ? conversation.groupName || conversation.participantName
      : conversation.participantName || conversation.groupName
  )?.trim() || (isCommunity ? "Community" : "Member")
  const messagePreview = useMemo(() => {
    if (conversation.isTyping) return `${conversation.typingUser || conversation.participantName} is typing…`
    if (!conversation.lastMessage) return "Start a conversation"
    return conversation.lastMessage.length > 54 ? `${conversation.lastMessage.substring(0, 54)}…` : conversation.lastMessage
  }, [conversation.lastMessage, conversation.isTyping, conversation.typingUser, conversation.participantName])
  const timestamp = conversation.lastMessageTime ? timeAgo(conversation.lastMessageTime) : ""

  return (
    <div
      className={`group border-b border-border/25 transition-colors ${isSelected ? "bg-emerald-50/80 dark:bg-emerald-950/40" : "bg-card hover:bg-muted/40"}`}
      style={{ contentVisibility: "auto", containIntrinsicSize: "0 72px" }}
    >
      <div className="flex min-h-[76px] w-full items-center px-3.5 py-3.5 text-left transition active:bg-emerald-50/50 sm:px-4">
        <div className="flex min-w-0 flex-1 items-center gap-3">
          <div className="relative shrink-0">
            <button
              type="button"
              onClick={(event) => {
                event.stopPropagation()
                onOpenProfile?.()
              }}
              className="block min-h-[44px] min-w-[44px] rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              aria-label={
                conversation.conversationType === "group" ||
                (conversation as { isCommunity?: boolean }).isCommunity ||
                (conversation as { kind?: string }).kind === "community"
                  ? `Open community ${displayName}`
                  : `Open ${displayName}'s profile`
              }
            >
              <LazyImage
                src={
                  conversation.groupPhoto ||
                  conversation.participantPhoto
                }
                alt={
                  conversation.conversationType === "group" ||
                  (conversation as { isCommunity?: boolean }).isCommunity
                    ? `${displayName} community`
                    : `${displayName} profile photo`
                }
                className={
                  conversation.conversationType === "group" ||
                  (conversation as { isCommunity?: boolean }).isCommunity ||
                  (conversation as { kind?: string }).kind === "community"
                    ? "h-12 w-12 rounded-xl bg-emerald-50 object-cover ring-1 ring-emerald-200/80"
                    : "h-12 w-12 rounded-full bg-muted object-cover ring-1 ring-border/50"
                }
              />
            </button>
            {conversation.conversationType === "group" ||
            (conversation as { isCommunity?: boolean }).isCommunity ||
            (conversation as { kind?: string }).kind === "community" ? (
              <span
                className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-md border-2 border-white bg-sky-500 text-[8px] font-bold text-white"
                aria-label="Community"
              >
                C
              </span>
            ) : (
              <span
                className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-white ${conversation.online ? "bg-emerald-500" : "bg-muted-foreground/40"}`}
                aria-label={conversation.online ? "Online" : "Offline"}
              />
            )}
          </div>

          <button
            type="button"
            onClick={onClick}
            className="min-w-0 flex-1 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded-lg"
            aria-label={`Open conversation with ${displayName}`}
          >
            <div className="flex items-center gap-2">
              <p className={`min-w-0 flex-1 truncate text-[15px] text-foreground ${hasUnread ? "font-semibold" : "font-medium"}`}>
                {(conversation.conversationType === "group" || (conversation as { isCommunity?: boolean }).isCommunity)
                  ? `Community · ${displayName}`
                  : displayName}
                {(conversation as { isRequest?: boolean }).isRequest ? (
                  <span className="ml-1.5 rounded-full bg-amber-100 px-1.5 py-0.5 text-[9px] font-bold text-amber-800">Request</span>
                ) : conversation.conversationType === "group" || (conversation as { isCommunity?: boolean }).isCommunity ? (
                  <span className="ml-1.5 rounded-full bg-sky-100 px-1.5 py-0.5 text-[9px] font-bold text-sky-800">Community</span>
                ) : (
                  <span className="ml-1.5 rounded-full bg-muted px-1.5 py-0.5 text-[9px] font-bold text-muted-foreground">DM</span>
                )}
              </p>
              <time dateTime={conversation.lastMessageTime ? new Date(conversation.lastMessageTime).toISOString() : undefined} className={`shrink-0 text-[11px] ${hasUnread ? "font-bold text-emerald-600" : "text-muted-foreground"}`}>
                {timestamp}
              </time>
            </div>
            <div className="mt-0.5 flex items-center gap-2">
              <p className={`min-w-0 flex-1 truncate text-[13px] ${conversation.isTyping ? "font-semibold text-emerald-600" : hasUnread ? "font-medium text-foreground" : "text-muted-foreground"}`}>
                {messagePreview}
              </p>
              <div className="flex shrink-0 items-center gap-1.5">
                {conversation.isPinned && <Pin size={13} className="text-blue-500" aria-label="Pinned" />}
                {conversation.isArchived && <Archive size={13} className="text-muted-foreground" aria-label="Archived" />}
                {conversation.isMuted && <VolumeX size={13} className="text-muted-foreground" aria-label="Muted" />}
                {hasUnread && (
                  unreadCount > 1 ? (
                    <span className="flex min-w-5 items-center justify-center rounded-full bg-emerald-600 px-2 py-0.5 text-[10px] font-bold text-white">
                      {unreadCount > 99 ? "99+" : unreadCount}
                    </span>
                  ) : (
                    <span className="h-2 w-2 shrink-0 rounded-full bg-[var(--gh-green)]" aria-label="Unread" />
                  )
                )}
              </div>
            </div>
          </button>
        </div>
      </div>

      <div className="flex gap-2 border-t border-gray-50 px-3 py-2 transition sm:hidden sm:group-hover:flex sm:group-focus-within:flex">
        {onPin && <button type="button" aria-label={`${conversation.isPinned ? "Unpin" : "Pin"} ${displayName}`} onClick={(e) => { e.stopPropagation(); onPin(conversation.id, !Boolean(conversation.isPinned)) }} className="inline-flex min-h-9 items-center gap-1 rounded-lg bg-emerald-50 px-2.5 py-1.5 text-xs font-semibold text-emerald-800 transition hover:bg-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-200" title={conversation.isPinned ? "Unpin" : "Pin"}><Pin size={12} />{conversation.isPinned ? "Unpin" : "Pin"}</button>}
        {onArchive && <button type="button" aria-label={`${conversation.isArchived ? "Restore" : "Archive"} ${displayName}`} onClick={(e) => { e.stopPropagation(); onArchive(conversation.id, !Boolean(conversation.isArchived)) }} className="inline-flex min-h-9 items-center gap-1 rounded-lg bg-muted px-2.5 py-1.5 text-xs font-semibold text-foreground transition hover:bg-muted/80" title={conversation.isArchived ? "Unarchive" : "Archive"}><Archive size={12} />{conversation.isArchived ? "Unarchive" : "Archive"}</button>}
        {onMute && <button type="button" aria-label={`${conversation.isMuted ? "Unmute" : "Mute"} ${displayName}`} onClick={(e) => { e.stopPropagation(); onMute(conversation.id, !Boolean(conversation.isMuted)) }} className="inline-flex min-h-9 items-center gap-1 rounded-lg bg-muted px-2.5 py-1.5 text-xs font-semibold text-foreground transition hover:bg-muted/80" title={conversation.isMuted ? "Unmute" : "Mute"}><VolumeX size={12} />{conversation.isMuted ? "Unmute" : "Mute"}</button>}
      </div>
    </div>
  )
}

// Memoized emoji picker - prevent re-renders

const COMMON_EMOJIS = ["😀", "😂", "❤️", "👍", "🔥", "😍", "👏", "🎉", "💯", "🙏"]

const EmojiPickerGrid = memo(({ onEmojiSelect }: { onEmojiSelect: (emoji: string) => void }) => (
  <div className="mb-3 p-3 bg-muted/40 rounded-lg grid grid-cols-10 gap-2">
    {COMMON_EMOJIS.map((emoji) => (
      <button
        key={emoji}
        type="button"
        aria-label={`Insert ${emoji}`}
        onClick={() => onEmojiSelect(emoji)}
        className="flex h-10 w-10 items-center justify-center rounded-xl text-xl transition hover:bg-card active:scale-110"
      >
        {emoji}
      </button>
    ))}
  </div>
))
EmojiPickerGrid.displayName = "EmojiPickerGrid"

export const ConversationItem = memo(ConversationItemBase)
ConversationItem.displayName = "ConversationItem"

export function MessageInput({
  messageText,
  onMessageChange,
  onSendMessage,
  onEmojiClick,
  onAttachmentClick,
  onVoiceNote,
  disabled,
}: {
  messageText: string
  onMessageChange: (text: string) => void
  onSendMessage: () => void
  onEmojiClick: () => void
  onAttachmentClick: () => void
  onVoiceNote?: () => void
  disabled: boolean
}) {
  const [showEmojiPicker, setShowEmojiPicker] = useState(false)
  const composerRef = useRef<HTMLTextAreaElement>(null)
  const sendLockRef = useRef(false)

  // Keep the composer compact for short messages and grow it naturally for
  // multi-line drafts. The hard visual cap prevents the keyboard from pushing
  // the conversation history off-screen on mobile devices.
  useEffect(() => {
    const composer = composerRef.current
    if (!composer) return
    composer.style.height = "auto"
    const nextHeight = Math.min(Math.max(composer.scrollHeight, 44), 120)
    composer.style.height = `${nextHeight}px`
    composer.style.overflowY = composer.scrollHeight > 120 ? "auto" : "hidden"
  }, [messageText])
  const emitTypingUi = (active: boolean) => {
    try {
      window.dispatchEvent(new CustomEvent("ghc:message-typing", { detail: { active } }))
    } catch { /* */ }
  }


  const handleEmojiSelect = useCallback((emoji: string) => {
    onMessageChange(messageText + emoji)
    setShowEmojiPicker(false)
  }, [messageText, onMessageChange])

  const lastSentRef = useRef<{ text: string; at: number }>({ text: "", at: 0 })
  const fireSend = useCallback(() => {
    if (disabled || sendLockRef.current) return
    const trimmed = messageText.trim()
    if (!trimmed) return
    // Block identical double-submit within 1.2s (Enter + button or double-tap)
    const now = Date.now()
    if (lastSentRef.current.text === trimmed && now - lastSentRef.current.at < 1200) {
      return
    }
    sendLockRef.current = true
    lastSentRef.current = { text: trimmed, at: now }
    try {
      onSendMessage()
    } finally {
      // Parent sets `disabled` while sending; release lock after UI settles.
      window.setTimeout(() => {
        sendLockRef.current = false
      }, 900)
    }
  }, [disabled, messageText, onSendMessage])

  const handleKeyPress = useCallback((e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault()
      fireSend()
    }
  }, [fireSend])

  const toggleEmojiPicker = useCallback(() => {
    setShowEmojiPicker(prev => !prev)
  }, [])

  return (
    <div
      className="relative z-40 min-w-0 shrink-0 border-t border-border/70 bg-card p-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]"
      onKeyDown={(event) => {
        if (event.key === "Escape" && showEmojiPicker) {
          event.preventDefault()
          setShowEmojiPicker(false)
        }
      }}
    >
      {/* Emoji picker - only renders when visible */}
      {showEmojiPicker && <EmojiPickerGrid onEmojiSelect={handleEmojiSelect} />}

      {/* Input area */}
      <div className="flex min-w-0 items-end gap-2">
        {/* Emoji button */}
        <button
          type="button"
          onClick={toggleEmojiPicker}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-muted text-muted-foreground transition hover:bg-muted/80 active:scale-90"
          title="Add emoji"
          aria-label="Add emoji"
          disabled={disabled}
          aria-busy={disabled || undefined}
        >
          <Smile size={20} aria-hidden />
        </button>

        {/* Message input */}
        <textarea
          ref={composerRef}
          value={messageText}
          onChange={(e) => onMessageChange(e.target.value)}
          onFocus={() => emitTypingUi(true)}
          onBlur={() => emitTypingUi(false)}
          onKeyDown={handleKeyPress}
          placeholder={disabled ? "Messaging unavailable…" : "Type a message…"}
          disabled={disabled}
          aria-label="Message text"
          aria-describedby="message-composer-hint"
          maxLength={8000}
          className="min-h-11 min-w-0 max-h-[120px] flex-1 resize-none rounded-2xl border border-border bg-muted px-3 py-2.5 text-[15px] leading-[1.45] transition focus:border-[var(--gh-green)] focus:bg-card focus:outline-none focus:ring-2 focus:ring-emerald-100 disabled:opacity-60"
          rows={1}
          style={{ minHeight: "44px", maxHeight: "120px", overflowY: "hidden" }}
        />

        {/* Voice note */}
        {onVoiceNote && (
          <button
            type="button"
            onClick={onVoiceNote}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-muted text-muted-foreground transition hover:bg-muted/80 active:scale-90"
            title="Voice note"
            aria-label="Record voice note"
            disabled={disabled}
          >
            <Mic size={20} aria-hidden />
          </button>
        )}

        {/* Attachment button */}
        <button
          type="button"
          onClick={onAttachmentClick}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-muted text-muted-foreground transition hover:bg-muted/80 active:scale-90"
          title="Attach file"
          aria-label="Attach file"
          disabled={disabled}
        >
          <Paperclip size={20} aria-hidden />
        </button>

        {/* Send button */}
        <button
          type="button"
          onClick={fireSend}
          disabled={!messageText.trim() || disabled}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[var(--gh-green)] text-white transition hover:brightness-110 active:scale-90 disabled:bg-muted disabled:text-muted-foreground"
          title="Send message"
          aria-label="Send message"
        >
          <Send size={20} aria-hidden />
        </button>
      </div>

      <p id="message-composer-hint" className="mt-1.5 flex items-center justify-between gap-2 text-[10px] text-muted-foreground">
        <span>{disabled ? "Sending is paused while this message is being processed." : "Enter to send · Shift+Enter for new line"}</span>
        <span className="shrink-0 tabular-nums">{messageText.length}/8000</span>
      </p>
    </div>
  )
}

// Enhanced message bubble with long-press actions (mobile) + hover actions (desktop)
function MessageBubbleBase({
  message,
  isSentByCurrentUser,
  onReply,
  onForward,
  onReact,
  onDelete,
  onReport,
  onCopy,
  onRetry,
}: {
  message: {
    id: string
    text: string
    senderId: string
    createdAt: number
    replyTo?: string
    replyToPreview?: { senderName: string; text: string }
    reactions?: Record<string, string[]>
    isEdited?: boolean
    isPinned?: boolean
    isDeleted?: boolean
    deletedForEveryone?: boolean
    mediaAttachments?: any[]
    status?: "sending" | "sent" | "delivered" | "read" | "failed" | "deleted"
    deliveredAt?: number | null
    readAt?: number
    failureReason?: string
  }
  isSentByCurrentUser: boolean
  onReply?: (messageId: string) => void
  onForward?: (messageId: string) => void
  onReact?: (messageId: string, emoji: string) => void
  /** deleteForEveryone=true when sender chooses "Delete for everyone" within the allowed window */
  onDelete?: (messageId: string, deleteForEveryone?: boolean) => void
  onReport?: (messageId: string) => void
  onCopy?: (text: string) => void
  onRetry?: (messageId: string) => void
}) {
  const [menuOpen, setMenuOpen] = useState(false)
  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const timestamp = useMemo(
    () => new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    [message.createdAt]
  )

  const reactionEmojis = useMemo(() => ["😀", "😂", "❤️", "👍", "😢", "😡"], [])

  const clearLongPress = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current)
      longPressTimer.current = null
    }
  }

  const startLongPress = () => {
    clearLongPress()
    longPressTimer.current = setTimeout(() => {
      setMenuOpen(true)
    }, 450)
  }

  const copyText = () => {
    const text = message.text || ""
    if (onCopy) onCopy(text)
    else if (typeof navigator !== "undefined" && navigator.clipboard) {
      void navigator.clipboard.writeText(text)
    }
    setMenuOpen(false)
  }

  return (
    <div className={`mb-3 flex ${isSentByCurrentUser ? "justify-end" : "justify-start"}`}>
      <div className="group relative">
        {/* Pinned indicator */}
        {message.isPinned && (
          <div className="text-xs text-blue-600 mb-1 px-2">📌 Pinned</div>
        )}
        
        {/* Reply preview if replying to another message */}
        {message.replyTo && message.replyToPreview && (
          <div className={`text-xs px-3 py-1 mb-1 rounded border-l-2 ${
            isSentByCurrentUser ? "border-emerald-300 bg-emerald-50 text-emerald-700" : "border-border/80 bg-muted/40 text-muted-foreground"
          }`}>
            <p className="font-semibold">{message.replyToPreview.senderName}</p>
            <p className="truncate opacity-75">{message.replyToPreview.text}</p>
          </div>
        )}

        {(message as any).isDeleted || (message as any).isDeletedForEveryone || (message as any).deletedForEveryone ? (
          <div
            className={`max-w-[min(82vw,24rem)] px-3.5 py-2.5 rounded-[1.15rem] text-[14px] leading-snug italic shadow-sm ${
              isSentByCurrentUser ? "bg-emerald-100 text-emerald-700 rounded-br-none" : "bg-muted text-muted-foreground rounded-bl-none"
            }`}
          >
            This message was deleted
          </div>
        ) : (
        <div
          role="group"
          aria-label={`Message from ${isSentByCurrentUser ? "you" : "conversation member"} at ${timestamp}`}
          onTouchStart={startLongPress}
          onTouchEnd={clearLongPress}
          onTouchMove={clearLongPress}
          onContextMenu={(e) => {
            e.preventDefault()
            setMenuOpen(true)
          }}
          className={`group max-w-[min(82vw,24rem)] select-text rounded-2xl px-4 py-2.5 text-sm shadow-sm ${
            isSentByCurrentUser ? "rounded-br-none border border-emerald-600/30 bg-emerald-600/15 text-emerald-950 dark:bg-emerald-600/25 dark:text-emerald-50" : "rounded-bl-none bg-muted text-foreground"
          }`}
        >
          {message.mediaAttachments?.length ? (
            <div className="mb-2 space-y-2">
              {message.mediaAttachments.map((media) => (
                <div key={media.id} className="overflow-hidden rounded-xl bg-black/5">
                  {media.type === "image" || media.type === "video" ? (
                    <div className="relative">
                      <button
                        type="button"
                        className="block w-full overflow-hidden rounded-xl text-left"
                        aria-label="Open or hold to download attachment"
                        onContextMenu={(e) => {
                          e.preventDefault()
                          if (media.url) void downloadMedia(media.url, { kind: media.type === "video" ? "video" : "image", filename: media.fileName })
                        }}
                        onPointerDown={(e) => {
                          if (e.button !== 0) return
                          const el = e.currentTarget
                          const timer = window.setTimeout(() => {
                            if (media.url) void downloadMedia(media.url, { kind: media.type === "video" ? "video" : "image", filename: media.fileName })
                            try { if ("vibrate" in navigator) navigator.vibrate(10) } catch { /* */ }
                          }, 500)
                          const clear = () => window.clearTimeout(timer)
                          el.addEventListener("pointerup", clear, { once: true })
                          el.addEventListener("pointercancel", clear, { once: true })
                        }}
                      >
                        <LazyImage variant="post-media" src={media.thumbnail || media.url} alt={media.fileName || "Message attachment"} className="max-h-56 w-full rounded-xl object-cover pointer-events-none" />
                      </button>
                      {media.type === "video" && <span className="absolute inset-0 flex items-center justify-center"><span className="rounded-full bg-black/55 p-2 text-white"><Play size={16} fill="currentColor" /></span></span>}
                    </div>
                  ) : media.type === "file" ? (
                    <div className="flex items-center gap-2 px-3 py-2 text-xs"><FileText size={16} /><span className="truncate">{media.fileName || "Attached file"}</span></div>
                  ) : media.type === "voice" ? (
                    <div className="min-w-[220px] max-w-full px-3 py-2">
                      <div className="mb-1 flex items-center gap-2 text-xs font-semibold text-foreground">
                        <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-emerald-600/10 text-emerald-700 dark:text-emerald-300" aria-hidden="true">
                          <AudioLines size={14} />
                        </span>
                        <span>Voice message</span>
                        {typeof media.duration === "number" && media.duration > 0 ? (
                          <span className="ml-auto tabular-nums text-muted-foreground">{Math.floor(media.duration / 60)}:{String(Math.floor(media.duration % 60)).padStart(2, "0")}</span>
                        ) : null}
                      </div>
                      {media.url ? (
                        <audio
                          className="h-9 w-full max-w-[280px]"
                          controls
                          preload="none"
                          src={media.url}
                          aria-label="Play voice message"
                        />
                      ) : (
                        <p className="text-xs text-muted-foreground">Audio is unavailable.</p>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 px-3 py-2 text-xs"><FileText size={16} /><span>{media.fileName || "Attachment"}</span></div>
                  )}
                </div>
              ))}
            </div>
          ) : null}
          {message.text && <p className="break-words">{message.text}</p>}
          {(message as any).sharedPostId && (
            <div className={`mt-2 rounded-xl border px-3 py-2 text-xs ${isSentByCurrentUser ? "border-emerald-400/40 bg-emerald-500/20 text-emerald-50" : "border-border/80 bg-card text-foreground/90"}`}>
              <p className="font-bold">Shared post</p>
              <p className="opacity-80">View original in feed · ref {(message as any).sharedPostId.slice(0, 8)}…</p>
            </div>
          )}
          <p className={`mt-1 flex items-center gap-1 text-xs opacity-70 ${isSentByCurrentUser ? "justify-end text-emerald-900 dark:text-emerald-100" : "text-muted-foreground"}`}>
            <span>{timestamp}</span>
            {message.isEdited ? <span>(edited)</span> : null}
            {isSentByCurrentUser && message.status && message.status !== "failed" ? (
              <span
                className={`inline-flex items-center gap-1 font-semibold tracking-tight ${message.status === "read" ? "text-emerald-700 dark:text-emerald-300" : ""}`}
                aria-label={
                  message.status === "read" ? "Seen by recipient" :
                  message.status === "delivered" ? "Delivered to recipient" :
                  message.status === "sending" ? "Sending message" :
                  message.status === "sent" ? (message.deliveredAt ? "Delivered to some recipients; waiting on others" : "Sent, not yet delivered") : "Message status"
                }
                title={
                  message.status === "read" ? "Seen by recipient" :
                  message.status === "delivered" ? "Delivered to recipient" :
                  message.status === "sending" ? "Sending message" :
                  message.status === "sent" ? (message.deliveredAt ? "Delivered to some recipients; waiting on others" : "Sent, not yet delivered") : "Message status"
                }
              >
                {message.status === "read" ? "Read" :
                  message.status === "delivered" ? "Delivered" :
                  message.status === "sending" ? "Sending…" :
                  message.status === "sent" ? (message.deliveredAt ? "Sent" : "Sent") : ""}
              </span>
            ) : null}
          </p>
        {message.status === "failed" && isSentByCurrentUser ? (
          <div className="mt-1 flex flex-col items-end gap-1 px-1">
            <div className="flex items-center justify-end gap-2">
              <span className="text-[10px] font-semibold text-red-600">Not delivered</span>
              {onRetry ? (
                <button
                  type="button"
                  className="min-h-8 rounded-full bg-red-50 px-2.5 text-[10px] font-bold text-red-700 dark:bg-red-950/40"
                  onClick={() => onRetry(message.id)}
                >
                  Retry
                </button>
              ) : null}
            </div>
            {message.failureReason ? (
              <p className="max-w-[85%] text-right text-[10px] leading-snug text-red-600/90">
                {String(message.failureReason)}
              </p>
            ) : null}
          </div>
        ) : null}
        {message.status === "sending" && isSentByCurrentUser ? (
          <p className="mt-0.5 text-right text-[10px] text-muted-foreground">Queued · sending…</p>
        ) : null}
        </div>
        )}

        {/* Reactions display */}
        {message.reactions && Object.keys(message.reactions).length > 0 && (
          <div className="flex flex-wrap gap-1 mt-1 px-2">
            {Object.entries(message.reactions).map(([emoji, users]) => (
              <div
                key={emoji}
                className={`text-xs px-2 py-1 rounded-full flex items-center gap-1 ${
                  isSentByCurrentUser
                    ? "bg-emerald-100 text-emerald-700"
                    : "bg-muted text-foreground/90"
                }`}
              >
                <span>{emoji}</span>
                <span className="text-xs font-semibold">{users.length}</span>
              </div>
            ))}
          </div>
        )}

        {/* Desktop hover actions */}
        <div
          className={`mt-1 flex gap-1 opacity-100 transition sm:opacity-0 sm:group-hover:opacity-100 sm:group-focus-within:opacity-100 ${
            isSentByCurrentUser ? "justify-end" : "justify-start"
          }`}
        >
          {onReply && (
            <button
              type="button"
              onClick={() => onReply(message.id)}
              className="min-h-9 rounded bg-muted px-3 py-1 text-xs text-foreground/90 transition hover:bg-muted/80"
              aria-label="Reply to message"
            >
              Reply
            </button>
          )}
          <button
            type="button"
            onClick={() => setMenuOpen(true)}
            className="min-h-9 rounded bg-muted px-3 py-1 text-xs text-foreground/90 transition hover:bg-muted/80"
            aria-label="More message actions"
          >
            More
          </button>
        </div>

        {/* Long-press / More action sheet */}
        {menuOpen && (
          <div
            className="fixed inset-0 z-[70] flex items-end bg-black/40 sm:items-center sm:justify-center"
            role="dialog"
            aria-modal="true"
            aria-labelledby="message-actions-title"
            onClick={() => setMenuOpen(false)}
          >
            <div
              className="w-full max-w-sm rounded-t-2xl bg-card p-2 shadow-2xl sm:rounded-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <p className="px-3 py-2 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                Message actions
              </p>
              {onReact && (
                <div className="mb-1 flex gap-1 px-2 pb-2">
                  {reactionEmojis.map((emoji) => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => {
                        onReact(message.id, emoji)
                        setMenuOpen(false)
                      }}
                      className="flex h-10 w-10 items-center justify-center rounded-full text-lg hover:bg-muted"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              )}
              {onReply && (
                <button
                  type="button"
                  className="w-full rounded-xl px-4 py-3 text-left text-sm font-semibold text-foreground hover:bg-muted/40"
                  onClick={() => {
                    onReply(message.id)
                    setMenuOpen(false)
                  }}
                >
                  Reply
                </button>
              )}
              <button
                type="button"
                className="w-full rounded-xl px-4 py-3 text-left text-sm font-semibold text-foreground hover:bg-muted/40"
                onClick={copyText}
              >
                Copy
              </button>
              {onForward && (
                <button
                  type="button"
                  className="w-full rounded-xl px-4 py-3 text-left text-sm font-semibold text-foreground hover:bg-muted/40"
                  onClick={() => {
                    onForward(message.id)
                    setMenuOpen(false)
                  }}
                >
                  Forward
                </button>
              )}
              {onDelete && (
                <>
                  <button
                    type="button"
                    className="w-full rounded-xl px-4 py-3 text-left text-sm font-semibold text-foreground hover:bg-muted/40"
                    onClick={() => {
                      onDelete(message.id, false)
                      setMenuOpen(false)
                    }}
                  >
                    Delete for me
                  </button>
                  {isSentByCurrentUser && Date.now() - message.createdAt <= 60 * 60 * 1000 && (
                    <button
                      type="button"
                      className="w-full rounded-xl px-4 py-3 text-left text-sm font-semibold text-red-600 hover:bg-red-50"
                      onClick={() => {
                        onDelete(message.id, true)
                        setMenuOpen(false)
                      }}
                    >
                      Delete for everyone
                    </button>
                  )}
                </>
              )}
              {!isSentByCurrentUser && onReport && (
                <button
                  type="button"
                  className="w-full rounded-xl px-4 py-3 text-left text-sm font-semibold text-red-600 hover:bg-red-50"
                  onClick={() => {
                    onReport(message.id)
                    setMenuOpen(false)
                  }}
                >
                  Report
                </button>
              )}
              <button
                type="button"
                className="mt-1 w-full rounded-xl bg-muted px-4 py-3 text-sm font-bold text-foreground"
                onClick={() => setMenuOpen(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// Chat header with participant info + presence / last-seen
export const MessageBubble = memo(MessageBubbleBase)
MessageBubble.displayName = "MessageBubble"

export function ChatHeader({
  participantName,
  participantPhoto,
  isOnline,
  isTyping = false,
  lastSeenLabel,
  onBack,
  onCall,
  onVideo,
  onSearch,
  onSharedMedia,
  onDetails,
  onOpenProfile,
  onBlock,
  onReport,
  isCommunity = false,
}: {
  participantName: string
  participantPhoto: string
  isOnline: boolean
  isTyping?: boolean
  lastSeenLabel?: string
  onBack: () => void
  onCall?: () => void
  onVideo?: () => void
  onSearch?: () => void
  onSharedMedia?: () => void
  onDetails?: () => void
  onOpenProfile?: () => void
  onBlock?: () => void
  onReport?: () => void
  isCommunity?: boolean
}) {
  const [menuOpen, setMenuOpen] = useState(false)
  return (
    <div className="flex items-center justify-between border-b border-border bg-card px-4 py-3">
      <div className="flex min-w-0 items-center gap-3">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-semibold text-muted-foreground transition hover:bg-muted active:scale-95"
          aria-label="Back to inbox"
        >
          ←
        </button>
        <button
          type="button"
          onClick={onOpenProfile}
          className="flex min-w-0 items-center gap-3 text-left transition active:scale-[0.98]"
        >
          <div className="relative shrink-0">
            <LazyImage
              src={participantPhoto || "/placeholder.svg?width=80&height=80"}
              alt=""
              className="h-12 w-12 rounded-full object-cover shadow-sm ring-1 ring-black/5"
            />
            {isOnline && (
              <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-card bg-emerald-500" />
            )}
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-bold text-foreground">
              {participantName.startsWith("Community ·") ? participantName : isCommunity ? `Community · ${participantName}` : participantName}
            </p>
            <p className={`text-[12px] ${isTyping ? "font-semibold text-emerald-600" : "text-muted-foreground"}`}>
              {isTyping ? "Typing…" : isOnline ? "Active now" : lastSeenLabel || "Offline"}
            </p>
          </div>
        </button>
      </div>

      <div className="relative flex items-center gap-0.5">
        {onDetails && (
          <button
            type="button"
            onClick={onDetails}
            className="flex h-11 w-11 items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted hover:text-foreground active:scale-95"
            aria-label="Conversation information and settings"
            title="Conversation information"
          >
            <Info size={19} strokeWidth={2} />
          </button>
        )}
        {onSharedMedia && (
          <button
            type="button"
            onClick={onSharedMedia}
            className="flex h-11 w-11 items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted hover:text-foreground active:scale-95"
            aria-label="View shared media"
            title="Shared media"
          >
            <Images size={19} strokeWidth={2} />
          </button>
        )}
        {onSearch && (
          <button
            type="button"
            onClick={onSearch}
            className="flex h-11 w-11 items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted hover:text-foreground active:scale-95"
            aria-label="Search recent messages"
            title="Search recent messages"
          >
            <Search size={19} strokeWidth={2} />
          </button>
        )}
        {onCall && !isCommunity && (
          <button
            type="button"
            onClick={onCall}
            className="flex h-11 w-11 items-center justify-center rounded-full text-muted-foreground transition hover:bg-emerald-50 hover:text-emerald-700 active:scale-95"
            aria-label="Voice call"
            title="Voice call"
          >
            <Phone size={20} strokeWidth={2} />
          </button>
        )}
        {onVideo && !isCommunity && (
          <button
            type="button"
            onClick={onVideo}
            className="flex h-11 w-11 items-center justify-center rounded-full text-muted-foreground transition hover:bg-emerald-50 hover:text-emerald-700 active:scale-95"
            aria-label="Video call"
            title="Video call"
          >
            <Video size={20} strokeWidth={2} />
          </button>
        )}
        {onOpenProfile && (
          <button
            type="button"
            onClick={onOpenProfile}
            className="hidden rounded-full bg-muted px-2.5 py-1.5 text-[11px] font-bold text-foreground sm:inline-flex"
          >
            Profile
          </button>
        )}
        <button
          type="button"
          onClick={() => setMenuOpen((v) => !v)}
          className="flex h-11 w-11 items-center justify-center rounded-full bg-muted text-muted-foreground transition hover:bg-muted/80"
          aria-label="Chat safety menu"
          aria-expanded={menuOpen}
        >
          ···
        </button>
        {menuOpen && (
          <div className="absolute right-0 top-12 z-30 w-48 overflow-hidden rounded-2xl border border-border bg-card py-1 shadow-lg">
            {onOpenProfile && (
              <button
                type="button"
                className="w-full px-3 py-2.5 text-left text-[12px] font-semibold text-foreground hover:bg-muted sm:hidden"
                onClick={() => {
                  setMenuOpen(false)
                  onOpenProfile()
                }}
              >
                View profile
              </button>
            )}
            {onReport && (
              <button
                type="button"
                className="w-full px-3 py-2.5 text-left text-[12px] font-semibold text-foreground hover:bg-muted"
                onClick={() => {
                  setMenuOpen(false)
                  onReport()
                }}
              >
                Report
              </button>
            )}
            {onBlock && (
              <button
                type="button"
                className="w-full px-3 py-2.5 text-left text-[12px] font-semibold text-red-600 hover:bg-red-50"
                onClick={() => {
                  setMenuOpen(false)
                  onBlock()
                }}
              >
                Block
              </button>
            )}
            <button
              type="button"
              className="w-full px-3 py-2 text-left text-[11px] text-muted-foreground hover:bg-muted"
              onClick={() => setMenuOpen(false)}
            >
              Close
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
