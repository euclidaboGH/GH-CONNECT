"use client"

import { promptDialog } from "@/lib/ui/global-interactions"
import { useState, useEffect, useRef, useCallback, useMemo, lazy, Suspense, type ReactNode } from "react"
import { useGHC } from "@/contexts/ghc-context"
import { SUPPORT_CONTACTS, LEGAL } from "@/lib/ghc-data"
import { compressForTheme } from "@/lib/media/compress-image"
import {
  ChevronLeft,
  ChevronRight,
  LogOut,
  ImagePlus,
  Check,
  Sun,
  Moon,
  Monitor,
  Search,
  Shield,
  Bell,
  Palette,
  Wallet,
  Crown,
  HelpCircle,
  Info,
  FileText,
  Gift,
  User,
  Ban,
  Lock,
  Users,
  ArrowLeft,
  Gauge,
  Smartphone,
  Wifi,
} from "lucide-react"
import { useSessionLock } from "@/contexts/session-lock-context"
import { useRegionalContext } from "@/contexts/regional-context"
import { getProductMessage } from "@/lib/i18n/product"
import { hasPinConfigured, clearPin } from "@/lib/session-security"
import { IdentityService } from "@/lib/identity/identity-service"
import { loadNotificationPreferences, saveNotificationPreferences, serializeAccountNotificationPreferences, type NotificationPreferences, type NotificationCategory } from "@/lib/domains/notification-domain"
import { THEME_PRESETS, type ThemeMode } from "@/lib/theme/themes"
// Settings subsections are separate chunks so the initial Settings route does
// not download security, compliance, Pi capability and passkey panels eagerly.
const ActiveSessionsPanel = lazy(() => import("@/components/ghc/active-sessions-panel").then((m) => ({ default: m.ActiveSessionsPanel })))
const AccountSecuritySignals = lazy(() => import("@/components/ghc/account-security-signals").then((m) => ({ default: m.AccountSecuritySignals })))
const PiPayoutAuthorizationCard = lazy(() => import("@/components/ghc/pi-payout-authorization-card").then((m) => ({ default: m.PiPayoutAuthorizationCard })))
const PiPlatformCapabilitiesCard = lazy(() => import("@/components/ghc/pi-platform-capabilities-card").then((m) => ({ default: m.PiPlatformCapabilitiesCard })))
const PiListingReadinessCard = lazy(() => import("@/components/ghc/pi-listing-readiness-card").then((m) => ({ default: m.PiListingReadinessCard })))
const CompliancePostureCard = lazy(() => import("@/components/ghc/compliance-posture-card").then((m) => ({ default: m.CompliancePostureCard })))
const ClaimReadinessCard = lazy(() => import("@/components/ghc/claim-readiness-card").then((m) => ({ default: m.ClaimReadinessCard })))
const PasskeysPanel = lazy(() => import("@/components/ghc/passkeys-panel").then((m) => ({ default: m.PasskeysPanel })))
const AccountDataControls = lazy(() => import("@/components/ghc/account-data-controls").then((m) => ({ default: m.AccountDataControls })))
const FoundationStatusCard = lazy(() => import("@/components/ghc/foundation-status-card").then((m) => ({ default: m.FoundationStatusCard })))
const PiStakingStatusNote = lazy(() => import("@/components/ghc/pi-supporter-badge").then((m) => ({ default: m.PiStakingStatusNote })))
import { APP_RELEASE_VERSION } from "@/lib/app-release"
import { getPrivacyHealth } from "@/lib/privacy-health"
import { matchSettingsSearch } from "@/lib/settings-search"
import { clampDiscoveryRadiusKm, clampAgeRange } from "@/lib/settings-persistence"
import { getDevicePerformanceProfile, preferReducedData, setPreferReducedData } from "@/lib/mobile-performance"
import { getLocaleOptions, normalizeLanguagePreference, translate } from "@/lib/i18n"
import { getShellMessage, getShellTranslationStatus } from "@/lib/i18n/shell"

const PremiumWalletScreen = lazy(() =>
  import("../../features/wallet/wallet-screen").then((m) => ({
    default: m.PremiumWalletScreen,
  }))
)
const PremiumMembershipScreen = lazy(() =>
  import("./premium-membership-screen").then((m) => ({
    default: m.PremiumMembershipScreen,
  }))
)
const RewardsCentreScreen = lazy(() =>
  import("./rewards-centre-screen").then((m) => ({
    default: m.RewardsCentreScreen,
  }))
)

async function ensureBrowserNotificationPermission(): Promise<boolean> {
  try {
    if (typeof window === "undefined" || !("Notification" in window)) return false
    if (Notification.permission === "granted") return true
    if (Notification.permission === "denied") return false
    const result = await Notification.requestPermission()
    return result === "granted"
  } catch {
    return false
  }
}

function SectionFallback({ label }: { label: string }) {
  return (
    <div className="flex h-full items-center justify-center text-[13px] text-muted-foreground">
      Loading {label}…
    </div>
  )
}


export type SettingsSection =
  | "main"
  | "privacy"
  | "device-lock"
  | "preferences"
  | "notifications"
  | "appearance"
  | "performance"
  | "help"
  | "legal"
  | "about"
  | "terms"
  | "privacy-policy"
  | "wallet"
  | "membership"
  | "rewards"
  | "pi-payout-auth"

function PerformanceSettingsScreen({ onBack }: { onBack: () => void }) {
  const [profile, setProfile] = useState<ReturnType<typeof getDevicePerformanceProfile> | null>(null)
  const [reducedData, setReducedData] = useState(false)
  const [refreshedAt, setRefreshedAt] = useState<number | null>(null)

  const refresh = useCallback(() => {
    setProfile(getDevicePerformanceProfile())
    setReducedData(preferReducedData())
    setRefreshedAt(Date.now())
  }, [])

  useEffect(() => { refresh() }, [refresh])

  const toggleReducedData = useCallback((enabled: boolean) => {
    setPreferReducedData(enabled)
    setReducedData(enabled || Boolean(profile?.saveData))
  }, [profile?.saveData])

  const deviceMemory = typeof navigator !== "undefined"
    ? Number((navigator as Navigator & { deviceMemory?: number }).deviceMemory) || null
    : null
  const status = !profile ? "Checking device" : profile.lowPower ? "Efficiency mode recommended" : "Device ready"

  return (
    <div className="flex h-full min-h-0 flex-col bg-background">
      <div className="flex shrink-0 items-center gap-2 border-b border-border/50 bg-card/95 px-2.5 py-2">
        <button type="button" onClick={onBack} className="hover:opacity-60" aria-label="Back"><ChevronLeft size={24} /></button>
        <h2 className="text-[14px] font-bold tracking-tight">Performance & data</h2>
      </div>
      <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-4 pb-[var(--gh-screen-bottom-inset)]">
        <section className="rounded-3xl border border-border/60 bg-card p-4 shadow-[var(--gh-card-shadow)]">
          <div className="flex items-start gap-3">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-primary/10 text-primary"><Gauge size={22} /></span>
            <div className="min-w-0 flex-1">
              <p className="text-[15px] font-bold">{status}</p>
              <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">GreenHaven adapts non-critical loading to the capabilities reported by this browser. These are device signals, not a synthetic speed score.</p>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-2">
            <div className="rounded-2xl bg-muted/50 p-3"><p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Processor</p><p className="mt-1 text-[15px] font-bold">{profile ? `${profile.hardwareConcurrency} logical cores` : "Checking"}</p></div>
            <div className="rounded-2xl bg-muted/50 p-3"><p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Memory</p><p className="mt-1 text-[15px] font-bold">{deviceMemory ? `~${deviceMemory} GB` : "Not reported"}</p></div>
            <div className="rounded-2xl bg-muted/50 p-3"><p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Connection</p><p className="mt-1 text-[15px] font-bold">{profile?.effectiveType ?? "Not reported"}</p></div>
            <div className="rounded-2xl bg-muted/50 p-3"><p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">Motion</p><p className="mt-1 text-[15px] font-bold">{profile?.reducedMotion ? "Reduced" : "Standard"}</p></div>
          </div>
          <button type="button" onClick={refresh} className="mt-4 min-h-11 w-full rounded-full border border-border px-4 py-2.5 text-[13px] font-semibold transition hover:bg-muted/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary">Refresh device diagnostics</button>
          {refreshedAt ? <p className="mt-2 text-center text-[10px] text-muted-foreground">Updated {new Date(refreshedAt).toLocaleTimeString()}</p> : null}
        </section>

        <section className="rounded-3xl border border-border/60 bg-card p-4 shadow-[var(--gh-card-shadow)]">
          <div className="flex items-center gap-3"><span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-sky-500/10 text-sky-600"><Wifi size={20} /></span><div><p className="text-[14px] font-bold">Reduce data usage</p><p className="text-[11px] text-muted-foreground">This device only</p></div></div>
          <label className="mt-4 flex min-h-12 cursor-pointer items-center justify-between gap-4 rounded-2xl bg-muted/40 px-3 py-2">
            <span className="min-w-0"><span className="block text-[13px] font-semibold">Prefer reduced data</span><span className="mt-0.5 block text-[11px] text-muted-foreground">Skip optional prefetching and favor lighter media where supported.</span></span>
            <input type="checkbox" checked={reducedData} onChange={(event) => toggleReducedData(event.target.checked)} disabled={Boolean(profile?.saveData || profile?.effectiveType === "2g" || profile?.effectiveType === "slow-2g")} className="h-5 w-5 shrink-0 accent-primary" aria-label="Prefer reduced data" />
          </label>
          {profile?.saveData || profile?.effectiveType === "2g" || profile?.effectiveType === "slow-2g" ? <p className="mt-2 text-[11px] text-muted-foreground">Your browser or network is already requesting reduced data, so this preference is locked on.</p> : null}
          <div className="mt-3 flex items-center gap-2 text-[11px] text-muted-foreground"><Smartphone size={14} /> Preference is stored locally on this device and does not change your account settings.</div>
        </section>

        <section className="rounded-3xl border border-border/60 bg-card p-4">
          <p className="text-[13px] font-bold">What GreenHaven optimizes</p>
          <ul className="mt-3 space-y-2 text-[12px] leading-relaxed text-muted-foreground">
            <li>• Defers non-critical work until the browser is idle.</li>
            <li>• Avoids optional prefetching on constrained connections and low-power devices.</li>
            <li>• Supports reduced-motion preferences and lazy media loading.</li>
            <li>• Keeps account, privacy, payment and entitlement decisions server-authoritative.</li>
          </ul>
        </section>
      </div>
    </div>
  )
}

export function SettingsScreen({
  onBack,
  initialSection = "main",
}: {
  onBack: () => void
  /** Optional deep-link into Settings (e.g. Profile header → Wallet). */
  initialSection?: SettingsSection
}) {
  const { settings, updateSettings, logout, blockedUsers, unblockUser, candidates } = useGHC()
  const [notificationIdentityId, setNotificationIdentityId] = useState(() => IdentityService.getCurrentUserId())
  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPreferences>(() => loadNotificationPreferences(notificationIdentityId))
  const [browserPermission, setBrowserPermission] = useState<NotificationPermission | "unsupported">(() =>
    typeof window !== "undefined" && "Notification" in window ? Notification.permission : "unsupported"
  )
  const sessionLock = useSessionLock()
  const regional = useRegionalContext()
  const msg = (key: Parameters<typeof getProductMessage>[0]) => getProductMessage(key, regional.locale)
  const localeOptions = useMemo(() => getLocaleOptions(), [])
  const selectedLocale = normalizeLanguagePreference(settings.language)
  useEffect(() => IdentityService.subscribe((identity) => setNotificationIdentityId(identity.userId)), [])
  useEffect(() => {
    setNotificationPrefs(loadNotificationPreferences(notificationIdentityId))
    const refreshPermission = () => setBrowserPermission(
      typeof window !== "undefined" && "Notification" in window ? Notification.permission : "unsupported"
    )
    refreshPermission()
    const onVisible = () => { if (document.visibilityState === "visible") refreshPermission() }
    window.addEventListener("focus", refreshPermission)
    document.addEventListener("visibilitychange", onVisible)
    return () => {
      window.removeEventListener("focus", refreshPermission)
      document.removeEventListener("visibilitychange", onVisible)
    }
  }, [notificationIdentityId])
  const [navStack, setNavStack] = useState<SettingsSection[]>(() =>
    initialSection && initialSection !== "main" ? ["main", initialSection] : ["main"],
  )
  const section = navStack[navStack.length - 1] ?? "main"
  const setSection = useCallback((next: SettingsSection) => {
    setNavStack((prev) => {
      if (next === "main") return ["main"]
      const top = prev[prev.length - 1]
      if (top === next) return prev
      return [...prev, next]
    })
  }, [])
  const [settingsQuery, setSettingsQuery] = useState("")
  const [logoutConfirm, setLogoutConfirm] = useState(false)
  const [membershipSubtitle, setMembershipSubtitle] = useState("…")

  /** Navigate into a subsection and record history so browser/Pi back steps one level. */
  const goToSection = useCallback((next: SettingsSection) => {
    setNavStack((prev) => {
      const top = prev[prev.length - 1]
      if (top === next) return prev
      if (next === "main") return ["main"]
      return [...prev, next]
    })
    try {
      if (next !== "main") {
        window.history.pushState({ ghcSettingsSection: next }, "")
      }
    } catch {
      /* history may be unavailable in some WebViews */
    }
  }, [])

  /** One-level back: subsection → previous screen; Settings main → close Settings (Profile). */
  const goBackOneLevel = useCallback(() => {
    setNavStack((prev) => {
      if (prev.length <= 1) {
        onBack()
        return prev
      }
      return prev.slice(0, -1)
    })
  }, [onBack])

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent<{ section?: string; focus?: string }>).detail
      const next = detail?.section
      if (
        next === "wallet" ||
        next === "rewards" ||
        next === "membership" ||
        next === "help" ||
        next === "privacy" ||
        next === "notifications" ||
        next === "appearance" ||
        next === "performance" ||
        next === "device-lock"
      ) {
        // Phase 5: optional focus target for Wallet Pi tools (withdrawal journey)
        if (next === "wallet" && detail?.focus) {
          try {
            sessionStorage.setItem("ghc.wallet.focus", String(detail.focus))
          } catch { /* */ }
        }
        goToSection(
          next as
            | "wallet"
            | "rewards"
            | "membership"
            | "help"
            | "privacy"
            | "notifications"
            | "appearance"
            | "performance"
            | "device-lock",
        )
      }
    }
    window.addEventListener("ghc:open-settings-section", handler)
    return () => window.removeEventListener("ghc:open-settings-section", handler)
  }, [goToSection])

  /** Browser / Pi shell back: step out one settings level instead of leaving the app. */
  useEffect(() => {
    const onPop = () => {
      setNavStack((prev) => {
        if (prev.length <= 1) {
          onBack()
          return prev
        }
        return prev.slice(0, -1)
      })
    }
    window.addEventListener("popstate", onPop)
    return () => window.removeEventListener("popstate", onPop)
  }, [onBack])

  // Deep-link entry (e.g. Profile → Wallet): push history once so back returns to Settings main
  useEffect(() => {
    if (initialSection && initialSection !== "main") {
      try {
        window.history.pushState({ ghcSettingsSection: initialSection }, "")
      } catch {
        /* */
      }
    }
    // only on mount for this Settings instance
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const [themeBusy, setThemeBusy] = useState(false)
  const themeFileRef = useRef<HTMLInputElement>(null)

  /** Keep Membership row in sync with server status (trial / VIP / VVIP / Free) */
  useEffect(() => {
    let cancelled = false
    const applyLocalFallback = () => {
      try {
        const { getBoundDomainServices } = require("@/lib/domains/compat")
        const st = getBoundDomainServices()?.membership?.getStatus?.() as
          | { tier?: string; source?: string; lifecycle?: string; expiresAt?: number }
          | null
        if (!st) {
          setMembershipSubtitle("Free plan")
          return
        }
        const tierRaw = String(st.tier || "free").toLowerCase()
        const tierLabel =
          tierRaw === "vvip" ? "VVIP" : tierRaw === "vip" ? "VIP" : tierRaw === "free" ? "Free" : String(st.tier).toUpperCase()
        const isTrial = st.source === "trial" || st.lifecycle === "trial"
        if (isTrial) {
          if (st.expiresAt && st.expiresAt > Date.now()) {
            const h = Math.max(1, Math.round((st.expiresAt - Date.now()) / 3600000))
            setMembershipSubtitle(
              h < 48 ? `${tierLabel} trial · ${h}h left` : `${tierLabel} trial · active`
            )
          } else {
            setMembershipSubtitle(`${tierLabel} trial`)
          }
        } else {
          setMembershipSubtitle(tierLabel === "Free" ? "Free plan" : `${tierLabel} · active`)
        }
      } catch {
        setMembershipSubtitle("Free plan")
      }
    }
    const refreshMembershipLabel = async () => {
      try {
        const headers: Record<string, string> = { Accept: "application/json" }
        try {
          Object.assign(headers, IdentityService.getAuthHeaders?.() || {})
        } catch { /* */ }
        const res = await fetch("/api/membership/status", {
          credentials: "include",
          cache: "no-store",
          headers,
        })
        const data = await res.json().catch(() => ({}))
        if (cancelled) return
        if (res.ok && data?.ok) {
          const ent = data.entitlement || data
          const tierRaw = String(ent.tier || data.tier || "free").toLowerCase()
          const tierLabel =
            tierRaw === "vvip" ? "VVIP" : tierRaw === "vip" ? "VIP" : tierRaw === "free" ? "Free" : tierRaw.toUpperCase()
          const isTrial = ent.source === "trial" || ent.lifecycle === "trial" || data.source === "trial"
          const expiresAt = Number(ent.expiresAt || data.expiresAt) || 0
          if (isTrial && expiresAt > Date.now()) {
            const h = Math.max(1, Math.round((expiresAt - Date.now()) / 3600000))
            setMembershipSubtitle(h < 48 ? `${tierLabel} trial · ${h}h left` : `${tierLabel} trial · active`)
          } else {
            setMembershipSubtitle(tierLabel === "Free" ? "Free plan" : `${tierLabel} · active`)
          }
          return
        }
      } catch {
        /* fall through */
      }
      if (!cancelled) applyLocalFallback()
    }
    void refreshMembershipLabel()
    const t1 = window.setTimeout(() => void refreshMembershipLabel(), 400)
    const t2 = window.setTimeout(() => void refreshMembershipLabel(), 1500)
    const onActivated = () => void refreshMembershipLabel()
    window.addEventListener("ghc:membership-activated", onActivated)
    return () => {
      cancelled = true
      window.clearTimeout(t1)
      window.clearTimeout(t2)
      window.removeEventListener("ghc:membership-activated", onActivated)
    }
  }, [section, initialSection])

  // Send narrow patches. Spreading the entire render-time settings snapshot here
  // allowed two quick toggles to overwrite each other's newer values.
  const handleToggle = async (key: string, value: boolean) => {
    await updateSettings({ [key]: value } as Partial<typeof settings>)
  }

  const handleSelect = async (key: string, value: string | string[] | number | boolean | null) => {
    let nextValue = value
    if (key === "locationRadius" && typeof value === "number") nextValue = clampDiscoveryRadiusKm(value)
    if (key === "ageMin" && typeof value === "number") nextValue = Math.min(80, Math.max(18, Math.min(Math.round(value), Number(settings.ageMax) || 80)))
    if (key === "ageMax" && typeof value === "number") nextValue = Math.max(18, Math.min(80, Math.max(Math.round(value), Number(settings.ageMin) || 18)))
    await updateSettings({ [key]: nextValue } as Partial<typeof settings>)
    if (key === "language" && typeof nextValue === "string") regional.setPreferredLocale(nextValue)
  }

  const setThemeMode = async (mode: ThemeMode) => {
    await updateSettings({
      themeMode: mode,
      darkMode: mode === "dark" || (mode === "system" && typeof window !== "undefined" && window.matchMedia("(prefers-color-scheme: dark)").matches),
    })
  }

  const setThemePreset = async (id: string) => {
    const preset = THEME_PRESETS.find((t) => t.id === id)
    await updateSettings({
      themeId: id,
      darkMode: settings.themeMode === "dark" || Boolean(preset?.prefersDark && settings.themeMode !== "light"),
    })
  }

  const onCustomThemeImage = async (file: File | null) => {
    if (!file || !file.type.startsWith("image/")) return
    setThemeBusy(true)
    try {
      const dataUrl = await compressForTheme(file)
      await updateSettings({
        themeCustomImage: dataUrl,
        themeId: settings.themeId || "gh-classic",
      })
    } catch {
      // silent — keep previous image
    } finally {
      setThemeBusy(false)
    }
  }

  if (section === "pi-payout-auth") {
    return (
      <div className="flex h-full min-h-0 flex-col bg-background">
        <div className="flex shrink-0 items-center gap-2 border-b border-border/50 px-3 py-2.5">
          <button type="button" onClick={goBackOneLevel} className="inline-flex min-h-10 min-w-10 items-center justify-center rounded-full hover:bg-muted" aria-label="Back">
            <ArrowLeft size={20} />
          </button>
          <h2 className="text-[16px] font-bold">Pi payout authorization</h2>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-4 pb-[var(--gh-screen-bottom-inset)]">
          <Suspense fallback={<SectionFallback label="Pi payout authorization" />}><PiPayoutAuthorizationCard /></Suspense>
          <p className="mt-4 text-[11px] leading-relaxed text-muted-foreground">
            GreenHaven never moves Pi without this consent. Authorization is stored server-side and checked on every withdrawal request. Revoking blocks future payouts only.
          </p>
        </div>
      </div>
    )
  }

  if (section === "wallet") {
    return <Suspense fallback={<SectionFallback label="Wallet" />}>
        <PremiumWalletScreen onBack={goBackOneLevel} />
      </Suspense>
  }

  if (section === "rewards") {
    return (
      <Suspense fallback={<SectionFallback label="Rewards" />}>
        <RewardsCentreScreen
          onBack={goBackOneLevel}
          onOpenWallet={() => goToSection("wallet")}
        />
      </Suspense>
    )
  }

  if (section === "membership") {
    return <Suspense fallback={<SectionFallback label="Membership" />}>
        <PremiumMembershipScreen onBack={goBackOneLevel} />
      </Suspense>
  }

  if (section === "about") {
    return (
      <div className="flex h-full min-h-0 flex-col bg-background">
        <div className="flex shrink-0 items-center gap-2 border-b border-border/50 bg-card/95 px-2.5 py-1.5">
          <button type="button" onClick={goBackOneLevel} className="hover:opacity-60" aria-label="Back">
            <ChevronLeft size={24} />
          </button>
          <h2 className="text-[14px] font-bold tracking-tight">About GreenHaven</h2>
          <p className="text-[12px] text-muted-foreground">Version {APP_RELEASE_VERSION}</p>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-6 pb-[var(--gh-screen-bottom-inset)] space-y-4">
          <Suspense fallback={<SectionFallback label="Platform status" />}><FoundationStatusCard /></Suspense>
          <div className="rounded-xl border border-border bg-muted/30 p-3">
            <p className="text-[12px] font-bold text-foreground">Pi Directory staking</p>
            <Suspense fallback={<span className="text-xs text-muted-foreground">Loading Pi status…</span>}><PiStakingStatusNote className="mt-1" /></Suspense>
          </div>
          <div className="space-y-4 text-[15px] leading-relaxed whitespace-pre-wrap text-foreground">{LEGAL.about}</div>
        </div>
      </div>
    )
  }

  if (section === "terms") {
    return (
      <div className="flex h-full min-h-0 flex-col bg-background">
        <div className="flex shrink-0 items-center gap-2 border-b border-border/50 bg-card/95 px-2.5 py-1.5">
          <button type="button" onClick={goBackOneLevel} className="hover:opacity-60" aria-label="Back">
            <ChevronLeft size={24} />
          </button>
          <h2 className="text-[14px] font-bold tracking-tight">Terms of Service</h2>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-6 pb-[var(--gh-screen-bottom-inset)]">
          <div className="space-y-4 text-[14px] leading-relaxed whitespace-pre-wrap text-foreground">{LEGAL.terms}</div>
        </div>
      </div>
    )
  }

  if (section === "privacy-policy") {
    return (
      <div className="flex h-full min-h-0 flex-col bg-background">
        <div className="flex shrink-0 items-center gap-2 border-b border-border/50 bg-card/95 px-2.5 py-1.5">
          <button type="button" onClick={goBackOneLevel} className="hover:opacity-60" aria-label="Back">
            <ChevronLeft size={24} />
          </button>
          <h2 className="text-[14px] font-bold tracking-tight">Privacy Policy</h2>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-6 pb-[var(--gh-screen-bottom-inset)]">
          <div className="space-y-4 text-[14px] leading-relaxed whitespace-pre-wrap text-foreground">{LEGAL.privacy}</div>
        </div>
      </div>
    )
  }

  if (section === "help") {
    return (
      <div className="flex h-full min-h-0 flex-col bg-background">
        <div className="flex shrink-0 items-center gap-2 border-b border-border/50 bg-card/95 px-2.5 py-1.5">
          <button type="button" onClick={goBackOneLevel} className="hover:opacity-60" aria-label="Back">
            <ChevronLeft size={24} />
          </button>
          <h2 className="text-[14px] font-bold tracking-tight">Help & Contact</h2>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-6 pb-[var(--gh-screen-bottom-inset)] space-y-3">
          <a
            href={`https://wa.me/${SUPPORT_CONTACTS.whatsapp}`}
            target="_blank"
            rel="noopener noreferrer"
            className="block p-4 bg-card border border-border rounded-2xl hover:border-primary transition"
          >
            <p className="font-bold text-[15px]">WhatsApp Support</p>
            <p className="text-[13px] text-muted-foreground">{SUPPORT_CONTACTS.whatsapp}</p>
          </a>
          <a
            href={SUPPORT_CONTACTS.facebook}
            target="_blank"
            rel="noopener noreferrer"
            className="block p-4 bg-card border border-border rounded-2xl hover:border-primary transition"
          >
            <p className="font-bold text-[15px]">Follow on Facebook</p>
            <p className="text-[13px] text-muted-foreground">GreenHavenXpres</p>
          </a>
          <a
            href={`mailto:${SUPPORT_CONTACTS.email}`}
            className="block p-4 bg-card border border-border rounded-2xl hover:border-primary transition"
          >
            <p className="font-bold text-[15px]">Email Support</p>
            <p className="text-[13px] text-muted-foreground">{SUPPORT_CONTACTS.email}</p>
          </a>
        </div>
      </div>
    )
  }

  if (section === "device-lock") {
    const uid = IdentityService.getCurrentUserId()
    const hasPin = hasPinConfigured(uid)
    const { lockNow, configurePin, idleLockMs, policy, setPolicy } = sessionLock
    return (
      <div className="flex h-full min-h-0 flex-col bg-background">
        <div className="flex shrink-0 items-center gap-2 border-b border-border/50 bg-card/95 px-2.5 py-1.5">
          <button type="button" onClick={goBackOneLevel} className="hover:opacity-60" aria-label="Back">
            <ChevronLeft size={24} />
          </button>
          <h2 className="text-[14px] font-bold tracking-tight">Device lock</h2>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-6 pb-[var(--gh-screen-bottom-inset)] space-y-4">
          <p className="text-[13px] leading-relaxed text-muted-foreground">
            Protects this device after idle or when you leave the app. Your real account identity is
            still Pi Network — the PIN never replaces Pi sign-in or Pi Wallet approval for payments.
          </p>
          <div className="rounded-[1.25rem] border border-border/50 bg-card p-4 space-y-3 shadow-[var(--gh-card-shadow)]">
            <p className="text-[14px] font-bold">
              Status:{" "}
              <span className={hasPin ? "text-emerald-600" : "text-amber-600"}>
                {hasPin ? "PIN enabled on this device" : "No PIN yet"}
              </span>
            </p>
            <p className="text-[12px] text-muted-foreground">
              Policy: <span className="font-semibold text-foreground">{policy.label}</span>
              {" · "}
              idle ~{Math.round(idleLockMs / 60000)} min
              {policy.lockOnBackground
                ? policy.backgroundGraceMs === 0
                  ? " · lock on background"
                  : ` · background grace ${Math.round(policy.backgroundGraceMs / 1000)}s`
                : ""}
            </p>
            <div className="flex flex-col gap-2">
              {(
                [
                  ["high", "High security"],
                  ["balanced", "Balanced"],
                  ["convenience", "Convenience"],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setPolicy(id)}
                  className={`rounded-xl border px-3 py-2.5 text-left text-[13px] font-semibold transition ${
                    policy.id === id
                      ? "border-emerald-500/50 bg-emerald-500/10 text-foreground"
                      : "border-border bg-background text-muted-foreground hover:bg-muted/40"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
            {hasPin ? (
              <>
                <button
                  type="button"
                  onClick={() => lockNow()}
                  className="w-full rounded-full bg-primary px-4 py-3 text-sm font-bold text-primary-foreground"
                >
                  Lock now
                </button>
                <button
                  type="button"
                  onClick={() => {
                    clearPin(uid)
                    window.location.reload()
                  }}
                  className="w-full rounded-full border border-border px-4 py-3 text-sm font-semibold"
                >
                  Remove PIN from this device
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={() => {
                  void promptDialog({ title: "Create device PIN", message: "Choose a 4–8 digit PIN. This unlocks this device only.", label: "Device PIN", inputType: "password", maxLength: 8, pattern: "^\\d{4,8}$", confirmLabel: "Create PIN" }).then((pin) => {
                    if (pin) void configurePin(pin)
                  })
                }}
                className="w-full rounded-full bg-primary px-4 py-3 text-sm font-bold text-primary-foreground"
              >
                Create device PIN
              </button>
            )}
          </div>
          <p className="text-[11px] text-muted-foreground">
            PIN is stored only on this device as a one-way hash. After 5 wrong attempts, GreenHaven
            requires a full Pi sign-in again. GHC transfers and Pi payments still require server
            checks and Pi Wallet — the app PIN is not financial authorization.
          </p>

          {/* Phase 5: server sessions (separate from local App Lock) */}
          <Suspense fallback={<SectionFallback label="Active sessions" />}><ActiveSessionsPanel /></Suspense>
          <div className="mt-3"><Suspense fallback={<SectionFallback label="Security signals" />}><AccountSecuritySignals /></Suspense></div>
          <div className="mt-3"><Suspense fallback={<SectionFallback label="Pi capabilities" />}><PiPlatformCapabilitiesCard /></Suspense></div>
          <div className="mt-3"><Suspense fallback={<SectionFallback label="Pi listing readiness" />}><PiListingReadinessCard /></Suspense></div>
          <div className="mt-3"><Suspense fallback={<SectionFallback label="Compliance posture" />}><CompliancePostureCard /></Suspense></div>
          <div className="mt-3"><Suspense fallback={<SectionFallback label="Claim readiness" />}><ClaimReadinessCard /></Suspense></div>

          {/* Phase 7: optional passkeys — does not replace Pi or App Lock */}
          <Suspense fallback={<SectionFallback label="Passkeys" />}><PasskeysPanel /></Suspense>
        </div>
      </div>
    )
  }

  if (section === "performance") {
    return <PerformanceSettingsScreen onBack={goBackOneLevel} />
  }

  if (section === "privacy") {
    return (
      <div className="flex h-full min-h-0 flex-col bg-background">
        <div className="flex shrink-0 items-center gap-2 border-b border-border/50 bg-card/95 px-2.5 py-1.5">
          <button type="button" onClick={goBackOneLevel} className="hover:opacity-60" aria-label="Back">
            <ChevronLeft size={24} />
          </button>
          <h2 className="text-[14px] font-bold tracking-tight">Privacy & Safety</h2>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-6 pb-[var(--gh-screen-bottom-inset)] space-y-4">
          {(() => {
            const health = getPrivacyHealth(settings as any)
            return (
              <div className="rounded-2xl border border-border bg-card p-4 shadow-[var(--gh-card-shadow)]" aria-label={`Privacy posture: ${health.label}`}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-[15px] font-bold">Privacy posture</p>
                    <p className="mt-1 text-[12px] text-muted-foreground">A practical summary of the controls you have enabled. GreenHaven does not use this score as a trust badge.</p>
                  </div>
                  <div className="shrink-0 rounded-full border border-border px-3 py-1 text-[12px] font-bold">{health.label}</div>
                </div>
                <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted" aria-hidden="true"><div className="h-full rounded-full bg-emerald-600" style={{ width: `${health.score}%` }} /></div>
                <p className="mt-2 text-[12px] text-muted-foreground">{health.score}/100 privacy posture</p>
                {health.recommendations[0] ? <p className="mt-2 rounded-xl bg-muted/50 px-3 py-2 text-[12px] leading-relaxed"><span className="font-semibold">Recommended:</span> {health.recommendations[0]}</p> : null}
              </div>
            )
          })()}
          <div>
            <p className="text-[14px] font-bold mb-3">Online Status</p>
            <select
              value={settings.onlineStatus}
              onChange={(e) => handleSelect("onlineStatus", e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-border bg-input"
            >
              <option value="everyone">Everyone</option>
              <option value="matches-only">Matches Only</option>
              <option value="hidden">Hidden</option>
            </select>
          </div>
          <div>
            <p className="text-[15px] font-semibold mb-1">Who can message you</p>
            <p className="mb-2 text-[12px] text-muted-foreground">Example: Matches only blocks cold messages from strangers.</p>
            <select
              value={settings.whoCanMessage}
              onChange={(e) => handleSelect("whoCanMessage", e.target.value)}
              className="min-h-12 w-full rounded-xl border border-border bg-input px-4 py-2.5 text-[15px]"
            >
              <option value="everyone">Everyone</option>
              <option value="matches-only">Matches only</option>
              <option value="no-one">No one</option>
            </select>
          </div>
          <div>
            <p className="text-[14px] font-bold mb-3">Profile Visibility</p>
            <select
              value={settings.profileVisibility}
              onChange={(e) => handleSelect("profileVisibility", e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-border bg-input"
            >
              <option value="everyone">Everyone</option>
              <option value="matches-only">Matches Only</option>
              <option value="hidden">Hidden</option>
            </select>
            <p className="mt-1 text-[12px] text-muted-foreground">Example: Hidden means you will not appear in Find discovery.</p>
          </div>
          <div>
            <p className="text-[14px] font-bold mb-3">Who Can Discover Me</p>
            <select
              value={(settings as any).whoCanDiscover || "everyone"}
              onChange={(e) => handleSelect("whoCanDiscover" as any, e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-border bg-input"
            >
              <option value="everyone">Everyone</option>
              <option value="matches-only">Matches &amp; connections only</option>
              <option value="no-one">No one (pause discovery)</option>
            </select>
          </div>
          <div>
            <p className="text-[14px] font-bold mb-3">Who Can Follow Me</p>
            <select
              value={(settings as any).whoCanFollow || "everyone"}
              onChange={(e) => handleSelect("whoCanFollow" as any, e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-border bg-input"
            >
              <option value="everyone">Everyone</option>
              <option value="matches-only">Matches &amp; connections only</option>
              <option value="no-one">No one</option>
            </select>
          </div>
          <div>
            <p className="text-[14px] font-bold mb-3">Who Can Connect With Me</p>
            <select
              value={(settings as any).whoCanConnect || "everyone"}
              onChange={(e) => handleSelect("whoCanConnect" as any, e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-border bg-input"
            >
              <option value="everyone">Everyone</option>
              <option value="matches-only">Matches only</option>
              <option value="no-one">No one</option>
            </select>
          </div>
          <div className="rounded-xl border border-border bg-muted/30 p-4 space-y-3">
            <p className="text-[14px] font-bold">Profile details others can see</p>
            {[
              ["showActivity", "Activity / recently active", (settings as any).showActivity !== false],
              ["showInterests", "Interests", (settings as any).showInterests !== false],
              ["showCommunities", "Communities", (settings as any).showCommunities !== false],
              ["showLocation", "Location", settings.showLocation !== false],
            ].map(([key, label, on]) => (
              <label key={String(key)} className="flex items-center justify-between gap-3 text-[13px]">
                <span>{label}</span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={Boolean(on)}
                  onClick={() => handleSelect(key as any, (!on) as any)}
                  className={`relative min-h-11 min-w-12 rounded-full transition ${on ? "bg-emerald-600" : "bg-muted-foreground/30"}`}
                >
                  <span className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition ${on ? "left-5" : "left-0.5"}`} />
                </button>
              </label>
            ))}
          </div>
          <div>
            <p className="text-[14px] font-bold mb-3">Who Can View My Stories</p>
            <select value={settings.storyVisibility} onChange={(e) => handleSelect("storyVisibility", e.target.value)} className="w-full px-4 py-2 rounded-lg border border-border bg-input">
              <option value="everyone">Everyone</option>
              <option value="matches-only">Matches Only</option>
              <option value="no-one">No One</option>
            </select>
          </div>
          <div>
            <p className="text-[15px] font-semibold mb-1">Location privacy</p>
            <p className="mb-2 text-[12px] text-muted-foreground">Choose how precisely others can see where you are.</p>
            <div className="space-y-2">
              {[
                { v: "city", label: "Exact city", hint: "e.g. Lagos" },
                { v: "region", label: "Region only", hint: "e.g. South West" },
                { v: "hidden", label: "Hidden", hint: "Not shown on profile" },
              ].map((opt) => {
                const current = settings.showLocation === false || (settings as any).locationPrivacy === "hidden"
                  ? "hidden"
                  : (settings as any).locationPrivacy === "region" || (settings as any).locationPrivacy === "admin1"
                    ? "region"
                    : "city"
                const on = current === opt.v
                return (
                  <button
                    key={opt.v}
                    type="button"
                    onClick={() => {
                      if (opt.v === "hidden") {
                        void handleToggle("showLocation", false)
                        void handleSelect("locationPrivacy" as any, "hidden")
                      } else {
                        void handleToggle("showLocation", true)
                        void handleSelect("locationPrivacy" as any, opt.v === "region" ? "admin1" : "locality")
                      }
                    }}
                    className={`flex min-h-12 w-full items-center gap-3 rounded-xl border px-3 text-left transition ${
                      on ? "border-emerald-500 bg-emerald-50/80 dark:bg-emerald-950/30" : "border-border bg-card"
                    }`}
                  >
                    <span className={`flex h-5 w-5 items-center justify-center rounded-full border-2 ${on ? "border-emerald-600" : "border-muted-foreground/40"}`}>
                      {on ? <span className="h-2.5 w-2.5 rounded-full bg-emerald-600" /> : null}
                    </span>
                    <span>
                      <span className="block text-[15px] font-semibold text-foreground">{opt.label}</span>
                      <span className="block text-[12px] text-muted-foreground">{opt.hint}</span>
                    </span>
                  </button>
                )
              })}
            </div>
          </div>

          <Suspense fallback={<SectionFallback label="Account data controls" />}><AccountDataControls /></Suspense>

          {/* Blocked users */}
          <div className="pt-2">
            <p className="mb-2 text-[15px] font-semibold">Blocked users</p>
            <p className="mb-2 text-[12px] text-muted-foreground">They cannot message you or appear in Find.</p>
            {(blockedUsers || []).length === 0 ? (
              <p className="rounded-xl border border-dashed border-border px-3 py-4 text-[13px] text-muted-foreground">No blocked users</p>
            ) : (
              <ul className="space-y-2">
                {(blockedUsers || []).map((id: string) => {
                  const c = (candidates || []).find((x: { id: string }) => x.id === id)
                  const name = c?.name || id.slice(0, 12)
                  return (
                    <li key={id} className="flex min-h-12 items-center gap-3 rounded-xl border border-border bg-card px-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-sm font-bold">
                        {(name || "?").charAt(0)}
                      </div>
                      <span className="min-w-0 flex-1 truncate text-[15px] font-medium">{name}</span>
                      <button
                        type="button"
                        onClick={() => {
                          void (async () => {
                            try {
                              await unblockUser?.(id)
                              try {
                                window.dispatchEvent(new CustomEvent("ghc:toast", { detail: { message: "User unblocked", type: "success" } }))
                              } catch { /* */ }
                            } catch {
                              try {
                                window.dispatchEvent(new CustomEvent("ghc:toast", { detail: { message: "Could not unblock", type: "error" } }))
                              } catch { /* */ }
                            }
                          })()
                        }}
                        className="min-h-10 rounded-full border border-border px-3 text-[12px] font-bold text-foreground"
                      >
                        Unblock
                      </button>
                    </li>
                  )
                })}
              </ul>
            )}
          </div>
        </div>
      </div>
    )
  }

  if (section === "preferences") {
    const rel = Array.isArray(settings.relationshipType) ? settings.relationshipType : []
    return (
      <div className="flex h-full min-h-0 flex-col bg-background">
        <div className="border-b border-border/50 bg-card/95 px-2.5 py-1.5">
          <div className="flex items-center gap-3">
            <button type="button" onClick={goBackOneLevel} className="hover:opacity-60" aria-label="Back">
              <ChevronLeft size={24} />
            </button>
            <div className="min-w-0">
              <h2 className="text-[18px] font-bold leading-tight">Preferences</h2>
              <p className="text-[12px] text-muted-foreground">Language &amp; discovery defaults</p>
            </div>
          </div>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-5 pb-[var(--gh-screen-bottom-inset)] space-y-5">
          {/* Language */}
          <section className="rounded-[1.25rem] border border-border/50 bg-card p-4 shadow-[var(--gh-card-shadow)]">
            <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground mb-2">Language</p>
            <select
              value={selectedLocale}
              onChange={(e) => void handleSelect("language", e.target.value)}
              className="w-full min-h-11 rounded-xl border border-border bg-background px-3 text-sm font-semibold"
              aria-label="App language"
            >
              {localeOptions.map((option) => (
                <option key={option.localeTag} value={option.localeTag}>
                  {option.nativeName || option.name} — {option.name}{option.translationAvailable ? "" : option.partialTranslationAvailable ? " (partially translated)" : " (not translated yet)"}
                </option>
              ))}
            </select>
            <p className="mt-2 text-[11px] text-muted-foreground">{regional.uiTranslationAvailable ? "English interface resources are active." : getShellTranslationStatus(regional.locale) === "partial" ? getShellMessage("languagePartial", regional.locale) : translate("language.translationPending")}</p>
            <p className="mt-1 text-[11px] text-muted-foreground">{getShellMessage("contentUnchanged", regional.locale)}</p>
          </section>

          {/* Device date, time & optional live location */}
          <section className="rounded-[1.25rem] border border-border/50 bg-card p-4 space-y-3 shadow-[var(--gh-card-shadow)]">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Regional context</p>
              <p className="mt-1 text-[14px] font-bold">Date, time &amp; location</p>
              <p className="mt-1 text-[11px] text-muted-foreground">GreenHaven uses your device time zone and language automatically. Live location is optional and is only requested when you enable it.</p>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="rounded-xl border border-border/60 bg-muted/20 p-3">
                <span className="text-muted-foreground">Time zone</span>
                <p className="mt-1 truncate font-bold" title={regional.timeZone}>{regional.timeZone}</p>
              </div>
              <div className="rounded-xl border border-border/60 bg-muted/20 p-3">
                <span className="text-muted-foreground">Language</span>
                <p className="mt-1 truncate font-bold">{regional.locale}</p>
              </div>
            </div>
            <div className="flex items-center justify-between gap-3 rounded-xl border border-border/60 bg-muted/20 p-3">
              <div className="min-w-0">
                <p className="text-[13px] font-bold">Live location</p>
                <p className="mt-0.5 text-[11px] text-muted-foreground">{regional.location ? "Available for nearby features" : regional.locationPermission === "denied" ? "Permission denied on this device" : "Not enabled"}</p>
              </div>
              {regional.location ? (
                <button type="button" onClick={regional.clearLocation} className="min-h-10 rounded-xl border border-border bg-background px-3 text-[11px] font-bold">Turn off</button>
              ) : (
                <button type="button" onClick={() => void regional.requestLocation()} className="min-h-10 rounded-xl bg-emerald-600 px-3 text-[11px] font-bold text-white">Enable</button>
              )}
            </div>
            {regional.location ? <p className="text-[10px] text-muted-foreground">Exact coordinates are kept in memory for the current session and are rounded before optional API use.</p> : null}
          </section>

          {/* Discovery */}
          <section className="rounded-[1.25rem] border border-border/50 bg-card p-4 space-y-4 shadow-[var(--gh-card-shadow)]">
            <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Discovery defaults</p>
            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <p className="text-[14px] font-bold">Location radius</p>
                <span className="text-[13px] font-semibold text-emerald-700">{settings.locationRadius} mi</span>
              </div>
              <input
                type="range"
                min="1"
                max="100"
                value={settings.locationRadius}
                onChange={(e) => handleSelect("locationRadius", parseInt(e.target.value, 10))}
                className="w-full accent-emerald-600"
                aria-label="Location radius in miles"
              />
            </div>
            <div>
              <p className="mb-2 text-[14px] font-bold">Age range</p>
              <div className="flex gap-3">
                <label className="flex-1 text-[11px] font-semibold text-muted-foreground">
                  Min
                  <input
                    type="number"
                    min={18}
                    max={80}
                    value={settings.ageMin}
                    onChange={(e) => handleSelect("ageMin", parseInt(e.target.value, 10) || 18)}
                    className="mt-1 w-full min-h-11 rounded-xl border border-border bg-background px-3 text-sm font-semibold"
                  />
                </label>
                <label className="flex-1 text-[11px] font-semibold text-muted-foreground">
                  Max
                  <input
                    type="number"
                    min={18}
                    max={80}
                    value={settings.ageMax}
                    onChange={(e) => handleSelect("ageMax", parseInt(e.target.value, 10) || 45)}
                    className="mt-1 w-full min-h-11 rounded-xl border border-border bg-background px-3 text-sm font-semibold"
                  />
                </label>
              </div>
            </div>
            <div>
              <p className="mb-2 text-[14px] font-bold">Looking for</p>
              <div className="flex flex-wrap gap-2">
                {(["friendship", "dating", "networking"] as const).map((type) => {
                  const on = rel.includes(type)
                  return (
                    <button
                      key={type}
                      type="button"
                      onClick={() => {
                        const updated = on ? rel.filter((t) => t !== type) : [...rel, type]
                        void handleSelect("relationshipType", updated.length ? updated : [type])
                      }}
                      className={`min-h-10 rounded-full px-4 text-[13px] font-bold capitalize transition ${
                        on
                          ? "bg-emerald-600 text-white shadow-sm"
                          : "border border-border bg-muted/40 text-foreground"
                      }`}
                    >
                      {type}
                    </button>
                  )
                })}
              </div>
            </div>
          </section>

          <section className="rounded-[1.25rem] border border-border/50 bg-card p-4 shadow-[var(--gh-card-shadow)]">
            <p className="text-[13px] font-bold text-foreground">Need finer alert control?</p>
            <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">
              Choose which events can notify you under{" "}
              <button type="button" className="font-bold text-emerald-700 underline" onClick={() => goToSection("notifications")}>
                Notifications
              </button>
              . Who can message or discover you is under{" "}
              <button type="button" className="font-bold text-emerald-700 underline" onClick={() => goToSection("privacy")}>
                Privacy &amp; Safety
              </button>
              .
            </p>
          </section>
        </div>
      </div>
    )
  }

  if (section === "notifications") {
    const toggles: {
      key: keyof typeof settings
      title: string
      body: string
      defaultOn: boolean
      categories: NotificationCategory[]
    }[] = [
      {
        key: "notifyMatches",
        title: "New matches",
        body: "When someone matches with you or accepts a connection.",
        defaultOn: true,
        categories: ["matches", "connections"],
      },
      {
        key: "notifyMessages",
        title: "Messages & requests",
        body: "Direct messages, group mentions, and GHC requests.",
        defaultOn: true,
        categories: ["messages", "mentions", "wallet"],
      },
      {
        key: "notifyRewards",
        title: "Rewards & claims",
        body: "Pending validation, claimable GHC, and streak reminders.",
        defaultOn: true,
        categories: ["rewards"],
      },
      {
        key: "notifyMembership",
        title: "Membership & trial",
        body: "Trial ending, renewal, and plan changes.",
        defaultOn: true,
        categories: ["premium"],
      },
      {
        key: "notifyProfileViews",
        title: "Profile views",
        body: "Occasional digests when people view your profile.",
        defaultOn: false,
        categories: ["profile_views"],
      },
      {
        key: "notifyMarketing",
        title: "Tips & product updates",
        body: "Optional product news. Never sold to advertisers.",
        defaultOn: false,
        categories: ["product_updates"],
      },
    ]
    return (
      <div className="flex h-full min-h-0 flex-col bg-background">
        <div className="border-b border-border/50 bg-card/95 px-2.5 py-1.5">
          <div className="flex items-center gap-3">
            <button type="button" onClick={goBackOneLevel} className="hover:opacity-60" aria-label="Back">
              <ChevronLeft size={24} />
            </button>
            <div className="min-w-0">
              <h2 className="text-[18px] font-bold leading-tight">Notifications</h2>
              <p className="text-[12px] text-muted-foreground">Choose what can reach you</p>
            </div>
          </div>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-5 pb-[var(--gh-screen-bottom-inset)] space-y-3">
          <section className="rounded-2xl border border-emerald-100 bg-emerald-50/50 p-4 dark:border-emerald-900 dark:bg-emerald-950/30">
            <p className="text-[12px] leading-relaxed text-muted-foreground">
              These control your in-app inbox and local browser alerts. Browser alerts require permission and an active app session. Remote push to offline devices is not yet configured.
            </p>
            <button
              type="button"
              onClick={() => {
                void ensureBrowserNotificationPermission().then((ok) => {
                  try {
                    window.dispatchEvent(
                      new CustomEvent("ghc:toast", {
                        detail: {
                          message: ok
                            ? "Browser alerts enabled"
                            : "Browser alerts were not enabled",
                          type: ok ? "success" : "info",
                        },
                      }),
                    )
                  } catch { /* */ }
                })
              }}
              className="mt-3 min-h-10 w-full rounded-xl border border-emerald-500/40 bg-white/80 text-xs font-bold text-emerald-900 dark:bg-emerald-950/50 dark:text-emerald-100"
            >
              {browserPermission === "granted" ? "Browser permission granted" : browserPermission === "denied" ? "Permission blocked — change it in browser site settings" : browserPermission === "unsupported" ? "Browser alerts unsupported here" : "Enable browser alerts"}
            </button>
            <p className="mt-2 text-[11px] text-muted-foreground">In-app choices sync with your account when the server profile store is available. “This device” choices stay in this browser and do not change your other devices.</p>
          </section>
          <section className="rounded-[1.25rem] border border-border/50 bg-card divide-y divide-border/50 overflow-hidden shadow-[var(--gh-card-shadow)]">
            {toggles.map((t) => {
              const raw = settings[t.key]
              const categoryPrefs = t.categories.map((category) => notificationPrefs[category])
              const inAppOn = categoryPrefs.length ? categoryPrefs.every((prefs) => Boolean(prefs.inApp)) : (typeof raw === "boolean" ? raw : t.defaultOn)
              const browserOn = categoryPrefs.length ? categoryPrefs.every((prefs) => Boolean(prefs.push)) : false
              const updateChannel = (channel: "inApp" | "push", enabled: boolean) => {
                if (channel === "push" && enabled && browserPermission !== "granted") {
                  void ensureBrowserNotificationPermission().then((ok) => {
                    setBrowserPermission(typeof window !== "undefined" && "Notification" in window ? Notification.permission : "unsupported")
                    if (!ok) return
                    const next = { ...notificationPrefs }
                    for (const category of t.categories) next[category] = { ...next[category], push: true }
                    setNotificationPrefs(next)
                    saveNotificationPreferences(next, notificationIdentityId)
                  })
                  return
                }
                const next = { ...notificationPrefs }
                for (const category of t.categories) next[category] = { ...next[category], [channel]: enabled }
                setNotificationPrefs(next)
                saveNotificationPreferences(next, notificationIdentityId)
                if (channel === "inApp") {
                  void handleSelect(t.key as never, enabled as never)
                  void fetch("/api/notifications/preferences", {
                    method: "PATCH",
                    headers: { "Content-Type": "application/json", ...IdentityService.getAuthHeaders() },
                    body: JSON.stringify({ preferences: serializeAccountNotificationPreferences(next) }),
                  }).then(async (response) => {
                    const body = await response.json().catch(() => null)
                    if (!response.ok || body?.ok !== true || body?.durable !== true) {
                      window.dispatchEvent(new CustomEvent("ghc:toast", { detail: { message: "In-app preference saved on this device; account sync is unavailable", type: "info" } }))
                    }
                  }).catch(() => window.dispatchEvent(new CustomEvent("ghc:toast", { detail: { message: "In-app preference saved locally; account sync will retry when online", type: "info" } })))
                }
              }
              return (
                <div key={String(t.key)} className="flex flex-col gap-3 px-4 py-3.5 sm:flex-row sm:items-center">
                  <div className="min-w-0 flex-1">
                    <p className="text-[14px] font-bold text-foreground">{t.title}</p>
                    <p className="mt-0.5 text-[12px] leading-snug text-muted-foreground">{t.body}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-3 sm:min-w-[250px]">
                    <button type="button" role="switch" aria-checked={inAppOn} aria-label={`${t.title} in-app inbox`} onClick={() => updateChannel("inApp", !inAppOn)} className="flex min-h-11 items-center justify-between gap-2 rounded-xl border border-border/60 px-2.5 text-[11px] font-semibold">
                      <span>In-app</span><span className={`relative h-6 w-10 rounded-full ${inAppOn ? "bg-emerald-600" : "bg-muted"}`}><span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow ${inAppOn ? "left-[18px]" : "left-0.5"}`} /></span>
                    </button>
                    <button type="button" role="switch" aria-checked={browserOn} aria-label={`${t.title} on this device`} onClick={() => updateChannel("push", !browserOn)} className="flex min-h-11 items-center justify-between gap-2 rounded-xl border border-border/60 px-2.5 text-[11px] font-semibold">
                      <span>This device</span><span className={`relative h-6 w-10 rounded-full ${browserOn ? "bg-emerald-600" : "bg-muted"}`}><span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow ${browserOn ? "left-[18px]" : "left-0.5"}`} /></span>
                    </button>
                  </div>
                </div>
              )
            })}
          </section>
          <p className="px-1 text-[11px] leading-relaxed text-muted-foreground">
            GHC balance changes never appear on your public profile. Reward and wallet alerts stay private to you.
          </p>
        </div>
      </div>
    )
  }

  if (section === "appearance") {
    const mode = (settings.themeMode as ThemeMode | undefined) || (settings.darkMode ? "dark" : "light")
    const activePreset = settings.themeId || "gh-classic"

    return (
      <div className="h-full flex flex-col bg-background text-foreground">
        <div className="flex shrink-0 items-center gap-2 border-b border-border/50 bg-card/95 px-2.5 py-1.5">
          <button type="button" onClick={goBackOneLevel} className="hover:opacity-60" aria-label="Back">
            <ChevronLeft size={24} />
          </button>
          <h2 className="text-[14px] font-bold tracking-tight">Appearance</h2>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto p-5 pb-[var(--gh-screen-bottom-inset)] space-y-6">
          {/* Mode */}
          <div>
            <p className="text-[13px] font-bold text-muted-foreground mb-2">Display mode</p>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  { id: "light" as const, label: "Light", icon: Sun },
                  { id: "dark" as const, label: "Dark", icon: Moon },
                  { id: "system" as const, label: "System", icon: Monitor },
                ] as const
              ).map(({ id, label, icon: Icon }) => {
                const selected = mode === id
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setThemeMode(id)}
                    className={`flex flex-col items-center gap-1.5 rounded-2xl border px-2 py-3 text-xs font-semibold transition ${
                      selected
                        ? "border-primary bg-primary/10 text-primary ring-2 ring-primary/30"
                        : "border-border bg-card text-foreground hover:border-primary/40"
                    }`}
                  >
                    <Icon size={18} aria-hidden />
                    {label}
                  </button>
                )
              })}
            </div>
            <p className="mt-2 text-[11px] text-muted-foreground">
              Dark mode uses true dark surfaces. System follows your device preference.
            </p>
          </div>

          {/* Presets */}
          <div>
            <p className="text-[13px] font-bold text-muted-foreground mb-2">Themes</p>
            <div className="grid grid-cols-2 gap-2.5">
              {THEME_PRESETS.map((preset) => {
                const selected = activePreset === preset.id
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => setThemePreset(preset.id)}
                    className={`relative overflow-hidden rounded-2xl border text-left transition ${
                      selected ? "border-primary ring-2 ring-primary/30" : "border-border hover:border-primary/40"
                    }`}
                  >
                    <div
                      className="h-16 min-h-[64px] w-full"
                      style={{ background: preset.preview }}
                      aria-hidden
                    />
                    <div className="bg-card px-2.5 py-2">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-[12px] font-bold text-foreground">{preset.name}</span>
                        {selected && <Check size={14} className="text-primary shrink-0" aria-hidden />}
                      </div>
                      <p className="mt-0.5 text-[10px] leading-snug text-muted-foreground line-clamp-2">
                        {preset.description}
                        {preset.premium ? " · Premium look" : ""}
                      </p>
                    </div>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Custom wallpaper */}
          <div>
            <p className="text-[13px] font-bold text-muted-foreground mb-2">Custom background</p>
            <div className="rounded-[1.25rem] border border-border/50 bg-card p-3.5 space-y-3 shadow-[var(--gh-card-shadow)]">
              {settings.themeCustomImage ? (
                <div
                  className="h-28 w-full rounded-xl bg-cover bg-center border border-border"
                  style={{ backgroundImage: `url(${settings.themeCustomImage})` }}
                  role="img"
                  aria-label="Current custom theme background"
                />
              ) : (
                <div className="flex h-24 items-center justify-center rounded-xl border border-dashed border-border bg-muted/40 text-[12px] text-muted-foreground">
                  No custom image
                </div>
              )}
              <input
                ref={themeFileRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0] || null
                  void onCustomThemeImage(f)
                  e.target.value = ""
                }}
              />
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={themeBusy}
                  onClick={() => themeFileRef.current?.click()}
                  className="inline-flex min-h-10 flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-3 text-[13px] font-bold text-primary-foreground disabled:opacity-50"
                >
                  <ImagePlus size={16} aria-hidden />
                  {themeBusy ? "Uploading…" : "Upload image"}
                </button>
                {settings.themeCustomImage && (
                  <button
                    type="button"
                    onClick={() => handleSelect("themeCustomImage", null)}
                    className="min-h-10 rounded-xl border border-border px-3 text-[13px] font-semibold text-foreground"
                  >
                    Remove
                  </button>
                )}
              </div>
              {settings.themeCustomImage && (
                <div>
                  <label className="text-[11px] font-semibold text-muted-foreground" htmlFor="theme-opacity">
                    Image strength: {Math.round((settings.themeImageOpacity ?? 0.35) * 100)}%
                  </label>
                  <input
                    id="theme-opacity"
                    type="range"
                    min={0.1}
                    max={0.85}
                    step={0.05}
                    value={settings.themeImageOpacity ?? 0.35}
                    onChange={(e) => handleSelect("themeImageOpacity", Number(e.target.value))}
                    className="mt-1 w-full accent-primary"
                  />
                </div>
              )}
              <p className="text-[10px] leading-relaxed text-muted-foreground">
                Images are compressed and stored with your settings. Prefer soft patterns so text stays readable.
              </p>
            </div>
          </div>

          {/* Language */}
          <div>
            <p className="text-[13px] font-bold text-muted-foreground mb-2">Language</p>
            <select
              value={selectedLocale}
              onChange={(e) => void handleSelect("language", e.target.value)}
              className="w-full rounded-xl border border-border bg-input px-4 py-2.5 text-sm text-foreground"
              aria-label="App language"
            >
              {localeOptions.map((option) => (
                <option key={option.localeTag} value={option.localeTag}>
                  {option.nativeName || option.name} — {option.name}{option.translationAvailable ? "" : option.partialTranslationAvailable ? " (partially translated)" : " (not translated yet)"}
                </option>
              ))}
            </select>
            <p className="mt-2 text-[11px] text-muted-foreground">{regional.uiTranslationAvailable ? "English interface resources are active." : getShellTranslationStatus(regional.locale) === "partial" ? getShellMessage("languagePartial", regional.locale) : translate("language.translationPending")}</p>
          </div>
        </div>
      </div>
    )
  }

  const groups: {
    heading: string
    items: {
      title: string
      subtitle?: string
      icon: ReactNode
      action: () => void
      keywords?: string
    }[]
  }[] = [
    {
      heading: "Account & economy",
      items: [
        {
          title: "GHC Wallet",
          subtitle: "Balance, send, request · private",
          icon: <Wallet size={20} strokeWidth={1.75} />,
          action: () => goToSection("wallet"),
          keywords: "wallet ghc coin balance transfer send receive",
        },
        {
          title: "Rewards Centre",
          subtitle: "Missions & daily claims",
          icon: <Gift size={20} strokeWidth={1.75} />,
          action: () => goToSection("rewards"),
          keywords: "rewards challenges earn pending claim",
        },
        {
          title: "Pi payout authorization",
          subtitle: "Required consent for A2U withdrawals",
          icon: <Shield size={20} strokeWidth={1.75} />,
          action: () => goToSection("pi-payout-auth"),
          keywords: "pi wallet authorization a2u payout withdraw consent identity",
        },
        {
          title: "Invite friends",
          subtitle: "Referral code · rewards when settlement is enabled",
          icon: <Users size={20} strokeWidth={1.75} />,
          action: () => goToSection("rewards"),
          keywords: "referral invite friends share code",
        },
        {
          title: "Membership",
          subtitle: membershipSubtitle,
          icon: <Crown size={20} strokeWidth={1.75} />,
          action: () => goToSection("membership"),
          keywords: "vip vvip free trial premium membership",
        },
      ],
    },
    {
      heading: "Privacy & safety",
      items: [
        {
          title: "Privacy & Safety",
          subtitle: "Who can message, discover, see you",
          icon: <Shield size={20} strokeWidth={1.75} />,
          action: () => goToSection("privacy"),
          keywords: "privacy block blocked safety message discover follow",
        },
        {
          title: "Device lock",
          subtitle: "PIN after idle · bank-style session protection",
          icon: <Lock size={20} strokeWidth={1.75} />,
          action: () => goToSection("device-lock"),
          keywords: "pin lock password security idle session device",
        },
      ],
    },
    {
      heading: "Preferences",
      items: [
        {
          title: "Performance & data",
          subtitle: "Device readiness, connection and data saver",
          icon: <Gauge size={20} strokeWidth={1.75} />,
          action: () => goToSection("performance"),
          keywords: "performance speed data saver network device low data battery loading",
        },
        {
          title: "Notifications",
          subtitle: "Matches, messages, rewards, membership",
          icon: <Bell size={20} strokeWidth={1.75} />,
          action: () => goToSection("notifications"),
          keywords: "notifications alerts push matches messages rewards membership",
        },
        {
          title: "Preferences",
          subtitle: "Language & discovery defaults",
          icon: <User size={20} strokeWidth={1.75} />,
          action: () => goToSection("preferences"),
          keywords: "language discovery age radius looking for",
        },
        {
          title: "Appearance",
          subtitle: "Light, dark, themes",
          icon: <Palette size={20} strokeWidth={1.75} />,
          action: () => goToSection("appearance"),
          keywords: "theme dark light mode appearance",
        },
      ],
    },
    {
      heading: "Support",
      items: [
        {
          title: "Help & Support",
          subtitle: "WhatsApp, email, Facebook",
          icon: <HelpCircle size={20} strokeWidth={1.75} />,
          action: () => goToSection("help"),
          keywords: "help support contact whatsapp email",
        },
        {
          title: "About GreenHaven",
          subtitle: `Version ${APP_RELEASE_VERSION}`,
          icon: <Info size={20} strokeWidth={1.75} />,
          action: () => goToSection("about"),
          keywords: "about version mission",
        },
        {
          title: "Terms of Service",
          icon: <FileText size={20} strokeWidth={1.75} />,
          action: () => goToSection("terms"),
          keywords: "terms legal",
        },
        {
          title: "Privacy Policy",
          icon: <FileText size={20} strokeWidth={1.75} />,
          action: () => goToSection("privacy-policy"),
          keywords: "privacy policy legal",
        },
      ],
    },
  ]

  const filteredGroups = groups
    .map((group) => ({
      ...group,
      items: group.items
        .map((item) => ({ item, score: matchSettingsSearch(settingsQuery, item) }))
        .filter((entry) => entry.score > 0)
        .sort((a, b) => b.score - a.score)
        .map((entry) => entry.item),
    }))
    .filter((group) => group.items.length > 0)
  const settingsResultCount = filteredGroups.reduce((count, group) => count + group.items.length, 0)
  const enabledNotificationCount = [settings.notifyMatches, settings.notifyMessages, settings.notifyRewards, settings.notifyMembership, settings.notifyProfileViews, settings.notifyMarketing]
    .filter(Boolean).length
  const activeTheme = THEME_PRESETS.find((preset) => preset.id === settings.themeId)?.name || "Custom appearance"
  const privacyHealth = getPrivacyHealth(settings as any)
  const overviewActions: Array<{ title: string; detail: string; icon: ReactNode; action: () => void }> = [
    { title: "Privacy & safety", detail: privacyHealth.label, icon: <Shield size={18} />, action: () => goToSection("privacy") },
    { title: "Notifications", detail: `${enabledNotificationCount} categories enabled`, icon: <Bell size={18} />, action: () => goToSection("notifications") },
    { title: "Appearance", detail: activeTheme, icon: <Palette size={18} />, action: () => goToSection("appearance") },
    { title: "Language & discovery", detail: selectedLocale, icon: <User size={18} />, action: () => goToSection("preferences") },
  ]

  return (
    <div className="gh-world-settings flex h-full min-h-0 flex-col bg-background" role="region" aria-label={msg("settingsTitle")}>
      <div className="flex shrink-0 items-center gap-3 border-b border-border/50 bg-card/95 p-4 backdrop-blur-md">
        <button
          type="button"
          onClick={onBack}
          className="flex h-11 w-11 items-center justify-center rounded-full hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
          aria-label="Back to profile"
        >
          <ChevronLeft size={24} strokeWidth={2} />
        </button>
        <h2 className="text-[18px] font-bold tracking-tight text-foreground">{msg("settingsTitle")}</h2>
      </div>

      <div className="shrink-0 border-b border-border/50 px-4 py-2.5">
        <div className="relative">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <input
            type="search"
            value={settingsQuery}
            onChange={(e) => setSettingsQuery(e.target.value)}
            placeholder={msg("searchSettings")}
            className="min-h-11 w-full rounded-2xl border border-border/70 bg-muted/40 py-2.5 pl-10 pr-11 text-[15px] outline-none transition focus:border-primary/40 focus:bg-card focus:ring-2 focus:ring-primary/20"
            aria-label={msg("searchSettings")}
            aria-describedby="settings-search-hint"
          />
          {settingsQuery ? (
            <button type="button" onClick={() => setSettingsQuery("")} className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary" aria-label="Clear settings search">
              <span aria-hidden="true">×</span>
            </button>
          ) : null}
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto pb-[var(--gh-screen-bottom-inset)]">
        <div className="space-y-5 px-4 py-4">
          {!settingsQuery.trim() ? (
            <section aria-labelledby="settings-overview-title" className="space-y-3">
              <div className="rounded-[1.5rem] border border-border/60 bg-gradient-to-br from-primary/10 via-card to-card p-4 shadow-[var(--gh-card-shadow)]">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-primary">Your control centre</p>
                    <h3 id="settings-overview-title" className="mt-1 text-[18px] font-bold tracking-tight">Make GreenHaven work your way</h3>
                    <p className="mt-1 max-w-[34rem] text-[12px] leading-relaxed text-muted-foreground">Manage account privacy, alerts, appearance and discovery preferences from one place. Sensitive account and payment decisions remain protected by their dedicated server checks.</p>
                  </div>
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-primary/10 text-primary"><Shield size={21} /></span>
                </div>
                <div className="mt-3 flex flex-wrap gap-2 text-[10px] font-semibold">
                  <span className="rounded-full border border-border/70 bg-background/80 px-2.5 py-1">Privacy: {privacyHealth.label}</span>
                  <span className="rounded-full border border-border/70 bg-background/80 px-2.5 py-1">{enabledNotificationCount}/6 alert categories</span>
                  <span className="rounded-full border border-border/70 bg-background/80 px-2.5 py-1">{selectedLocale}</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {overviewActions.map((item) => (
                  <button key={item.title} type="button" onClick={item.action} className="flex min-h-[76px] items-center gap-3 rounded-2xl border border-border/60 bg-card p-3 text-left transition hover:border-primary/40 hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary">
                    <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-muted text-foreground">{item.icon}</span>
                    <span className="min-w-0"><span className="block text-[12px] font-bold">{item.title}</span><span className="mt-0.5 block truncate text-[10px] text-muted-foreground">{item.detail}</span></span>
                    <ChevronRight size={15} className="ml-auto shrink-0 text-muted-foreground" />
                  </button>
                ))}
              </div>
            </section>
          ) : null}
          <p id="settings-search-hint" className="text-[11px] text-muted-foreground" aria-live="polite">
            {settingsQuery.trim() ? `${settingsResultCount} matching setting${settingsResultCount === 1 ? "" : "s"}` : "Find account controls by feature or task."}
          </p>
          {filteredGroups.length === 0 ? (
            <p className="px-2 text-[13px] text-muted-foreground">No settings match “{settingsQuery}”.</p>
          ) : (
            filteredGroups.map((group) => (
              <section key={group.heading} aria-labelledby={`settings-${group.heading}`}>
                <h3
                  id={`settings-${group.heading}`}
                  className="mb-2 px-1 text-[11px] font-bold uppercase tracking-wide text-muted-foreground"
                >
                  {group.heading}
                </h3>
                <div className="overflow-hidden rounded-[1.25rem] border border-border/60 bg-card shadow-[var(--gh-card-shadow)]">
                  {group.items.map((item, idx) => (
                    <button
                      key={item.title}
                      type="button"
                      onClick={item.action}
                      className={`flex min-h-12 w-full items-center gap-3 px-3.5 py-3 text-left transition hover:bg-muted/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-primary ${
                        idx > 0 ? "border-t border-border/50" : ""
                      }`}
                    >
                      <span className="gh-icon-tile flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl bg-muted text-foreground">
                        {item.icon}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-[15px] font-semibold text-foreground">{item.title}</span>
                        {item.subtitle ? (
                          <span className="mt-0.5 block text-[12px] text-muted-foreground">{item.subtitle}</span>
                        ) : null}
                      </span>
                      <ChevronRight size={20} strokeWidth={1.75} className="shrink-0 text-muted-foreground" />
                    </button>
                  ))}
                </div>
              </section>
            ))
          )}

          <section aria-labelledby="settings-danger">
            <h3 id="settings-danger" className="mb-2 px-1 text-[12px] font-bold uppercase tracking-wide text-muted-foreground">
              Session
            </h3>
            {!logoutConfirm ? (
              <button
                type="button"
                onClick={() => setLogoutConfirm(true)}
                className="flex min-h-12 w-full items-center justify-center gap-2 rounded-[1.25rem] border border-destructive/30 bg-destructive/10 px-4 py-3 text-[15px] font-bold text-destructive transition hover:bg-destructive/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-destructive"
              >
                <LogOut size={18} strokeWidth={2} />
                Log out
              </button>
            ) : (
              <div className="rounded-2xl border border-destructive/40 bg-card p-4">
                <p className="text-[15px] font-semibold text-foreground">Log out of GreenHaven?</p>
                <p className="mt-1 text-[12px] text-muted-foreground">You can sign back in anytime on this device.</p>
                <div className="mt-3 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setLogoutConfirm(false)}
                    className="min-h-11 flex-1 rounded-xl border border-border font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      await logout()
                      onBack()
                    }}
                    className="min-h-11 flex-1 rounded-xl bg-destructive font-bold text-destructive-foreground"
                  >
                    Log out
                  </button>
                </div>
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  )
}

export default SettingsScreen
