"use client"

import { DurableImage } from "./durable-image"
import { IdentityService } from "@/lib/identity/identity-service"

import { useState, useEffect } from "react"
import { ageFromBornDate, isAdultFromBornDate, maxBornDateForMinAge } from "@/lib/age-utils"
import { useGHC } from "@/contexts/ghc-context"
import { INTERESTS } from "@/lib/ghc-data"
import { compressForAvatar } from "@/lib/media/compress-image"
import { uploadDurableMedia } from "@/lib/media/upload-client"
import type { OnboardingStep, Gender, PrimaryMode } from "@/lib/ghc-types"

import {
  Heart,
  Users,
  Briefcase,
  Plus,
  X,
  Sparkles,
  Camera,
  MessageCircle,
  TrendingUp,
  Shield,
  Image as ImageIcon,
  Rocket,
  Check,
  ChevronLeft,
  Handshake,
  Building2,
  Globe2,
  GraduationCap,
} from "lucide-react"
import { BrandLogo } from "./brand-logo"
import { LazyImage } from "./lazy-image"
import { LocationPicker } from "./location-picker"
import {
  legacyCityCountry,
  parseLegacyLocation,
  type StructuredLocation,
} from "@/lib/geography"


/** Connection intents — local helpers (avoid path-alias runtime misses in App Studio) */
type ConnectionIntentId =
  | "friendship"
  | "dating"
  | "networking"
  | "business"
  | "collaboration"
  | "communities"
  | "mentorship"

const INTENT_IDS: ConnectionIntentId[] = [
  "friendship",
  "dating",
  "networking",
  "business",
  "collaboration",
  "communities",
  "mentorship",
]

function normalizeIntents(raw: unknown): ConnectionIntentId[] {
  if (!Array.isArray(raw)) return []
  const allowed = new Set<string>(INTENT_IDS)
  const out: ConnectionIntentId[] = []
  for (const x of raw) {
    const id = String(x).toLowerCase().trim() as ConnectionIntentId
    if (allowed.has(id) && !out.includes(id)) out.push(id)
  }
  return out
}

function saveConnectionIntents(userId: string, intents: ConnectionIntentId[]) {
  try {
    if (typeof localStorage === "undefined") return
    const key = "ghc_connection_intents_v1"
    const all = JSON.parse(localStorage.getItem(key) || "{}")
    all[userId] = normalizeIntents(intents)
    localStorage.setItem(key, JSON.stringify(all))
  } catch {
    /* ignore */
  }
}

const INTEREST_ICONS: Record<string, string> = {
  Reading: "📚",
  Gaming: "🎮",
  Cooking: "🍳",
  Photography: "📷",
  Fitness: "💪",
  Fashion: "👗",
  Food: "🍔",
  Music: "🎵",
  Travel: "✈️",
  Sports: "⚽",
  Tech: "💻",
  Finance: "💰",
  Healthcare: "🏥",
  Education: "🎓",
  Arts: "🎨",
  Entrepreneurship: "🚀",
  Wellness: "🧘",
  Nature: "🌿",
  Volunteering: "🤝",
  Pets: "🐾",
  Spirituality: "✨",
  Writing: "✍️",
}

/** Premium dark shell — deep green-black with soft emerald glow */
function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="gh-world-onboarding relative flex h-full min-h-0 flex-col overflow-hidden bg-[#050a08] text-white" role="region" aria-label="GreenHaven account setup">
      {/* Ambient glows */}
      <div className="pointer-events-none absolute -left-24 -top-28 h-72 w-72 rounded-full bg-emerald-500/15 blur-[100px]" />
      <div className="pointer-events-none absolute -right-20 top-40 h-64 w-64 rounded-full bg-teal-400/10 blur-[90px]" />
      <div className="pointer-events-none absolute bottom-10 left-1/2 h-48 w-48 -translate-x-1/2 rounded-full bg-emerald-600/10 blur-[80px]" />
      {/* Subtle grid / world texture hint */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "radial-gradient(circle at 50% 20%, rgba(16,185,129,0.35) 0%, transparent 55%), radial-gradient(circle at 80% 80%, rgba(52,211,153,0.2) 0%, transparent 40%)",
        }}
      />
      {children}
    </div>
  )
}

function BrandHeader({ showBack, onBack }: { showBack?: boolean; onBack?: () => void }) {
  return (
    <div className="relative z-10 flex items-center justify-between px-4 pb-1 pt-[max(0.65rem,env(safe-area-inset-top))]">
      <div className="flex items-center gap-2">
        {showBack && (
          <button
            type="button"
            onClick={onBack}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-white/5 text-emerald-300 ring-1 ring-white/10 transition hover:bg-white/10"
            aria-label="Back"
          >
            <ChevronLeft size={20} />
          </button>
        )}
        <BrandLogo onDark size="bar" className="object-left drop-shadow-[0_0_18px_rgba(16,185,129,0.35)]" />
      </div>
    </div>
  )
}

function StepDots({ current, total }: { current: number; total: number }) {
  return (
    <div className="flex items-center justify-center gap-1.5 py-2.5" aria-label={`Step ${current} of ${total}`}>
      {Array.from({ length: total }).map((_, i) => (
        <span
          key={i}
          className={`h-1.5 rounded-full transition-all duration-300 ${
            i + 1 === current
              ? "w-7 bg-gradient-to-r from-emerald-400 to-teal-400 shadow-[0_0_10px_rgba(52,211,153,0.55)]"
              : i + 1 < current
                ? "w-3 bg-emerald-500/70"
                : "w-1.5 bg-white/15"
          }`}
        />
      ))}
    </div>
  )
}

function PrimaryButton({
  children,
  onClick,
  disabled,
}: {
  children: React.ReactNode
  onClick: () => void
  disabled?: boolean
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="flex min-h-12 w-full items-center justify-center gap-2 rounded-2xl bg-[var(--gh-green)] px-6 text-[15px] font-bold text-white shadow-md shadow-emerald-700/25 transition hover:brightness-105 active:scale-[0.98] disabled:bg-muted disabled:text-muted-foreground disabled:shadow-none disabled:opacity-50"
    >
      {children}
    </button>
  )
}

function SecondaryButton({
  children,
  onClick,
  disabled,
}: {
  children: React.ReactNode
  onClick: () => void
  disabled?: boolean
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="flex min-h-12 flex-1 items-center justify-center rounded-2xl border border-white/10 bg-white/5 px-4 text-[15px] font-bold text-white/90 backdrop-blur transition hover:bg-white/10 active:scale-[0.98] disabled:opacity-40"
    >
      {children}
    </button>
  )
}

const fieldClass =
  "w-full rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3.5 text-[15px] text-white shadow-inner outline-none transition placeholder:text-white/35 focus:border-emerald-400/60 focus:ring-2 focus:ring-emerald-500/25"

export function Onboarding() {
  const { profile, updateProfile, completeOnboarding } = useGHC()
  const safeProfile = profile || ({} as typeof profile)
  const piUsername =
    IdentityService.getUsername() ||
    IdentityService.getIdentity().displayName ||
    ""
  const [phase, setPhase] = useState<"splash" | "welcome" | "flow">("splash")
  const [introPage, setIntroPage] = useState<number>(0)

  useEffect(() => {
    if (phase !== "splash") return
    const timer = window.setTimeout(() => setPhase("welcome"), 2200)
    return () => window.clearTimeout(timer)
  }, [phase])
  const [step, setStep] = useState<OnboardingStep>(1)
  const [formData, setFormData] = useState({
    firstName: (() => {
      const n = (safeProfile.displayName || "").trim()
      if (!n) return ""
      return n.split(/\s+/)[0] || ""
    })(),
    lastName: (() => {
      const n = (safeProfile.displayName || "").trim()
      if (!n) return ""
      const parts = n.split(/\s+/)
      return parts.length > 1 ? parts.slice(1).join(" ") : ""
    })(),
    displayName: safeProfile.displayName || piUsername || "",
    age: typeof safeProfile.age === "number" ? safeProfile.age : 0,
    bornDate: (safeProfile as any).bornDate || "",
    gender: safeProfile.gender && safeProfile.gender !== "prefer-not-to-say" ? safeProfile.gender : "",
    city: safeProfile.city || "",
    country: safeProfile.country || "",
    state: "",
    structuredLocation: (safeProfile.city || safeProfile.country
      ? parseLegacyLocation(safeProfile.city || "", safeProfile.country || "")
      : null) as StructuredLocation | null,
    bio: safeProfile.bio || "",
    primaryMode: safeProfile.primaryMode || "",
    connectionIntents: (() => { const n = normalizeIntents((safeProfile as { connectionIntents?: string[] }).connectionIntents); return n })(),
    interests: safeProfile.interests || [],
    photos: safeProfile.photos || [],
  })
  const [uploading, setUploading] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [finishing, setFinishing] = useState(false)

  const validateStep = () => {
    const nextErrors: Record<string, string> = {}
    const composedName = `${formData.firstName} ${formData.lastName}`.trim().replace(/\s+/g, " ")
    const cleanName = composedName || formData.displayName.trim().replace(/\s+/g, " ")
    const cleanCity = formData.city.trim().replace(/\s+/g, " ")
    const cleanCountry = formData.country.trim()
    const cleanState = formData.state.trim()
    const cleanBio = formData.bio.trim().replace(/\s+/g, " ")
    const looksLikeWords = (value: string) => /^[\p{L}][\p{L}\s'.-]*$/u.test(value)
    const hasMeaningfulText = (value: string, min: number) =>
      value.length >= min && new Set(value.toLowerCase().split(/\s+/)).size > 1 && !/(.)\1{4,}/u.test(value)

    if (step === 1) {
      const first = formData.firstName.trim().replace(/\s+/g, " ")
      const last = formData.lastName.trim().replace(/\s+/g, " ")
      if (first.length < 1 || first.length > 40 || !looksLikeWords(first))
        nextErrors.firstName = "Enter your first name (letters only)."
      if (last.length < 1 || last.length > 40 || !looksLikeWords(last))
        nextErrors.lastName = "Enter your surname / last name (letters only)."
      if (cleanName.length < 2 || cleanName.length > 60 || !looksLikeWords(cleanName))
        nextErrors.displayName = "First name and surname must form a valid full name."
      const derived = formData.bornDate ? ageFromBornDate(formData.bornDate) : null
      if (!formData.bornDate) nextErrors.age = "Enter your date of birth to continue."
      else if (derived === null || !isAdultFromBornDate(formData.bornDate)) nextErrors.age = "You must be at least 18 years old and enter a valid date."
      if (
        !formData.structuredLocation?.countryId ||
        !formData.structuredLocation?.admin1Id ||
        !(formData.structuredLocation?.localityName || formData.structuredLocation?.admin2Name || formData.city)
      ) {
        nextErrors.location = "Select your country, region, and city or town."
      } else if (
        formData.structuredLocation?.countryId === "ng" &&
        formData.structuredLocation?.admin1Id &&
        !formData.structuredLocation?.admin2Id &&
        !formData.structuredLocation?.admin2Name
      ) {
        nextErrors.location = "Select your Local Government Area (LGA), then your city or town."
      }
      if (!formData.gender || formData.gender === "prefer-not-to-say") {
        nextErrors.gender = "Please select your gender to continue."
      }
    }
    if (step === 2) {
      const intents = normalizeIntents(formData.connectionIntents)
      if (intents.length < 1) nextErrors.connectionIntents = "Choose at least one connection goal."
      if (!["friendship", "dating", "networking"].includes(formData.primaryMode)) nextErrors.primaryMode = "Choose a valid primary connection mode."
    }
    if (step === 3 && formData.interests.length < 3) nextErrors.interests = "Choose at least 3 interests."
    if (step === 4 && formData.photos.length < 1) nextErrors.photos = "Add a profile photo to continue."
    setErrors(nextErrors)
    return Object.keys(nextErrors).length === 0
  }

  const handleNext = async () => {
    if (!validateStep()) return
    if (step === 1) {
      const fullName = `${formData.firstName} ${formData.lastName}`.trim().replace(/\s+/g, " ")
      const saved = await updateProfile({
        displayName: fullName,
        age: formData.bornDate ? (ageFromBornDate(formData.bornDate) ?? formData.age) : formData.age,
        bornDate: formData.bornDate,
        gender: formData.gender as Gender,
        city: formData.city.trim().replace(/\s+/g, " "),
        country: formData.country.trim(),
        homeLocation: formData.structuredLocation || null,
        locationPrivacy: "locality",
        bio: formData.bio.trim().replace(/\s+/g, " "),
      })
      if (!saved) { setErrors((p) => ({ ...p, persistence: "We could not securely save these details. Check your connection and try again." })); return }
      setErrors((p) => ({ ...p, persistence: "" }))
      setStep(2)
    } else if (step === 2) {
      const saved = await updateProfile({
        primaryMode: formData.primaryMode as PrimaryMode,
        connectionIntents: normalizeIntents((formData as { connectionIntents?: string[] }).connectionIntents),
      } as Partial<import("@/lib/ghc-types").Profile>)
      if (!saved) { setErrors((p) => ({ ...p, persistence: "Your connection choices were not saved. Please retry." })); return }
      setErrors((p) => ({ ...p, persistence: "" }))
      try {
        saveConnectionIntents(IdentityService.getCurrentUserId(), normalizeIntents((formData as { connectionIntents?: string[] }).connectionIntents) as ConnectionIntentId[])
      } catch { /* */ }
      setStep(3)
    } else if (step === 3) {
      const saved = await updateProfile({ interests: formData.interests })
      if (!saved) { setErrors((p) => ({ ...p, persistence: "Your interests were not saved. Please retry." })); return }
      setErrors((p) => ({ ...p, persistence: "" }))
      setStep(4)
    } else if (step === 4) {
      const saved = await updateProfile({ photos: formData.photos })
      if (!saved) { setErrors((p) => ({ ...p, persistence: "Your profile photo was not saved. Please retry." })); return }
      setErrors((p) => ({ ...p, persistence: "" }))
      setStep(5)
    } else if (step === 5) {
      setFinishing(true)
      try {
        const saved = await updateProfile({
          photos: formData.photos,
          city: formData.city,
          country: formData.country,
          homeLocation: formData.structuredLocation || null,
          locationPrivacy: "locality",
          bio: formData.bio,
          interests: formData.interests,
          displayName: `${formData.firstName} ${formData.lastName}`.trim().replace(/\s+/g, " "),
          age: formData.bornDate ? (ageFromBornDate(formData.bornDate) ?? undefined) : undefined,
          gender: formData.gender as Gender,
          primaryMode: formData.primaryMode as PrimaryMode,
          connectionIntents: normalizeIntents(formData.connectionIntents),
        })
        if (!saved) { setErrors((p) => ({ ...p, persistence: "Your profile details could not be confirmed on the server. Nothing has been marked complete; please retry." })); return }
        setErrors((p) => ({ ...p, persistence: "" }))
        const completed = await completeOnboarding()
        if (!completed) setErrors((p) => ({ ...p, persistence: "Registration was not confirmed. Review any missing details and try again." }))
      } finally {
        setFinishing(false)
      }
    }
  }

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || formData.photos.length >= 6) return
    setUploading(true)
    try {
      const compressed = await compressForAvatar(file)
      const blob = await fetch(compressed).then((response) => response.blob())
      const uploaded = await uploadDurableMedia(blob, {
        fileName: `onboarding-avatar-${Date.now()}.${blob.type === "image/webp" ? "webp" : "jpg"}`,
        category: "avatars",
      })
      if (!uploaded.ok || uploaded.kind !== "image") {
        throw new Error(uploaded.ok ? "The uploaded file is not an image." : uploaded.userMessage || uploaded.error)
      }
      setFormData((p) => ({ ...p, photos: [...p.photos, uploaded.url] }))
      setErrors((p) => ({ ...p, photos: "", persistence: "" }))
    } catch (err) {
      console.error("[onboarding] Photo upload failed:", err)
      setErrors((p) => ({
        ...p,
        photos: err instanceof Error ? err.message : "Could not process photo. Try another image.",
      }))
    } finally {
      setUploading(false)
    }
  }

  const removePhoto = (index: number) => {
    setFormData((p) => ({ ...p, photos: p.photos.filter((_, i) => i !== index) }))
  }

  /* ───────────── SPLASH (3s) ───────────── */
  if (phase === "splash") {
    return (
      <div className="relative flex h-full flex-col items-center justify-center overflow-hidden bg-[#050a08] px-6">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(16,185,129,0.18)_0%,transparent_60%)]" />
        <div className="pointer-events-none absolute -left-16 top-24 h-56 w-56 rounded-full bg-emerald-500/20 blur-[90px]" />
        <div className="pointer-events-none absolute -right-12 bottom-32 h-48 w-48 rounded-full bg-teal-400/15 blur-[80px]" />
        <div className="relative z-10 flex flex-col items-center">
          <div className="relative">
            <div className="absolute inset-0 scale-110 rounded-full bg-emerald-400/20 blur-3xl" />
            <BrandLogo onDark size="hero" priority className="relative drop-shadow-[0_0_40px_rgba(16,185,129,0.45)]" />
          </div>
          <div
            className="mt-8 h-8 w-8 animate-spin rounded-full border-2 border-emerald-500/20 border-t-emerald-400"
            role="status"
            aria-label="Loading"
          />
        </div>
      </div>
    )
  }

  /* ───────────── WELCOME / ECOSYSTEM INTRO (4 screens) ───────────── */
  if (phase === "welcome") {
    const INTRO = [
      {
        n: "01",
        title: "Connect",
        desc: "Meet people around shared interests — friendship, networking, business, communities, or dating.",
        icon: Users,
      },
      {
        n: "02",
        title: "Communicate",
        desc: "Chat, share posts, and build communities. Conversations stay meaningful and intentional.",
        icon: MessageCircle,
      },
      {
        n: "03",
        title: "Earn",
        desc: "Build your GreenHaven profile through meaningful participation. Daily claims can earn GHC; mission milestones unlock achievements, not GHC.",
        icon: TrendingUp,
      },
      {
        n: "04",
        title: "Use",
        desc: "Use GHC across the GreenHaven ecosystem — membership, marketplace, boosts, and more.",
        icon: Sparkles,
      },
    ] as const
    const page = INTRO[Math.min(introPage, INTRO.length - 1)]
    const isLast = introPage >= INTRO.length - 1

    return (
      <Shell>
        <div className="pt-[max(0.75rem,env(safe-area-inset-top))]" aria-hidden />
        <div className="relative z-10 flex flex-1 flex-col overflow-y-auto px-6 pb-8 pt-4">
          <div className="mx-auto flex w-full max-w-md flex-1 flex-col">
            <div className="mb-4 flex items-center justify-between">
              <BrandLogo onDark size="bar" className="object-left opacity-90" />
              <button
                type="button"
                onClick={() => setPhase("flow")}
                className="text-[12px] font-semibold text-white/50 hover:text-white/80"
              >
                Skip
              </button>
            </div>

            {piUsername && introPage === 0 ? (
              <p className="mb-1 text-center text-[13px] font-medium text-emerald-300/90">
                Welcome, {piUsername}
              </p>
            ) : null}

            <div className="flex flex-1 flex-col items-center justify-center text-center">
              <p className="text-[11px] font-bold uppercase tracking-[0.28em] text-emerald-400/90">
                {page.n}
              </p>
              <div className="mt-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/25">
                <page.icon size={32} strokeWidth={1.75} />
              </div>
              <h1 className="mt-6 text-[1.75rem] font-black tracking-tight text-white">
                {page.title}
              </h1>
              <p className="mx-auto mt-3 max-w-[18rem] text-[14px] leading-relaxed text-white/55">
                {page.desc}
              </p>

              <div className="mt-8 flex items-center gap-2">
                {INTRO.map((_, i) => (
                  <button
                    key={i}
                    type="button"
                    aria-label={`Intro page ${i + 1}`}
                    onClick={() => setIntroPage(i)}
                    className={`h-1.5 rounded-full transition-all ${
                      i === introPage ? "w-6 bg-emerald-400" : "w-1.5 bg-white/25"
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="mt-auto space-y-3 pt-6">
              <PrimaryButton
                onClick={() => {
                  if (isLast) setPhase("flow")
                  else setIntroPage((p) => p + 1)
                }}
              >
                {isLast ? (
                  <>
                    Get Started <Rocket size={18} />
                  </>
                ) : (
                  "Continue"
                )}
              </PrimaryButton>
              {!isLast ? (
                <button
                  type="button"
                  onClick={() => setPhase("flow")}
                  className="w-full py-2 text-center text-[12px] font-semibold text-white/45"
                >
                  Skip intro
                </button>
              ) : (
                <p className="text-center text-[12px] text-white/40">
                  Already have an account?{" "}
                  <span className="font-semibold text-emerald-400">Sign in</span>
                </p>
              )}
            </div>
          </div>
        </div>
      </Shell>
    )
  }

  /* ───────────── FLOW STEPS ───────────── */
  /* ───────────── FLOW STEPS ───────────── */
  return (
    <Shell>
      <BrandHeader
        showBack={step > 1}
        onBack={() => setStep((s) => (s > 1 ? ((s - 1) as OnboardingStep) : 1))}
      />
      <StepDots current={step} total={5} />

      <div className="relative z-10 min-h-0 flex-1 overflow-y-auto px-5 pb-4">
        <div className="mx-auto w-full max-w-md">
          {/* STEP 1 — Profile */}
          {step === 1 && (
            <div className="space-y-5 animate-in fade-in duration-300">
              <div className="text-center">
                <h1 className="text-[1.45rem] font-black tracking-tight text-white">Let&apos;s set up your profile</h1>
                <p className="mt-1 text-[13px] text-white/50">Tell us a little about yourself</p>
              </div>

              {/* Live profile preview */}
              <div className="rounded-2xl border border-emerald-400/20 bg-gradient-to-br from-emerald-500/10 to-transparent p-3">
                <p className="mb-2 text-[10px] font-bold uppercase tracking-wider text-emerald-300/80">Preview</p>
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-full bg-white/10 text-sm font-bold text-white ring-2 ring-emerald-400/30">
                    {formData.photos[0] ? (
                      <DurableImage src={formData.photos[0]} alt="" className="h-full w-full object-cover" />
                    ) : (
                      (formData.displayName || "?").slice(0, 1).toUpperCase()
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold text-white">{formData.displayName || "Your name"}</p>
                    <p className="truncate text-[11px] text-white/50">
                      {[formData.city, formData.country].filter(Boolean).join(", ") || "Location"}
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-3.5 rounded-3xl border border-white/8 bg-white/[0.04] p-4 backdrop-blur-sm">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="mb-1.5 block text-[12px] font-bold text-white/60">First name *</label>
                    <input
                      type="text"
                      required
                      value={formData.firstName}
                      onChange={(e) => {
                        const firstName = e.target.value
                        setFormData((p) => ({
                          ...p,
                          firstName,
                          displayName: `${firstName} ${p.lastName}`.trim().replace(/\s+/g, " "),
                        }))
                      }}
                      placeholder="Given name"
                      maxLength={40}
                      autoComplete="given-name"
                      className={fieldClass}
                    />
                    {errors.firstName && <p className="mt-1 text-xs text-rose-400">{errors.firstName}</p>}
                  </div>
                  <div>
                    <label className="mb-1.5 block text-[12px] font-bold text-white/60">Surname *</label>
                    <input
                      type="text"
                      required
                      value={formData.lastName}
                      onChange={(e) => {
                        const lastName = e.target.value
                        setFormData((p) => ({
                          ...p,
                          lastName,
                          displayName: `${p.firstName} ${lastName}`.trim().replace(/\s+/g, " "),
                        }))
                      }}
                      placeholder="Family name"
                      maxLength={40}
                      autoComplete="family-name"
                      className={fieldClass}
                    />
                    {errors.lastName && <p className="mt-1 text-xs text-rose-400">{errors.lastName}</p>}
                  </div>
                </div>
                {errors.displayName && <p className="text-xs text-rose-400">{errors.displayName}</p>}

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="mb-1.5 block text-[12px] font-bold text-white/60">Date of birth *</label>
                    <input
                      type="date"
                      required
                      aria-required="true"
                      max={maxBornDateForMinAge(18)}
                      value={formData.bornDate}
                      onChange={(e) => {
                        const bornDate = e.target.value
                        const derived = ageFromBornDate(bornDate)
                        setFormData((p) => ({ ...p, bornDate, age: derived !== null ? derived : p.age }))
                        setErrors((p) => ({ ...p, age: "" }))
                      }}
                      className={`${fieldClass} [color-scheme:dark]`}
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-[12px] font-bold text-white/60">Gender</label>
                    <select
                      value={formData.gender}
                      required
                      aria-required="true"
                      onChange={(e) => {
                        const v = e.target.value as Gender
                        setFormData((p) => ({ ...p, gender: v }))
                        if (v) setErrors((p) => ({ ...p, gender: "" }))
                      }}
                      className={`${fieldClass} [color-scheme:dark]`}
                    >
                      <option value="" disabled>
                        Select gender
                      </option>
                      <option value="male">Male</option>
                      <option value="female">Female</option>
                      <option value="non-binary">Non-binary</option>
                    </select>
                    {errors.gender && <p className="mt-1 text-xs text-rose-400">{errors.gender}</p>}
                  </div>
                </div>
                {errors.age && <p className="text-xs text-rose-400">{errors.age}</p>}
                {formData.bornDate && (
                  <p className="text-[11px] text-white/40">
                    Age for discovery:{" "}
                    <strong className="text-emerald-300">{ageFromBornDate(formData.bornDate) ?? "—"}</strong> (private)
                  </p>
                )}

                <div>
                  <p className="mb-2 text-[12px] font-bold text-white/60">Location *</p>
                  <LocationPicker
                    variant="dark"
                    idPrefix="onboard"
                    value={formData.structuredLocation}
                    requireLocality
                    showPrivacy={false}
                    onChange={(loc) => {
                      const legacy = legacyCityCountry(loc)
                      setFormData((p) => ({
                        ...p,
                        structuredLocation: loc,
                        city: legacy.city,
                        country: legacy.country,
                        state: loc?.admin1Name || "",
                      }))
                      setErrors((p) => ({ ...p, location: "" }))
                    }}
                  />
                  {errors.location && <p className="mt-1.5 text-xs text-rose-400">{errors.location}</p>}
                </div>

                <div>
                  <label className="mb-1.5 block text-[12px] font-bold text-white/60">
                    Bio (optional) · {formData.bio.length}/500
                  </label>
                  <textarea
                    value={formData.bio}
                    onChange={(e) => {
                      setFormData((p) => ({ ...p, bio: e.target.value.slice(0, 500) }))
                      setErrors((p) => ({ ...p, bio: "" }))
                    }}
                    placeholder="Tell us about yourself…"
                    maxLength={500}
                    rows={3}
                    className={`${fieldClass} min-h-[88px] resize-none`}
                  />
                  {errors.bio && <p className="mt-1 text-xs text-rose-400">{errors.bio}</p>}
                </div>
              </div>

              <div className="flex items-start gap-2 rounded-2xl border border-emerald-500/15 bg-emerald-500/10 px-3.5 py-2.5 text-[11px] text-emerald-200/90">
                <Shield size={14} className="mt-0.5 shrink-0 text-emerald-400" />
                Your information helps us connect you with the right people and communities.
              </div>
            </div>
          )}

          {/* STEP 2 — Mode */}
          {step === 2 && (
            <div className="space-y-4 animate-in fade-in duration-300">
              <div className="text-center">
                <h1 className="text-[1.45rem] font-black tracking-tight text-white">What brings you here?</h1>
                <p className="mt-1 text-[13px] text-white/50">Select all that apply — change anytime in Profile</p>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {[
                  { value: "friendship", label: "Friendship", icon: Users, accent: "from-emerald-500 to-teal-500" },
                  { value: "dating", label: "Dating", icon: Heart, accent: "from-rose-500 to-pink-500" },
                  { value: "networking", label: "Networking", icon: Briefcase, accent: "from-sky-500 to-blue-600" },
                  { value: "business", label: "Business", icon: Building2, accent: "from-emerald-500 to-teal-600" },
                  { value: "collaboration", label: "Collaboration", icon: Handshake, accent: "from-amber-500 to-orange-600" },
                  { value: "communities", label: "Communities", icon: Globe2, accent: "from-cyan-500 to-blue-600" },
                  { value: "mentorship", label: "Mentorship", icon: GraduationCap, accent: "from-indigo-500 to-violet-600" },
                ].map((mode) => {
                  const selected = (normalizeIntents((formData as { connectionIntents?: string[] }).connectionIntents).includes(mode.value as ConnectionIntentId) || formData.primaryMode === mode.value)
                  return (
                    <button
                      key={mode.value}
                      type="button"
                      onClick={() =>
                        setFormData((p) => {
                          const id = mode.value as ConnectionIntentId
                          const cur = normalizeIntents((p as { connectionIntents?: string[] }).connectionIntents)
                          const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]
                          const intents = next.length ? next : [id]
                          const primary =
                            intents[0] === "dating"
                              ? "dating"
                              : intents[0] === "networking" || intents[0] === "business"
                                ? "networking"
                                : "friendship"
                          return { ...p, primaryMode: primary as PrimaryMode, connectionIntents: intents }
                        })
                      }
                      className={`relative flex min-h-[5.25rem] flex-col items-center justify-center gap-1.5 rounded-2xl border px-2 py-3 text-center transition active:scale-[0.98] ${
                        selected
                          ? "border-emerald-400/55 bg-emerald-500/12 shadow-[0_0_20px_rgba(16,185,129,0.18)]"
                          : "border-white/8 bg-white/[0.04] hover:border-white/15 hover:bg-white/[0.06]"
                      }`}
                    >
                      <span
                        className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${mode.accent} text-white shadow-md`}
                      >
                        <mode.icon size={20} />
                      </span>
                      <span className="text-[13px] font-bold leading-tight text-white">{mode.label}</span>
                      {selected ? (
                        <span className="absolute right-2 top-2 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500 text-white shadow-[0_0_10px_rgba(16,185,129,0.45)]">
                          <Check size={11} strokeWidth={3} />
                        </span>
                      ) : null}
                    </button>
                  )
                })}
              </div>
              {errors.connectionIntents && <p role="alert" className="text-center text-xs text-rose-400">{errors.connectionIntents}</p>}
              {errors.primaryMode && <p role="alert" className="text-center text-xs text-rose-400">{errors.primaryMode}</p>}
              <p className="text-center text-[11px] text-white/35">
                Multi-select is fine — Discover uses these to rank people for you.
              </p>
            </div>
          )}

          {/* STEP 3 — Interests */}
          {step === 3 && (
            <div className="space-y-5 animate-in fade-in duration-300">
              <div className="text-center">
                <h1 className="text-[1.45rem] font-black tracking-tight text-white">Choose your interests</h1>
                <p className="mt-1 text-[13px] text-white/50">
                  What makes you unique? Pick at least 3
                  {formData.interests.length > 0 && (
                    <span className="ml-1 font-bold text-emerald-400">· {formData.interests.length} selected</span>
                  )}
                </p>
              </div>
              {errors.interests && <p className="text-center text-xs text-rose-400">{errors.interests}</p>}

              {Object.entries(INTERESTS).map(([category, items]) => (
                <div key={category}>
                  <h3 className="mb-2 text-[11px] font-bold uppercase tracking-wider text-white/35">{category}</h3>
                  <div className="flex flex-wrap gap-2">
                    {items.map((interest) => {
                      const selected = formData.interests.includes(interest)
                      return (
                        <button
                          key={interest}
                          type="button"
                          onClick={() => {
                            setFormData((p) => {
                              const isSelected = p.interests.includes(interest)
                              return {
                                ...p,
                                interests: isSelected
                                  ? p.interests.filter((i) => i !== interest)
                                  : [...p.interests, interest],
                              }
                            })
                          }}
                          className={`inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[13px] font-bold transition ${
                            selected
                              ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-[0_4px_16px_rgba(16,185,129,0.35)]"
                              : "border border-white/10 bg-white/[0.05] text-white/80 hover:border-emerald-400/30"
                          }`}
                        >
                          <span className="text-sm">{INTEREST_ICONS[interest] || "✨"}</span>
                          {interest}
                        </button>
                      )
                    })}
                  </div>
                </div>
              ))}
              <div className="rounded-2xl border border-emerald-500/15 bg-emerald-500/10 px-3.5 py-2.5 text-center text-[11px] text-emerald-200/90">
                This helps us show relevant content, people and communities.
              </div>
            </div>
          )}

          {/* STEP 4 — Photos */}
          {step === 4 && (
            <div className="space-y-5 animate-in fade-in duration-300">
              <div className="text-center">
                <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/30">
                  <Camera size={26} />
                </div>
                <h1 className="text-[1.45rem] font-black tracking-tight text-white">Add photos</h1>
                <p className="mt-1 text-[13px] text-white/50">Add a profile photo. You can add up to 6 photos.</p>
                {errors.photos && <p className="mt-1 text-xs text-rose-400">{errors.photos}</p>}
              </div>

              <div className="grid grid-cols-2 gap-3">
                {formData.photos.map((photo, idx) => (
                  <div key={idx} className="relative aspect-[3/4] overflow-hidden rounded-2xl ring-1 ring-white/10">
                    <LazyImage src={photo} alt="Profile photo" className="h-full w-full object-cover" />
                    <button
                      type="button"
                      onClick={() => removePhoto(idx)}
                      className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-rose-500 text-white shadow"
                      aria-label="Remove photo"
                    >
                      <X size={14} />
                    </button>
                    {idx === 0 && (
                      <span className="absolute left-2 top-2 rounded-full bg-emerald-500 px-2 py-0.5 text-[10px] font-bold text-white">
                        Primary
                      </span>
                    )}
                  </div>
                ))}

                {formData.photos.length < 6 && (
                  <label className="flex aspect-[3/4] cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-emerald-400/35 bg-emerald-500/5 transition hover:bg-emerald-500/10">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-300">
                      <Plus size={24} />
                    </div>
                    <span className="text-[13px] font-bold text-emerald-300">{uploading ? "Uploading…" : "Add photo"}</span>
                    <input type="file" accept="image/*" onChange={handlePhotoUpload} disabled={uploading} className="hidden" />
                  </label>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2">
                {[
                  { icon: ImageIcon, label: "High quality" },
                  { icon: Shield, label: "Secure upload" },
                  { icon: Camera, label: "Up to 6 photos" },
                  { icon: Sparkles, label: "Easy to update" },
                ].map((f) => (
                  <div
                    key={f.label}
                    className="flex items-center gap-2 rounded-xl border border-white/8 bg-white/[0.04] px-3 py-2 text-[11px] font-semibold text-white/60"
                  >
                    <f.icon size={14} className="text-emerald-400" />
                    {f.label}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* STEP 5 — Ready */}
          {step === 5 && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <div className="text-center">
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/15 text-emerald-300 ring-2 ring-emerald-400/30 shadow-[0_0_30px_rgba(16,185,129,0.35)]">
                  <Check size={32} strokeWidth={2.5} />
                </div>
                <h1 className="text-[1.65rem] font-black tracking-tight text-white">Review your profile</h1>
                <p className="mx-auto mt-2 max-w-xs text-[14px] text-white/50">
                  Check your details below, then finish registration to enter GreenHaven.
                </p>
              </div>

              <div className="overflow-hidden rounded-3xl border border-white/10 bg-white/[0.05] shadow-[0_12px_40px_rgba(0,0,0,0.35)]">
                <div className="bg-gradient-to-r from-emerald-600/80 to-teal-600/80 px-4 py-3">
                  <p className="text-[11px] font-bold uppercase tracking-wider text-white/80">Profile preview</p>
                </div>
                <div className="flex items-center gap-4 p-4">
                  {formData.photos[0] ? (
                    <LazyImage
                      src={formData.photos[0]}
                      alt=""
                      className="h-16 w-16 rounded-2xl object-cover ring-2 ring-emerald-400/30"
                    />
                  ) : (
                    <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-500/15 text-emerald-400">
                      <Camera size={24} />
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[17px] font-black text-white">
                      {formData.displayName || "You"}
                      {formData.bornDate || formData.age
                        ? `, ${formData.bornDate ? ageFromBornDate(formData.bornDate) ?? formData.age : formData.age}`
                        : ""}
                    </p>
                    <p className="truncate text-[13px] text-white/50">
                      {[formData.city, formData.country].filter(Boolean).join(", ") || "Location"}
                    </p>
                    <div className="mt-1.5 flex flex-wrap gap-1">
                      {formData.interests.slice(0, 4).map((interest) => (
                        <span
                          key={interest}
                          className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold text-emerald-300"
                        >
                          {interest}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Footer nav */}
      <div className="relative z-10 border-t border-white/8 bg-[#050a08]/90 px-5 pb-[max(1rem,env(safe-area-inset-bottom))] pt-3 backdrop-blur-md">
        <div className="mx-auto flex w-full max-w-md gap-3">
          {step > 1 && step < 5 && (
            <SecondaryButton onClick={() => setStep((s) => (s - 1) as OnboardingStep)}>Back</SecondaryButton>
          )}
          {step === 1 && (
            <SecondaryButton onClick={() => setPhase("welcome")}>Back</SecondaryButton>
          )}
          <div className="flex-[1.4]">
            <PrimaryButton
              onClick={() => void handleNext()}
              disabled={
                finishing ||
                (step === 2 && (normalizeIntents(formData.connectionIntents).length < 1 || !["friendship", "dating", "networking"].includes(formData.primaryMode))) ||
                (step === 3 && formData.interests.length < 3) ||
                (step === 1 && (
                  !formData.gender ||
                  !formData.displayName.trim() ||
                  !(formData.structuredLocation?.countryId && formData.structuredLocation?.admin1Id)
                )) ||
                (step === 4 && formData.photos.length < 1)
              }
            >
              {step === 5 ? (finishing ? "Starting…" : "Enter GreenHaven →") : "Next →"}
            </PrimaryButton>
          </div>
        </div>
      </div>
    </Shell>
  )
}
