/**
 * MessagingDomain — single canonical messaging system.
 *
 * Conversation types:
 *   DIRECT | PRIVATE_GROUP | COMMUNITY
 *
 * Message states:
 *   sending → sent → delivered → read | failed | deleted
 *
 * Consolidates pure helpers from unified-messaging-engine + message-state-manager.
 * Does NOT create a second messaging engine.
 *
 * Permissions: block, privacy (whoCanMessage), membership, community role chat.
 *
 * Monetization: optional tools in messaging-premium.ts only.
 * Basic sendMessage is never blocked by payment or GHC balance.
 */



import { runMutation, type MutationResult } from "./mutation-pipeline"
import { MESSAGING_FREE_GUARANTEE } from "./messaging-premium"
import { softDeleteMessage } from "../social-graph"
import type { DomainMessage } from "./types"
import type { MessageRepository } from "./repositories"
import type { Conversation, Message } from "../ghc-types"
import {
  handleMessageEdit,
  handleMessageDeletion,
  prepareMessageForSending,
  toggleConversationPin,
  toggleConversationArchive,
  toggleConversationMute,
  isValidMessage,
  searchMessages,
  handleMessageReaction,
} from "../unified-messaging-engine"
import {
  isDurableMessagingEnabled,
  shouldAttemptDurableMessaging,
} from "../messaging/durable-flag"
import { apiSendMessageWithRetry } from "../messaging/server-messaging-sync"
import type { PermissionContext } from "../permission-engine"
import { canCommunityAction, normalizeRole } from "./community-domain"

/** Canonical product conversation types */
export type MessagingConversationType = "DIRECT" | "PRIVATE_GROUP" | "COMMUNITY"

/** Legacy ConversationKind alias used by earlier domain API */
export type ConversationKind = "private" | "group" | "community"

export type MessageStatus =
  | "sending"
  | "sent"
  | "delivered"
  | "read"
  | "failed"
  | "deleted"

export const MESSAGE_STATUSES: MessageStatus[] = [
  "sending",
  "sent",
  "delivered",
  "read",
  "failed",
  "deleted",
]

/** Valid status transitions (failed/deleted are terminal-ish) */
const STATUS_TRANSITIONS: Record<MessageStatus, MessageStatus[]> = {
  sending: ["sent", "failed", "deleted"],
  sent: ["delivered", "read", "failed", "deleted"],
  delivered: ["read", "failed", "deleted"],
  read: ["deleted"],
  failed: ["sending", "deleted"], // retry → sending
  deleted: [],
}

export function canTransitionMessageStatus(
  from: MessageStatus,
  to: MessageStatus
): boolean {
  if (from === to) return true
  return STATUS_TRANSITIONS[from]?.includes(to) ?? false
}

export function resolveMessageStatus(message: Message): MessageStatus {
  if (message.isDeleted || message.isDeletedForEveryone || message.status === "deleted") {
    return "deleted"
  }
  const s = message.status
  if (
    s === "sending" ||
    s === "sent" ||
    s === "delivered" ||
    s === "read" ||
    s === "failed" ||
    s === "deleted"
  ) {
    return s
  }
  return "sent"
}

export function createMessagingDomain(deps: {
  currentUserId?: string
  isBlocked: (userId: string) => boolean
  getConversationParticipant?: (conversationId: string) => string | null
  getConversation?: (conversationId: string) => Conversation | undefined
  repository?: MessageRepository
  upsertConversation?: (conversation: Conversation) => void
  patchConversation?: (conversationId: string, patch: Partial<Conversation>) => void
  /** Privacy / graph context for permission checks */
  getPermissionContext?: () => PermissionContext
  isMember?: (conversationId: string, userId: string) => boolean
}) {
  const actorId = deps.currentUserId || "current-user"

  function kindOf(c: Conversation | undefined): ConversationKind {
    if (!c) return "private"
    const anyC = c as any
    const explicitCommunity =
      anyC.kind === "community" ||
      anyC.isCommunity === true ||
      Boolean(anyC.communityId) ||
      String(c.id || "").startsWith("comm_") ||
      String(c.id || "").startsWith("community")
    if (c.conversationType === "group" || explicitCommunity) {
      if (explicitCommunity) return "community"
      // Product communities are often stored as conversationType=group with a name
      if (anyC.groupName || anyC.category || anyC.boardPosts) return "community"
      return "group"
    }
    return "private"
  }

  function messagingTypeOf(c: Conversation | undefined): MessagingConversationType {
    const k = kindOf(c)
    if (k === "community") return "COMMUNITY"
    if (k === "group") return "PRIVATE_GROUP"
    return "DIRECT"
  }

  /**
   * Full pre-send gate: block, privacy, membership, community chat permission.
   * UI must not invent parallel rules — call this or sendMessage (which uses it).
   */
  function evaluateSendPermission(input: {
    conversationId: string
    recipientId?: string
  }): { allowed: true } | { allowed: false; reason: string } {
    const conv = deps.getConversation?.(input.conversationId)
    if (!conv) return { allowed: false, reason: "Conversation not found" }

    const type = messagingTypeOf(conv)

    if (type === "DIRECT") {
      const other =
        input.recipientId ||
        deps.getConversationParticipant?.(input.conversationId) ||
        conv.participantId ||
        null
      if (!other) return { allowed: false, reason: "Missing recipient" }
      if (deps.isBlocked(other)) return { allowed: false, reason: "You can't message this user" }

      // `who can message you` is the recipient's preference, not the sender's.
      // The durable server re-checks the recipient's saved preference on every send.
      return { allowed: true }
    }

    // PRIVATE_GROUP / COMMUNITY — prefer local membership when known.
    // When the members list is empty/unknown (common after create before hydrate),
    // allow the send through so the durable server can auto-heal membership.
    const members: string[] = Array.isArray((conv as any).members) ? (conv as any).members : []
    const rolesMap = (conv as any).groupRoles || {}
    const listedAsMember =
      members.includes(actorId) ||
      conv.createdBy === actorId ||
      Boolean(rolesMap[actorId]) ||
      Boolean(deps.isMember?.(input.conversationId, actorId))
    const membershipUnknown = members.length === 0 && !conv.createdBy && !rolesMap[actorId]

    // Groups & communities: never hard-block solely on incomplete client member lists.
    // Durable messaging API is authoritative and auto-heals membership on send.
    if (type === "PRIVATE_GROUP" || type === "COMMUNITY") {
      if (!listedAsMember && !membershipUnknown && conv.createdBy && conv.createdBy !== actorId) {
        // Positive non-membership only when we have a non-empty members list that excludes actor
        if (members.length > 0 && !members.includes(actorId) && !rolesMap[actorId]) {
          // Still allow community chats through — server will FORBIDDEN if truly not a member
          if (type === "PRIVATE_GROUP") {
            return { allowed: false, reason: "You are not a member of this group" }
          }
        }
      }
    }
    const isMember =
      listedAsMember ||
      membershipUnknown ||
      type === "COMMUNITY" ||
      conv.createdBy === actorId ||
      members.length === 0

    if (type === "COMMUNITY") {
      const role = normalizeRole(
        rolesMap[actorId] ||
          (conv.createdBy === actorId ? "owner" : isMember ? "member" : "member")
      )
      if (!canCommunityAction(role, "chat")) {
        // Default members can chat — only block explicit restricted roles
        if (role !== "member" && role !== "owner" && role !== "admin" && role !== "moderator") {
          return { allowed: false, reason: "Community chat not permitted for your role" }
        }
      }
    }

    return { allowed: true }
  }

  return {
    conversationKind(conversationId: string): ConversationKind {
      return kindOf(deps.getConversation?.(conversationId))
    },

    conversationType(conversationId: string): MessagingConversationType {
      return messagingTypeOf(deps.getConversation?.(conversationId))
    },

    evaluateSendPermission,
    /** Constant: chat is free */
    freeMessagingGuarantee: MESSAGING_FREE_GUARANTEE as string,
    resolveMessageStatus,
    canTransitionMessageStatus,

    async sendMessage(input: {
      conversationId: string
      text: string
      recipientId?: string
      replyToId?: string
      sharedPostId?: string
      /** Offline path starts as sending */
      offline?: boolean
    }): Promise<MutationResult<DomainMessage & { uiMessage?: Message }>> {
      return runMutation({
        name: "messaging.send",
        actorId,
        input,
        validate: (i) => {
          if (!i.conversationId) return "Missing conversation"
          if (!(i.text || "").trim()) return "Message cannot be empty"
          if (i.text.length > 4000) return "Message is too long"
          if (!isValidMessage(i.text) && i.text.trim().length === 0) return "Message cannot be empty"
          return null
        },
        authorize: (i) => {
          const gate = evaluateSendPermission({
            conversationId: i.conversationId,
            recipientId: i.recipientId,
          })
          return gate.allowed ? null : gate.reason
        },
        mutate: async (i) => {
          // Offline: local "sending" only — offline-message-flush will retry.
          // Online: server-first — no permanent "sent" without durable API ok.
          const online = shouldAttemptDurableMessaging(i.offline)
          const clientId = `msg_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`

          if (online) {
            const res = await apiSendMessageWithRetry(
              i.conversationId,
              i.text.trim(),
              clientId,
              i.replyToId,
              i.sharedPostId
            )
            const ok = Boolean(res && ((res as { ok?: boolean }).ok || (res as { httpOk?: boolean }).httpOk))
            const durable = (res as { durable?: boolean }).durable
            // Accept explicit durable true, or ok without durable:false (legacy API)
            const accepted = ok && durable !== false
            if (!accepted) {
              const err =
                (res as { error?: string })?.error ||
                (res as { message?: string })?.message ||
                "MESSAGE_NOT_DURABLE"
              throw new Error(err)
            }
            const serverId = String(
              (res as { message?: { id?: string } }).message?.id ||
                (res as { id?: string }).id ||
                clientId
            )
            const uiMessage: Message = {
              id: serverId,
              senderId: actorId,
              text: i.text.trim(),
              createdAt: Date.now(),
              status: "sent",
              replyTo: i.replyToId,
              sharedPostId: i.sharedPostId,
            }
            const msg: DomainMessage & { uiMessage?: Message } = {
              id: uiMessage.id,
              conversationId: i.conversationId,
              senderId: actorId,
              text: uiMessage.text,
              replyToId: i.replyToId,
              createdAt: uiMessage.createdAt || Date.now(),
              status: "sent",
              uiMessage,
            }
            if (deps.repository) {
              deps.repository.append(i.conversationId, uiMessage)
            }
            return msg
          }

          // Offline path — queue later via offline-message-flush
          const prepared =
            prepareMessageForSending(i.text.trim(), actorId, i.conversationId) ||
            ({
              id: clientId,
              senderId: actorId,
              text: i.text.trim(),
              createdAt: Date.now(),
              status: "sending" as MessageStatus,
            } as Message)

          const uiMessage: Message = {
            ...prepared,
            status: "sending",
            replyTo: i.replyToId || prepared.replyTo,
            sharedPostId: i.sharedPostId || prepared.sharedPostId,
          }

          const msg: DomainMessage & { uiMessage?: Message } = {
            id: uiMessage.id,
            conversationId: i.conversationId,
            senderId: actorId,
            text: uiMessage.text,
            replyToId: i.replyToId,
            createdAt: uiMessage.createdAt || Date.now(),
            status: "sending",
            uiMessage,
          }

          if (deps.repository) {
            deps.repository.append(i.conversationId, uiMessage)
          }

          return msg
        },
        eventType: "MESSAGE_CREATED",
        eventPayload: (m) => ({
          conversationId: m.conversationId,
          messageId: m.id,
          status: m.status,
        }),
      })
    },

    /** Advance delivery state (sent → delivered → read) or mark failed / retry */
    async setMessageStatus(
      conversationId: string,
      messageId: string,
      next: MessageStatus,
      meta?: { failureReason?: string }
    ): Promise<MutationResult<{ message: Message }>> {
      return runMutation({
        name: "messaging.setStatus",
        actorId,
        input: { conversationId, messageId, next, meta },
        authorize: (i) => {
          const conv = deps.getConversation?.(i.conversationId)
          const message = conv?.messages?.find((m) => m.id === i.messageId)
          if (!message) return "Message not found"
          const current = resolveMessageStatus(message)
          if (!canTransitionMessageStatus(current, i.next)) {
            return `Cannot transition from ${current} to ${i.next}`
          }
          return null
        },
        mutate: (i) => {
          const conv = deps.getConversation?.(i.conversationId)
          const message = conv?.messages?.find((m) => m.id === i.messageId)!
          const patch: Message = {
            ...message,
            status: i.next,
            ...(i.next === "read"
              ? {
                  readAt: Date.now(),
                  readBy: Array.from(new Set([...(message.readBy || []), actorId])),
                }
              : {}),
            ...(i.next === "failed"
              ? {
                  failedAt: Date.now(),
                  failureReason: i.meta?.failureReason || "Network error",
                }
              : {}),
            ...(i.next === "deleted"
              ? { isDeleted: true, deletedAt: Date.now() }
              : {}),
            ...(i.next === "sending" ? { failedAt: undefined, failureReason: undefined } : {}),
          }
          if (deps.repository) {
            deps.repository.update(i.conversationId, i.messageId, patch)
          }
          return { message: patch }
        },
        eventType: "MESSAGE_UPDATED",
        eventPayload: (d, i) => ({
          conversationId: i.conversationId,
          messageId: d.message.id,
          status: i.next,
        }),
      })
    },

    async editMessage(input: {
      conversationId: string
      messageId: string
      newText: string
    }): Promise<MutationResult<{ message: Message }>> {
      return runMutation({
        name: "messaging.edit",
        actorId,
        input,
        validate: (i) => {
          if (!(i.newText || "").trim()) return "Message cannot be empty"
          return null
        },
        authorize: (i) => {
          const gate = evaluateSendPermission({ conversationId: i.conversationId })
          return gate.allowed ? null : gate.reason
        },
        mutate: async (i) => {
          const conv = deps.getConversation?.(i.conversationId)
          const message = conv?.messages?.find((m) => m.id === i.messageId)
          if (!message) throw new Error("Message not found")
          if (resolveMessageStatus(message) === "deleted") throw new Error("Message deleted")
          // Durable path: PATCH /api/messaging/conversations/:id/messages
          if (isDurableMessagingEnabled()) {
            try {
              const { IdentityService } = await import("@/lib/identity/identity-service")
              const res = await fetch(
                `/api/messaging/conversations/${encodeURIComponent(i.conversationId)}/messages`,
                {
                  method: "PATCH",
                  headers: {
                    "Content-Type": "application/json",
                    ...IdentityService.getAuthHeaders(),
                  },
                  body: JSON.stringify({ messageId: i.messageId, body: i.newText.trim() }),
                }
              )
              const data = (await res.json().catch(() => ({}))) as {
                ok?: boolean
                error?: string
                message?: Message
                durable?: boolean
              }
              if (!res.ok || data.ok === false) {
                throw new Error(data.error || "Could not edit message on server")
              }
              if (data.message) {
                if (deps.repository) {
                  deps.repository.update(i.conversationId, i.messageId, data.message)
                }
                return { message: data.message }
              }
            } catch (e) {
              throw e instanceof Error ? e : new Error("Could not edit message")
            }
          }
          const edited = handleMessageEdit(message, i.newText.trim(), actorId)
          if (!edited) throw new Error("Cannot edit this message")
          if (deps.repository) {
            deps.repository.update(i.conversationId, i.messageId, edited)
          }
          return { message: edited }
        },
        eventType: "MESSAGE_UPDATED",
        eventPayload: (d, i) => ({
          conversationId: i.conversationId,
          messageId: d.message.id,
        }),
      })
    },

    async deleteMessage(
      message: { id: string; senderId: string; createdAt: number; conversationId: string },
      mode: "for_me" | "for_everyone"
    ): Promise<MutationResult<{ messageId: string; mode: string; message?: Message }>> {
      return runMutation({
        name: "messaging.delete",
        actorId,
        input: { message, mode },
        authorize: (i) => {
          if (i.mode === "for_everyone") {
            if (i.message.senderId !== actorId) {
              return "You can only delete your own messages for everyone"
            }
            if (Date.now() - i.message.createdAt > 60 * 60 * 1000) {
              return "Delete-for-everyone window has expired"
            }
          }
          return null
        },
        mutate: (i) => {
          const conv = deps.getConversation?.(i.message.conversationId)
          const full = conv?.messages?.find((m) => m.id === i.message.id) || (i.message as any)
          const engineDeleted = handleMessageDeletion(full, actorId, i.mode === "for_everyone")
          const next = {
            ...(engineDeleted ||
              softDeleteMessage(full as any, actorId, i.mode === "for_everyone" ? "everyone" : "me")),
            status: "deleted" as MessageStatus,
            deletedAt: Date.now(),
          }
          if (deps.repository) {
            deps.repository.update(i.message.conversationId, i.message.id, next as any)
          }
          return { messageId: i.message.id, mode: i.mode, message: next as Message }
        },
        eventType: "MESSAGE_DELETED",
        eventPayload: (d, i) => ({
          conversationId: i.message.conversationId,
          messageId: d.messageId,
          mode: d.mode,
        }),
      })
    },

    async react(
      conversationId: string,
      messageId: string,
      emoji: string
    ): Promise<MutationResult<{ message: Message }>> {
      return runMutation({
        name: "messaging.react",
        actorId,
        input: { conversationId, messageId, emoji },
        validate: (i) => (!(i.emoji || "").trim() ? "Missing reaction" : null),
        authorize: (i) => {
          const gate = evaluateSendPermission({ conversationId: i.conversationId })
          return gate.allowed ? null : gate.reason
        },
        mutate: (i) => {
          const conv = deps.getConversation?.(i.conversationId)
          const message = conv?.messages?.find((m) => m.id === i.messageId)
          if (!message) throw new Error("Message not found")
          const next = handleMessageReaction(message, i.emoji.trim(), actorId, true)
          if (deps.repository) {
            deps.repository.update(i.conversationId, i.messageId, next)
          }
          return { message: next }
        },
      })
    },

    search(conversationId: string, query: string): Message[] {
      const conv = deps.getConversation?.(conversationId)
      if (!conv?.messages) return []
      return searchMessages(conv.messages, { query })
    },

    async createConversation(input: {
      kind: ConversationKind
      participantId?: string
      participantName?: string
      participantPhoto?: string
      name?: string
      memberIds?: string[]
      communityId?: string
    }): Promise<MutationResult<{ conversation: Conversation }>> {
      return runMutation({
        name: "messaging.createConversation",
        actorId,
        input,
        validate: (i) => {
          if (i.kind === "private" && !i.participantId) return "Missing participant"
          if (i.kind === "private" && i.participantId && deps.isBlocked(i.participantId)) {
            return "Cannot start chat with blocked user"
          }
          if ((i.kind === "group" || i.kind === "community") && !(i.name || "").trim()) {
            return "Group name required"
          }
          return null
        },
        mutate: async (i) => {
          const now = Date.now()
          let id = `conv_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`

          // Private DMs: server-first durable conversation id (no local-only id when online).
          if (i.kind === "private" && i.participantId) {
            try {
              const { apiCreateDirectConversation } = await import(
                "@/lib/messaging/server-messaging-sync"
              )
              const res = await apiCreateDirectConversation(i.participantId)
              if (res.httpOk && res.ok && res.conversation?.id) {
                id = String(res.conversation.id)
              } else if (res.error === "PRIVACY_SETTINGS_UNCONFIGURED") {
                throw new Error("Cannot start chat: this user needs to open GreenHaven once to sync their privacy settings")
              } else if (res.error === "BLOCKED" || res.error === "PRIVACY_RESTRICTED" || res.status === 403) {
                throw new Error("Cannot start chat: this user’s messaging privacy settings do not allow it")
              } else if (shouldAttemptDurableMessaging(false)) {
                // Online but server did not confirm — do not invent a local-only conversation
                throw new Error(
                  res.error
                    ? `Cannot start chat: ${res.error}`
                    : "Cannot start chat: a secure conversation could not be created. Please retry when the connection recovers."
                )
              }
            } catch (e) {
              if (e instanceof Error && e.message.startsWith("Cannot start chat:")) throw e
              if (shouldAttemptDurableMessaging(false)) {
                throw e instanceof Error
                  ? e
                  : new Error("Cannot start chat: connection error")
              }
            }
          }

          const conversation: Conversation = {
            id,
            conversationType: i.kind === "private" ? "private" : "group",
            participantId: i.participantId || "",
            participantName: i.participantName || i.name || "Chat",
            participantPhoto: i.participantPhoto || "/placeholder.svg?width=40&height=40",
            lastMessage: "",
            lastMessageTime: now,
            unread: false,
            unreadCount: 0,
            messages: [],
            ...(i.kind !== "private"
              ? {
                  name: i.name,
                  memberIds: Array.from(new Set([actorId, ...(i.memberIds || [])])),
                  members: Array.from(new Set([actorId, ...(i.memberIds || [])])),
                  roles: { [actorId]: "admin" as const },
                  groupRoles: { [actorId]: i.kind === "community" ? "owner" : "admin" },
                }
              : {}),
            ...(i.kind === "community" || i.communityId
              ? ({ communityId: i.communityId || id, kind: "community" } as any)
              : {}),
          } as Conversation

          deps.upsertConversation?.(conversation)
          return { conversation }
        },
        eventType: "CONVERSATION_CREATED",
        eventPayload: (d) => ({
          conversationId: d.conversation.id,
          kind: input.kind,
        }),
      })
    },

    async markRead(conversationId: string): Promise<MutationResult<{ conversationId: string; readMessageIds: string[] }>> {
      return runMutation({
        name: "messaging.markRead",
        actorId,
        input: { conversationId },
        mutate: (i) => {
          const conv = deps.getConversation?.(i.conversationId)
          const readMessageIds: string[] = []
          const now = Date.now()
          // Peer read receipts: messages sent by others become "read" for this actor
          if (conv?.messages?.length && deps.repository) {
            for (const message of conv.messages) {
              const fromPeer =
                message.senderId &&
                message.senderId !== actorId &&
                message.senderId !== "current-user"
              if (!fromPeer) continue
              const current = resolveMessageStatus(message)
              if (current === "sent" || current === "delivered") {
                if (canTransitionMessageStatus(current, "read")) {
                  const patch: Message = {
                    ...message,
                    status: "read",
                    readAt: now,
                    readBy: Array.from(new Set([...(message.readBy || []), actorId])),
                  }
                  deps.repository.update(i.conversationId, message.id, patch)
                  readMessageIds.push(message.id)
                }
              }
            }
          }
          deps.patchConversation?.(i.conversationId, { unread: false, unreadCount: 0 })
          if (shouldAttemptDurableMessaging(false)) {
            void import("../messaging/server-messaging-sync")
              .then((m) => m.apiMarkConversationRead(i.conversationId))
              .catch(() => {})
          }
          return { conversationId: i.conversationId, readMessageIds }
        },
        eventType: "MESSAGE_READ",
        eventPayload: (d) => ({
          conversationId: d.conversationId,
          readMessageIds: d.readMessageIds,
          readerId: actorId,
        }),
      })
    },

    async setPinned(
      conversationId: string,
      pinned: boolean
    ): Promise<MutationResult<{ conversationId: string; isPinned: boolean }>> {
      return runMutation({
        name: "messaging.setPinned",
        actorId,
        input: { conversationId, pinned },
        mutate: async (i) => {
          const conv = deps.getConversation?.(i.conversationId)
          if (!conv) throw new Error("Conversation not found")
          toggleConversationPin(conv)
          deps.patchConversation?.(i.conversationId, { isPinned: i.pinned } as any)
          if (shouldAttemptDurableMessaging(false)) {
            try {
              const { IdentityService } = await import("@/lib/identity/identity-service")
              await fetch(
                `/api/messaging/conversations/${encodeURIComponent(i.conversationId)}/prefs`,
                {
                  method: "PATCH",
                  headers: {
                    "Content-Type": "application/json",
                    ...IdentityService.getAuthHeaders(),
                  },
                  body: JSON.stringify({ isPinned: i.pinned }),
                }
              )
            } catch {
              /* local prefs already applied */
            }
          }
          return { conversationId: i.conversationId, isPinned: i.pinned }
        },
      })
    },

    async setArchived(
      conversationId: string,
      archived: boolean
    ): Promise<MutationResult<{ conversationId: string; isArchived: boolean }>> {
      return runMutation({
        name: "messaging.setArchived",
        actorId,
        input: { conversationId, archived },
        mutate: async (i) => {
          const conv = deps.getConversation?.(i.conversationId)
          if (!conv) throw new Error("Conversation not found")
          toggleConversationArchive(conv)
          deps.patchConversation?.(i.conversationId, { isArchived: i.archived } as any)
          if (shouldAttemptDurableMessaging(false)) {
            try {
              const { IdentityService } = await import("@/lib/identity/identity-service")
              await fetch(
                `/api/messaging/conversations/${encodeURIComponent(i.conversationId)}/prefs`,
                {
                  method: "PATCH",
                  headers: {
                    "Content-Type": "application/json",
                    ...IdentityService.getAuthHeaders(),
                  },
                  body: JSON.stringify({ isArchived: i.archived }),
                }
              )
            } catch {
              /* local prefs already applied */
            }
          }
          return { conversationId: i.conversationId, isArchived: i.archived }
        },
      })
    },

    async setMuted(
      conversationId: string,
      muted: boolean,
      muteHours?: number
    ): Promise<MutationResult<{ conversationId: string; isMuted: boolean }>> {
      return runMutation({
        name: "messaging.setMuted",
        actorId,
        input: { conversationId, muted, muteHours },
        mutate: async (i) => {
          const conv = deps.getConversation?.(i.conversationId)
          if (!conv) throw new Error("Conversation not found")
          toggleConversationMute(conv, i.muteHours)
          deps.patchConversation?.(i.conversationId, { isMuted: i.muted } as any)
          if (shouldAttemptDurableMessaging(false)) {
            try {
              const { IdentityService } = await import("@/lib/identity/identity-service")
              const mutedUntil = i.muted
                ? Date.now() + (Number(i.muteHours) || 24) * 60 * 60 * 1000
                : null
              await fetch(
                `/api/messaging/conversations/${encodeURIComponent(i.conversationId)}/prefs`,
                {
                  method: "PATCH",
                  headers: {
                    "Content-Type": "application/json",
                    ...IdentityService.getAuthHeaders(),
                  },
                  body: JSON.stringify({ mutedUntil }),
                }
              )
            } catch {
              /* local prefs already applied */
            }
          }
          return { conversationId: i.conversationId, isMuted: i.muted }
        },
      })
    },
  }
}

export type MessagingDomain = ReturnType<typeof createMessagingDomain>
