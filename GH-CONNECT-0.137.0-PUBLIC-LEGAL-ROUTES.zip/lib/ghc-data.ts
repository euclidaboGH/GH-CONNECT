import { isDemoDataAllowed } from "@/lib/demo-data-policy"
import type { Profile, Settings, Candidate, Post, StoryItem } from "./ghc-types"

// Storage keys
export const STORAGE_KEYS = {
  profile: "ghc.profile",
  settings: "ghc.settings",
  posts: "ghc.posts",
  matches: "ghc.matches",
  likes: "ghc.likes",
  conversations: "ghc.conversations",
  friendRequests: "ghc.friend-requests",
  stories: "ghc.stories",
  /** Social graph — survive refresh within Studio / Pi storage */
  following: "ghc.following",
  friends: "ghc.friends",
  blockedUsers: "ghc.blocked-users",
  mutedUsers: "ghc.muted-users",
}

// Interests
export const INTERESTS = {
  hobbies: ["Music", "Sports", "Travel", "Reading", "Gaming", "Cooking", "Photography", "Fitness", "Fashion", "Food"],
  professional: ["Tech", "Finance", "Healthcare", "Education", "Arts", "Entrepreneurship"],
  lifestyle: ["Wellness", "Nature", "Volunteering", "Pets", "Spirituality", "Writing"],
}

export const ALL_INTERESTS = [...INTERESTS.hobbies, ...INTERESTS.professional, ...INTERESTS.lifestyle]

export function seedStories(): StoryItem[] {
  if (!isDemoDataAllowed()) return []

  const now = Date.now()
  return [
    { id: "story-sarah", ownerId: "cand-1", name: "Sarah", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah&size=128", text: "Morning coffee vibes", createdAt: now - 3600000 },
    { id: "story-emma", ownerId: "cand-2", name: "Emma", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emma&size=128", text: "Studio day", createdAt: now - 7200000 },
    { id: "story-jessica", ownerId: "cand-3", name: "Jessica", photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Jessica&size=128", text: "Shipping something new", createdAt: now - 10800000 },
  ]
}

const STORY_MEDIA_MAX_BYTES = 48_000
const SAFE_STORY_BACKGROUNDS = new Set([
  "linear-gradient(145deg,#064e3b 0%,#047857 48%,#0f172a 100%)",
  "linear-gradient(145deg,#7c2d12 0%,#db2777 52%,#4c1d95 100%)",
  "linear-gradient(145deg,#082f49 0%,#0369a1 52%,#312e81 100%)",
  "linear-gradient(145deg,#713f12 0%,#ca8a04 52%,#9a3412 100%)",
  "linear-gradient(145deg,#4a044e 0%,#a21caf 55%,#831843 100%)",
  "linear-gradient(145deg,#111827 0%,#334155 52%,#020617 100%)",
])

function boundedStoryText(value: unknown, maxLength: number): string {
  return typeof value === "string" ? value.replace(/[\u0000-\u001F\u007F]/g, "").slice(0, maxLength) : ""
}

export function sanitizeStory(value: unknown): StoryItem | null {
  if (!value || typeof value !== "object") return null
  const raw = value as Partial<StoryItem>
  const id = boundedStoryText(raw.id, 80)
  const name = boundedStoryText(raw.name, 80)
  const createdAt = typeof raw.createdAt === "number" && Number.isFinite(raw.createdAt) ? raw.createdAt : 0
  if (!id || !name || createdAt <= 0) return null

  const media = raw.media && (raw.media.type === "image" || raw.media.type === "video") && typeof raw.media.url === "string" && raw.media.url.length <= STORY_MEDIA_MAX_BYTES
    ? { type: raw.media.type, url: raw.media.url }
    : null

  return {
    id,
    ownerId: typeof raw.ownerId === "string" ? boundedStoryText(raw.ownerId, 80) : undefined,
    name,
    photo: typeof raw.photo === "string" && raw.photo.length <= STORY_MEDIA_MAX_BYTES ? raw.photo : undefined,
    text: boundedStoryText(raw.text, 500),
    media,
    background: typeof raw.background === "string" && SAFE_STORY_BACKGROUNDS.has(raw.background) ? raw.background : undefined,
    audience: ["everyone", "followers", "friends", "matches-only", "private"].includes(String(raw.audience)) ? raw.audience : undefined,
    status: ["draft", "published", "expired", "archived", "highlight"].includes(String(raw.status)) ? raw.status : undefined,
    expiresAt: typeof raw.expiresAt === "number" && Number.isFinite(raw.expiresAt) ? raw.expiresAt : undefined,
    archivedAt: typeof raw.archivedAt === "number" && Number.isFinite(raw.archivedAt) ? raw.archivedAt : undefined,
    highlightedAt: typeof raw.highlightedAt === "number" && Number.isFinite(raw.highlightedAt) ? raw.highlightedAt : undefined,
    createdAt,
  }
}

export function sanitizeStories(value: unknown): StoryItem[] {
  if (!Array.isArray(value)) return []
  const seen = new Set<string>()
  return value
    .map(sanitizeStory)
    .filter((story): story is StoryItem => {
      if (!story) return false
      if (seen.has(story.id)) return false
      seen.add(story.id)
      return true
    })
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 50)
}

// Default profile
export function defaultProfile(): Profile {
  return {
    displayName: "User",
    age: 25,
    gender: "prefer-not-to-say",
    city: "",
    country: "",
    bio: "",
    primaryMode: "dating",
    interests: [],
    photos: [],
    coverPhoto: null,
    status: "",
    profession: "",
    bornDate: "",
    hometown: "",
    education: "",
    verified: false,
    onboarded: false,
    createdAt: Date.now(),
  }
}

/**
 * Map a Pi/local storage blob into a full Profile without unsafe casts.
 * Storage blobs are Record<string, unknown>; required fields fall back to defaults.
 */
export function coerceStoredProfile(blob: unknown): Profile | null {
  if (!blob || typeof blob !== "object" || Array.isArray(blob)) return null
  const raw = blob as Record<string, unknown>
  const base = defaultProfile()

  const str = (v: unknown, fallback: string): string =>
    typeof v === "string" ? v : fallback
  const strOrNull = (v: unknown): string | null =>
    v === null ? null : typeof v === "string" ? v : null
  const num = (v: unknown, fallback: number): number =>
    typeof v === "number" && Number.isFinite(v) ? v : fallback
  const bool = (v: unknown, fallback: boolean): boolean =>
    typeof v === "boolean" ? v : fallback
  const strArr = (v: unknown): string[] =>
    Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : []

  const genderRaw = raw.gender
  const gender =
    genderRaw === "male" ||
    genderRaw === "female" ||
    genderRaw === "non-binary" ||
    genderRaw === "prefer-not-to-say"
      ? genderRaw
      : base.gender

  const modeRaw = raw.primaryMode
  const primaryMode =
    modeRaw === "dating" ||
    modeRaw === "friendship" ||
    modeRaw === "networking"
      ? modeRaw
      : base.primaryMode

  const profile: Profile = {
    ...base,
    id: typeof raw.id === "string" ? raw.id : base.id,
    username:
      raw.username === null
        ? null
        : typeof raw.username === "string"
          ? raw.username
          : base.username,
    displayName: str(raw.displayName, base.displayName),
    age: num(raw.age, base.age),
    gender,
    city: str(raw.city, base.city),
    country: str(raw.country, base.country),
    bio: str(raw.bio, base.bio),
    primaryMode,
    interests: strArr(raw.interests).length ? strArr(raw.interests) : base.interests,
    photos: strArr(raw.photos),
    coverPhoto: strOrNull(raw.coverPhoto),
    status: str(raw.status, base.status),
    profession: str(raw.profession, base.profession),
    bornDate: str(raw.bornDate, base.bornDate),
    hometown: str(raw.hometown, base.hometown),
    education: str(raw.education, base.education),
    verified: bool(raw.verified, base.verified),
    onboarded: bool(raw.onboarded, base.onboarded),
    createdAt: num(raw.createdAt, base.createdAt),
  }

  if (Array.isArray(raw.connectionIntents)) {
    profile.connectionIntents = strArr(raw.connectionIntents)
  }
  if (Array.isArray(raw.skills)) {
    profile.skills = strArr(raw.skills)
  }
  if (Array.isArray(raw.pinnedPostIds)) {
    profile.pinnedPostIds = strArr(raw.pinnedPostIds)
  }
  if (typeof raw.isPublic === "boolean") profile.isPublic = raw.isPublic
  if (typeof raw.profileViews === "number") profile.profileViews = raw.profileViews
  if (
    raw.profileMode === "social" ||
    raw.profileMode === "professional" ||
    raw.profileMode === "business"
  ) {
    profile.profileMode = raw.profileMode
  }

  return profile
}

// Default settings
export const DEFAULT_SETTINGS: Settings = {
  darkMode: false,
  themeMode: "light",
  themeId: "gh-classic",
  themeCustomImage: null,
  themeImageOpacity: 0.35,
  language: "English",
  onlineStatus: "everyone",
  whoCanMessage: "everyone",
  profileVisibility: "everyone",
  storyVisibility: "everyone",
  whoCanDiscover: "everyone",
  whoCanFollow: "everyone",
  whoCanConnect: "everyone",
  showActivity: true,
  showInterests: true,
  showCommunities: true,
  showLocation: true,
  locationRadius: 50,
  ageMin: 18,
  ageMax: 45,
  genderPref: ["Everyone"],
  relationshipType: ["dating"],
  blockedUsers: [],
  moderationReports: [],
  notifyMatches: true,
  notifyMessages: true,
  notifyRewards: true,
  notifyMembership: true,
  notifyProfileViews: false,
  notifyMarketing: false,
}

// Seed candidates for discovery — PRODUCTION returns [] (never silent fake people)
export function seedCandidates(): Candidate[] {
  if (!isDemoDataAllowed()) return []
  const now = Date.now()
  const candidates: Candidate[] = [
    {
      id: "cand-1",
      name: "Sarah",
      age: 26,
      location: "Lagos, Nigeria",
      bio: "Adventure seeker, love travel and photography 📸",
      photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah&size=256",
      interests: ["Travel", "Photography", "Tech"],
      verified: true,
      online: true,
      lastSeen: now,
    },
    {
      id: "cand-2",
      name: "Emma",
      age: 24,
      location: "Abuja, Nigeria",
      bio: "Artist and coffee lover ☕",
      photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emma&size=256",
      interests: ["Arts", "Food", "Wellness"],
      verified: false,
      online: false,
      lastSeen: now - 3600000,
    },
    {
      id: "cand-3",
      name: "Jessica",
      age: 28,
      location: "Accra, Ghana",
      bio: "Entrepreneur building fintech. Let's connect!",
      photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Jessica&size=256",
      interests: ["Tech", "Entrepreneurship", "Finance"],
      verified: true,
      online: true,
      lastSeen: now,
    },
    {
      id: "cand-4",
      name: "Nicole",
      age: 25,
      location: "Nairobi, Kenya",
      bio: "Fitness enthusiast & yoga instructor",
      photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Nicole&size=256",
      interests: ["Fitness", "Wellness", "Nature"],
      verified: false,
      online: true,
      lastSeen: now,
    },
    {
      id: "cand-5",
      name: "Zainab",
      age: 27,
      location: "Cairo, Egypt",
      bio: "Teacher, bookworm, love meaningful conversations",
      photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Zainab&size=256",
      interests: ["Education", "Reading", "Writing"],
      verified: true,
      online: false,
      lastSeen: now - 7200000,
    },
    {
      id: "cand-6",
      name: "David",
      age: 29,
      location: "Cape Town, South Africa",
      bio: "Software engineer. Open to friendship and networking.",
      photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=David&size=256",
      interests: ["Tech", "Gaming", "Music"],
      verified: true,
      online: true,
      lastSeen: now,
    },
    {
      id: "cand-7",
      name: "Amina",
      age: 23,
      location: "Kano, Nigeria",
      bio: "Student, love languages and culture.",
      photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Amina&size=256",
      interests: ["Education", "Travel", "Reading"],
      verified: false,
      online: true,
      lastSeen: now - 1800000,
    },
    {
      id: "cand-8",
      name: "Kwame",
      age: 31,
      location: "Kumasi, Ghana",
      bio: "Business owner. Looking for meaningful connections.",
      photo: "https://api.dicebear.com/7.x/avataaars/svg?seed=Kwame&size=256",
      interests: ["Entrepreneurship", "Sports", "Food"],
      verified: true,
      online: false,
      lastSeen: now - 86400000,
    },
  ]
  return candidates
}

// Seed posts for home feed
export function seedPosts(): Post[] {
  if (!isDemoDataAllowed()) return []

  return [
    {
      id: "post-current-1",
      authorId: "current-user",
      authorName: "You",
      authorPhoto: "/placeholder.svg?width=40&height=40",
      content: "Just got back from this amazing trip to the mountains! The views were breathtaking 🏔️",
      images: ["/placeholder.svg?width=300&height=250"],
      video: null,
      pdf: null,
      pdfName: null,
      likes: 12,
      comments: [{ id: "c1", authorName: "Emma L.", authorPhoto: "/placeholder.svg?width=32&height=32", text: "Looks amazing!", createdAt: Date.now() - 600000 }],
      createdAt: Date.now() - 3600000,
    },
    {
      id: "post-1",
      authorId: "cand-1",
      authorName: "Sarah",
      authorPhoto: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah&size=128",
      content: "Morning coffee and a good book. Can't ask for more! ☕📖",
      images: ["/placeholder.svg?width=300&height=250"],
      video: null,
      pdf: null,
      pdfName: null,
      likes: 24,
      comments: [],
      createdAt: Date.now() - 5400000,
    },
    {
      id: "post-2",
      authorId: "cand-2",
      authorName: "Emma",
      authorPhoto: "https://api.dicebear.com/7.x/avataaars/svg?seed=Emma&size=128",
      content: "Started a new project this week. Really excited about where this is heading!",
      images: [],
      video: null,
      pdf: null,
      pdfName: null,
      likes: 8,
      comments: [],
      createdAt: Date.now() - 7200000,
    },
    {
      id: "post-3",
      authorId: "cand-3",
      authorName: "Jessica",
      authorPhoto: "https://api.dicebear.com/7.x/avataaars/svg?seed=Jessica&size=128",
      content: "Excited to announce we just hit 1M users on our app! Thank you all for the support 🎉",
      images: [],
      video: null,
      pdf: null,
      pdfName: null,
      likes: 45,
      comments: [],
      createdAt: Date.now() - 10800000,
    },
  ]
}

// Utility functions
export function timeAgo(timestamp: number): string {
  const now = Date.now()
  const diff = now - timestamp
  const seconds = Math.floor(diff / 1000)
  const minutes = Math.floor(seconds / 60)
  const hours = Math.floor(minutes / 60)
  const days = Math.floor(hours / 24)

  if (seconds < 60) return "now"
  if (minutes < 60) return `${minutes}m ago`
  if (hours < 24) return `${hours}h ago`
  if (days < 7) return `${days}d ago`

  const date = new Date(timestamp)
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 11)
}

/** @deprecated Prefer purpose-aware helpers from @/lib/media/compress-image */
export {
  compressImage,
  compressImageFile,
  compressForAvatar,
  compressForCover,
  compressForFeed,
  compressForTheme,
  compressForMessage,
} from "@/lib/media/compress-image"

export const LANGUAGES = ["English", "Spanish", "French", "German", "Portuguese", "Arabic", "Hindi", "Chinese"]

export const SUPPORT_CONTACTS = {
  whatsapp: "+2348143225421",
  facebook: "https://www.facebook.com/GreenHavenXpres",
  email: "support@ghconnect.com",
}

// Privacy settings utilities
export function shouldShowLocation(profileVisibility: string, myVisibility: string): boolean {
  if (profileVisibility === "everyone") return true
  if (profileVisibility === "hidden") return false
  return myVisibility === "matches-only" // Matches only see if both match
}

export function shouldShowOnlineStatus(onlineStatus: string, isMatched: boolean): boolean {
  if (onlineStatus === "everyone") return true
  if (onlineStatus === "hidden") return false
  if (onlineStatus === "matches-only" && isMatched) return true
  return false
}

export function getVisibleUserDetails(candidate: Candidate, userSettings: Settings, isMatched: boolean = false) {
  return {
    name: candidate.name, // Always show name
    age: candidate.age, // Always show age
    photo: candidate.photo, // Always show photo
    bio: candidate.bio, // Always show bio in discovery
    interests: candidate.interests, // Always show interests
    location: userSettings.profileVisibility === "hidden" ? "Hidden" : candidate.location,
    online: shouldShowOnlineStatus(userSettings.onlineStatus, isMatched),
    verified: candidate.verified, // Verified status always shown
  }
}

// Legal content
export const LEGAL = {
  about: `Welcome to GreenHaven — a global community built on genuine connections.

GreenHaven (GreenHaven Connect) was created with a simple belief: meaningful relationships should know no borders. Whether you're looking for friendship, dating, professional networking, or something in between, our platform brings together people from every corner of the world in a safe, respectful, and inclusive environment.

Our Mission: To empower individuals to form authentic connections across cultures, interests, and backgrounds — fostering relationships that enrich lives and broaden horizons.

Our Values:
• Safety First: Every feature prioritizes your security and privacy
• Authenticity: We celebrate genuine connections and verified profiles
• Inclusivity: Everyone is welcome regardless of background, gender, or orientation
• Respect: We maintain a culture of kindness and mutual respect
• Transparency: We are open about how your data is used and protected`,

  terms: `Terms of Service - GreenHaven

1. Acceptance of Terms
By using GreenHaven, you accept these terms and our privacy policy.

2. User Conduct
You agree to:
- Be at least 18 years old
- Provide accurate information
- Respect other users
- Not engage in harassment or abuse
- Not share explicit content
- Follow all applicable laws

3. Account Responsibility
You are responsible for maintaining your account security and all activities under your account.

4. User Content
You retain all rights to content you post. By posting, you grant GreenHaven a license to use that content.

5. Limitations of Liability
GreenHaven is provided "as is". We are not liable for indirect damages or issues arising from third-party content.

6. Termination
We reserve the right to terminate accounts that violate these terms.

7. Changes to Terms
We may update these terms at any time with notice to users.`,

  privacy: `Privacy Policy - GreenHaven

Last updated: 2026-10-26

GreenHaven is a social and marketplace app for Pioneers. We design data practices to collect only what is needed to run the product.

1. Authentication with Pi
- You sign in with Pi Authentication (Pi Browser / Pi SDK). We do not operate a separate password login.
- After you authorize the app, our servers verify your session with Pi Platform (/v2/me) and store an app-specific Pi user identifier linked to your GreenHaven account.
- We may store your Pi display username when Pi provides it. This is not a password and is not a legal identity document.
- We do not receive your Pi wallet seed phrase. Payments are authorized by you through Pi payment flows.

2. Information We Collect
- Profile content you choose to provide (display name, photos, bio, interests, location you set)
- Social and marketplace activity inside GreenHaven (posts, messages, listings, communities)
- Technical logs needed for security and reliability (approximate device/browser metadata, IP for abuse prevention)
- Payment intent records for π transactions you complete in-app (amount, status, purpose) — separate from any internal GHC reward balance

3. What We Do Not Require
- We do not require email or phone number solely to use core social features unless a specific feature genuinely needs it and you consent.
- We do not sell personal data.
- We do not import Pi private messages or the Pi social graph; messaging and communities on GreenHaven are our own systems.

4. How We Use Information
- Provide and improve GreenHaven features
- Secure accounts, prevent fraud and abuse
- Process π payments you initiate and related support
- Operate optional internal rewards (GHC) under our product rules — rewards are not a substitute for π and are not a claim on Pi Network

5. Sharing
- Other GreenHaven users see what you publish under your privacy settings
- Infrastructure providers (hosting, database) process data under contract to run the service
- Legal requests when required by law
- Pi Platform receives what is necessary for authentication and payments you start

6. Retention and Your Rights
- You may update profile content in-app
- You may request account deletion; residual legal/security logs may be kept as required
- Contact support through in-app Support or the contact listed in the app store / Developer Portal listing

7. International and Ecosystem Context
- GreenHaven may be accessed via Pi Browser. Hosting regions depend on our deployment provider (for example Vercel).
- This policy is the Privacy Policy URL for Developer Portal configuration.

8. Changes
We may update this policy; material changes will be reflected by updating this page.`,
}


/**
 * Studio / local reciprocal interests so mutual Match can form when the user
 * expresses interest back. Never creates a Match by itself.
 * Only a subset of candidates "liked" the current user.
 */
export function seedReciprocalInterests(
  candidates: { id: string }[],
  currentUserId = "current-user",
): import("./ghc-types").Like[] {
  if (!isDemoDataAllowed()) return []

  const now = Date.now()
  const likes: import("./ghc-types").Like[] = []
  candidates.forEach((c, index) => {
    // Every other candidate has already expressed interest (mutual when user likes)
    if (index % 2 === 0 && c.id && c.id !== currentUserId) {
      likes.push({
        id: `seed-like-in-${c.id}`,
        fromUserId: c.id,
        toUserId: currentUserId,
        createdAt: now - (index + 1) * 60000,
      })
    }
  })
  return likes
}
