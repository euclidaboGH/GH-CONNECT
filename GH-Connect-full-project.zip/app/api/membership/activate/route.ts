/**
 * POST /api/membership/activate
 * Server grants VIP/VVIP only after verified Pi intent COMPLETED or GHC catalog spend.
 */
import { NextResponse } from "next/server"
import { resolveAuthenticatedUser } from "@/lib/server/economy/auth"
import {
  getEntitlement,
  tryGetEntitlementAuthoritative,
  grantEntitlement,
  MEMBERSHIP_SERVER_CATALOG,
} from "@/lib/server/membership/entitlement-store"
import {
  getPaymentIntent,
  loadPaymentIntent,
  loadByProviderPaymentId,
} from "@/lib/server/payments/intent-store"
import {
  executeAuthoritativeSpend,
  getProcessGhcStore,
} from "@/lib/server/economy/store"
import { allowMemoryServer, isDatabaseConfigured } from "@/lib/server/economy/http"
import { readGhcServerEnv as readEnv } from "@/lib/server/economy/env"
import { getRequestContext } from "@/lib/server/foundation/request-context"
import { z } from "zod"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

async function rpcSpend(input: {
  userId: string
  amount: number
  referenceId: string
  reason: string
}): Promise<{ ok: boolean; error?: string; tx?: unknown; idempotent?: boolean }> {
  const env = readEnv()
  if (!env.supabaseUrl || !env.supabaseServiceRoleKey) {
    return { ok: false, error: "SERVER_UNAVAILABLE" }
  }
  try {
    const res = await fetch(
      `${env.supabaseUrl.replace(/\/$/, "")}/rest/v1/rpc/ghc_execute_spend`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey: env.supabaseServiceRoleKey,
          Authorization: `Bearer ${env.supabaseServiceRoleKey}`,
        },
        body: JSON.stringify({
          p_user_id: input.userId,
          p_amount: input.amount,
          p_reference_id: input.referenceId,
          p_reason: input.reason,
          p_source_event: "PREMIUM_PURCHASE",
        }),
      }
    )
    const data = await res.json().catch(() => null)
    if (!res.ok || !data?.ok) {
      return { ok: false, error: String(data?.error || "SPEND_FAILED") }
    }
    return { ok: true, idempotent: Boolean(data.idempotent), tx: data.tx }
  } catch {
    return { ok: false, error: "SPEND_RPC_FAILED" }
  }
}

export async function POST(request: Request) {
  const reqCtx = getRequestContext(request.headers)
  const auth = await resolveAuthenticatedUser(request.headers)
  if (!auth) {
    return NextResponse.json({ ok: false, error: "AUTH_REQUIRED" }, { status: 401, headers: { "x-request-id": reqCtx.requestId } })
  }

  const raw = await request.json().catch(() => ({}))
  const schema = z.object({
    tier: z.enum(["vip", "vvip"]),
    period: z.enum(["monthly", "yearly"]).optional(),
    billingPeriod: z.enum(["monthly", "yearly"]).optional(),
    method: z.enum(["pi", "ghc"]),
    intentId: z.string().max(120).optional(),
    paymentId: z.string().max(120).optional(),
    spendReferenceId: z.string().max(160).optional(),
  })
  const parsed = schema.safeParse({
    ...raw,
    tier: String((raw as { tier?: string }).tier || "").toLowerCase(),
    period: String((raw as { period?: string }).period || "").toLowerCase() || undefined,
    billingPeriod: String((raw as { billingPeriod?: string }).billingPeriod || "").toLowerCase() || undefined,
    method: String((raw as { method?: string }).method || "").toLowerCase(),
  })
  if (!parsed.success) {
    return NextResponse.json(
      { ok: false, error: "INVALID_BODY", details: parsed.error.flatten() },
      { status: 400, headers: { "x-request-id": reqCtx.requestId } }
    )
  }
  const tier = parsed.data.tier
  const period = (parsed.data.period || parsed.data.billingPeriod || "monthly") as "monthly" | "yearly"
  const method = parsed.data.method
  const body = { ...raw, ...parsed.data, period, tier, method }

  const catalog = MEMBERSHIP_SERVER_CATALOG[tier as "vip" | "vvip"]

  // Idempotent / already-active: same tier still valid — do not charge again
  try {
    const existingResult = await tryGetEntitlementAuthoritative(auth.userId)
    if (
      existingResult.ok &&
      existingResult.entitlement.tier === tier &&
      existingResult.entitlement.active !== false &&
      (!existingResult.entitlement.expiresAt ||
        existingResult.entitlement.expiresAt > Date.now() + 60_000)
    ) {
      return NextResponse.json(
        {
          ok: true,
          entitlement: existingResult.entitlement,
          alreadyActive: true,
          message: "Membership already active for this tier",
        },
        { status: 200 }
      )
    }
  } catch {
    /* continue — store may be unavailable; spend path will surface errors */
  }

  if (method === "pi") {
    const intentId = String(body.intentId || "").trim()
    const paymentId = String(body.paymentId || "").trim()

    let intent =
      (intentId ? await loadPaymentIntent(intentId) : null) ||
      (paymentId ? await loadByProviderPaymentId(paymentId) : null) ||
      (intentId ? getPaymentIntent(intentId) : null)

    if (!intent) {
      return NextResponse.json(
        {
          ok: false,
          error: "INTENT_REQUIRED",
          message: "Durable COMPLETED payment intent required — client paymentId/txid is not enough",
        },
        { status: 409 }
      )
    }

    if (intent.userId !== auth.userId) {
      return NextResponse.json({ ok: false, error: "FORBIDDEN" }, { status: 403 })
    }

    if (intent.status !== "COMPLETED" && intent.status !== "FULFILLED") {
      return NextResponse.json(
        { ok: false, error: "PAYMENT_NOT_COMPLETED", status: intent.status },
        { status: 409 }
      )
    }

    if (intent.currency && intent.currency !== "PI") {
      return NextResponse.json({ ok: false, error: "CURRENCY_MISMATCH" }, { status: 409 })
    }

    const expectedPi = period === "yearly" ? catalog.yearlyPi : catalog.monthlyPi
    if (Math.abs(Number(intent.amount) - expectedPi) > 0.001) {
      return NextResponse.json(
        { ok: false, error: "amount_mismatch", expected: expectedPi, actual: intent.amount },
        { status: 409 }
      )
    }

    // Durable intent must name the exact catalog product (tier+period). Do not
    // accept a bare purpose "membership" alone — that would let a VIP payment
    // activate VVIP (or vice versa) when amounts are not checked strictly enough.
    const productId = String(intent.metadata?.productId || "")
    const expected = `membership_${tier}_${period}`
    if (!productId || productId !== expected) {
      return NextResponse.json(
        { ok: false, error: "PRODUCT_MISMATCH", expected, productId: productId || null },
        { status: 409 }
      )
    }

    const purchaseRef =
      intent.providerPaymentId || paymentId || `pi:${intent.id}`

    // Payment intent is durable; entitlement table may still be missing in production.
    // Never report ok:true unless grantEntitlement persisted (or Studio memory path).
    try {
      const entitlement = await grantEntitlement({
        userId: auth.userId,
        tier,
        billingPeriod: period,
        source: "pi",
        purchaseRef,
        paymentIntentId: intent.id,
      })
      return NextResponse.json({ ok: true, entitlement })
    } catch (e) {
      const msg = e instanceof Error ? e.message : "MEMBERSHIP_DURABLE_WRITE_FAILED"
      const code =
        msg.includes("MEMBERSHIP_STORE_UNAVAILABLE") || msg.includes("MEMBERSHIP_DURABLE")
          ? msg.includes("STORE")
            ? "MEMBERSHIP_STORE_UNAVAILABLE"
            : "MEMBERSHIP_DURABLE_WRITE_FAILED"
          : "MEMBERSHIP_DURABLE_WRITE_FAILED"
      console.error("[membership/activate] grant after Pi payment failed", code)
      return NextResponse.json(
        {
          ok: false,
          error: code,
          message:
            "Payment was recorded, but membership entitlement could not be stored durably. Retry activation after ghc_membership_entitlements is available.",
          paymentIntentId: intent.id,
          purchaseRef,
        },
        { status: 503 }
      )
    }
  }

  // method === "ghc"
  const price = period === "yearly" ? catalog.yearlyGhc : catalog.monthlyGhc
  const referenceId =
    String(body.spendReferenceId || "").trim() ||
    `membership_${tier}_${period}_${auth.userId}`

  if (isDatabaseConfigured()) {
    const spend = await rpcSpend({
      userId: auth.userId,
      amount: price,
      referenceId,
      reason: `Membership ${tier} ${period}`,
    })
    if (!spend.ok) {
      const status = spend.error === "INSUFFICIENT_BALANCE" ? 402 : 503
      return NextResponse.json(
        {
          ok: false,
          error: spend.error || "SPEND_FAILED",
          message:
            spend.error === "INSUFFICIENT_BALANCE"
              ? "Insufficient GHC balance for this membership plan"
              : "Could not complete GHC membership spend",
        },
        { status }
      )
    }
    try {
      const entitlement = await grantEntitlement({
        userId: auth.userId,
        tier,
        billingPeriod: period,
        source: "ghc",
        purchaseRef: referenceId,
      })
      return NextResponse.json({ ok: true, entitlement, spend: spend.tx, idempotent: spend.idempotent })
    } catch (e) {
      const msg = e instanceof Error ? e.message : "MEMBERSHIP_DURABLE_WRITE_FAILED"
      console.error("[membership/activate] grant after GHC spend failed", msg)
      return NextResponse.json(
        {
          ok: false,
          error: "MEMBERSHIP_DURABLE_WRITE_FAILED",
          message:
            "GHC spend may have been applied, but membership entitlement could not be stored durably.",
          spendReferenceId: referenceId,
        },
        { status: 503 }
      )
    }
  }

  if (allowMemoryServer()) {
    const spend = await executeAuthoritativeSpend(getProcessGhcStore(), {
      userId: auth.userId,
      amount: price,
      referenceId,
      reason: `Membership ${tier} ${period}`,
      sourceEvent: "PREMIUM_PURCHASE",
    })
    if (!spend.ok) {
      return NextResponse.json(
        { ok: false, error: spend.error || "SPEND_FAILED" },
        { status: 400 }
      )
    }
    const entitlement = await grantEntitlement({
      userId: auth.userId,
      tier,
      billingPeriod: period,
      source: "ghc",
      purchaseRef: spend.tx?.id || referenceId,
    })
    return NextResponse.json({ ok: true, entitlement, spend: spend.tx })
  }

  return NextResponse.json(
    {
      ok: false,
      error: "SERVER_UNAVAILABLE",
      message: "GHC membership spend requires database or GHC_SERVER_MEMORY=1",
    },
    { status: 503 }
  )
}

export async function GET(request: Request) {
  const auth = await resolveAuthenticatedUser(request.headers)
  if (!auth) {
    return NextResponse.json({ ok: false, error: "AUTH_REQUIRED" }, { status: 401 })
  }
  const result = await tryGetEntitlementAuthoritative(auth.userId)
  if (!result.ok) {
    return NextResponse.json(
      { ok: false, error: "MEMBERSHIP_STORE_UNAVAILABLE" },
      { status: 503 }
    )
  }
  return NextResponse.json({
    ok: true,
    entitlement: result.entitlement,
    source: result.source,
  })
}
